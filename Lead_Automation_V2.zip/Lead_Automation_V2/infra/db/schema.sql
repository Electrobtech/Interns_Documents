-- =====================================================================
-- Lead Automation — Multi-tenant SaaS schema (PostgreSQL)
-- Every table carries organization_id for org-wide data isolation.
-- Unified Schema (Main Project + Custom Additions)
-- =====================================================================
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ---------- Tenancy ----------
CREATE TABLE IF NOT EXISTS organizations (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                    TEXT NOT NULL,
  slug                    TEXT UNIQUE NOT NULL,
  -- ---- Company Registration (Tenant Onboarding) profile ----
  legal_name              TEXT,
  business_type           TEXT,   -- proprietorship | partnership | llp | private_limited | public_limited | startup | ngo | other
  industry                TEXT,
  website                 TEXT,
  logo_url                TEXT,
  employee_count          TEXT,
  description             TEXT,
  company_email           TEXT,
  company_phone           TEXT,
  support_email           TEXT,
  alternate_phone         TEXT,
  address_line1           TEXT,
  address_line2           TEXT,
  city                    TEXT,
  state                   TEXT,
  country                 TEXT,
  postal_code             TEXT,
  gst_number              TEXT,
  pan_number              TEXT,
  registration_number     TEXT,
  incorporation_cert_url  TEXT,
  gst_cert_url            TEXT,
  registration_cert_url   TEXT,
  subscription_plan       TEXT DEFAULT 'starter', -- starter | professional | enterprise
  coupon_code             TEXT,
  status                  TEXT DEFAULT 'pending', -- pending | active | suspended
  onboarding_step         INT DEFAULT 1,
  -- ---- GST verification auto-fill (Step 5 "Verify GST") ----
  trade_name              TEXT,
  district                TEXT,
  gst_status              TEXT,   -- e.g. Active | Cancelled | Suspended, as returned by the GST provider
  gst_registration_date   TEXT,   -- kept as returned by the provider (formats vary); not a DB date type
  gst_verified_at         TIMESTAMPTZ,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS organizations_name_ci_idx ON organizations (lower(name));

-- GST verification cache
CREATE TABLE IF NOT EXISTS gst_verifications (
  gst_number           TEXT PRIMARY KEY,
  verification_status  TEXT,
  company_name         TEXT,
  trade_name           TEXT,
  business_type        TEXT,
  registration_date    TEXT,
  address              TEXT,
  district             TEXT,
  state                TEXT,
  pincode              TEXT,
  verified_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Auth / Users / Roles ----------
CREATE TABLE IF NOT EXISTS roles (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,             -- admin | manager | agent
  description   TEXT,
  UNIQUE (name)
);

CREATE TABLE IF NOT EXISTS permissions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          TEXT UNIQUE NOT NULL,      -- e.g. inbox:read, campaign:send
  description   TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id       UUID REFERENCES roles(id) ON DELETE CASCADE,
  permission_id UUID REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS users (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id     UUID REFERENCES organizations(id) ON DELETE CASCADE,
  role_id             UUID REFERENCES roles(id),
  name                TEXT NOT NULL,
  email               TEXT NOT NULL,
  mobile              TEXT,
  password_hash       TEXT NOT NULL,
  availability        TEXT DEFAULT 'offline',  -- online | away | offline
  is_email_verified   BOOLEAN NOT NULL DEFAULT false,
  is_phone_verified   BOOLEAN NOT NULL DEFAULT false,
  two_factor_enabled  BOOLEAN NOT NULL DEFAULT false,
  two_factor_method   TEXT,                     -- authenticator | sms
  pin_hash            TEXT,                      -- bcrypt hash of a 4-6 digit PIN, alt login (017_pin_authentication.sql)
  is_pin_enabled      BOOLEAN NOT NULL DEFAULT false,
  failed_pin_attempts INTEGER NOT NULL DEFAULT 0,
  pin_lockout_until   TIMESTAMPTZ,
  pin_updated_at      TIMESTAMPTZ,                -- age-checked at login for 30-day expiration
  previous_pin_hash   TEXT,                       -- prior PIN, so a new one can't just repeat it (018_pin_expiration_history.sql)
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, email)
);

-- Verification codes used by registration wizard
CREATE TABLE IF NOT EXISTS verification_codes (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  channel         TEXT NOT NULL,           -- email | mobile
  target          TEXT NOT NULL,           -- email address or phone number
  code_hash       TEXT NOT NULL,
  purpose         TEXT NOT NULL DEFAULT 'signup',
  consumed        BOOLEAN NOT NULL DEFAULT false,
  expires_at      TIMESTAMPTZ NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS verification_codes_target_idx ON verification_codes (channel, target);

CREATE TABLE IF NOT EXISTS teams (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Channels & Integrations ----------
CREATE TABLE IF NOT EXISTS channels (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  type            TEXT NOT NULL,           -- whatsapp | instagram | messenger | sms | webchat | voice | email | google_reviews | linkedin
  display_name    TEXT,
  status          TEXT DEFAULT 'disconnected',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS integrations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  provider        TEXT NOT NULL,           -- shopify | stripe | google_sheets | zapier ...
  status          TEXT DEFAULT 'disconnected',
  credentials     JSONB DEFAULT '{}'::jsonb,
  locked_at       TIMESTAMPTZ,
  locked_by       UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Contacts & Leads ----------
CREATE TABLE IF NOT EXISTS contacts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  name            TEXT,
  email           TEXT,
  phone           TEXT,
  source          TEXT,                    -- lead source / origin channel
  external_id     TEXT,                    -- raw channel identity (WhatsApp phone / IG-scoped user id / etc)
  tags            TEXT[] DEFAULT '{}',
  notes           TEXT,
  opted_out       BOOLEAN NOT NULL DEFAULT false, -- True once contact sends STOP/UNSUBSCRIBE
  opted_out_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_contacts_org_source_external
  ON contacts (organization_id, source, external_id)
  WHERE external_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS leads (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id) ON DELETE CASCADE,
  stage           TEXT DEFAULT 'new',      -- new | qualified | active | won | lost
  priority        TEXT DEFAULT 'medium',
  score           INT DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Conversations & Messages ----------
CREATE TABLE IF NOT EXISTS conversations (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id     UUID REFERENCES organizations(id) ON DELETE CASCADE,
  contact_id          UUID REFERENCES contacts(id),
  channel_type        TEXT NOT NULL,
  assigned_to         UUID REFERENCES users(id),
  status              TEXT DEFAULT 'open',     -- open | pending | missed | campaign | closed
  handled_by          TEXT NOT NULL DEFAULT 'bot'
                        CHECK (handled_by IN ('bot','human')),
  external_contact_id TEXT,                    -- provider-side thread/sender id
  last_message_at     TIMESTAMPTZ DEFAULT now(),
  last_read_at        TIMESTAMPTZ NOT NULL DEFAULT now(), -- bumped on open; see migrations/023_conversation_last_read_at.sql
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_conversations_org_channel_external
  ON conversations (organization_id, channel_type, external_contact_id);

CREATE TABLE IF NOT EXISTS messages (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
  direction       TEXT NOT NULL,           -- inbound | outbound
  body            TEXT,
  sender          TEXT,
  message_type    TEXT NOT NULL DEFAULT 'text', -- text | button_click | list_select | buttons | list | document | system
  metadata        JSONB NOT NULL DEFAULT '{}'::jsonb,
  media_url       TEXT,                    -- WhatsApp/IG media or email attachment download URL
  media_type      TEXT,
  external_id     TEXT,                    -- provider-side message id (wamid / Gmail message id)
  subject         TEXT,                    -- email-specific subject line
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Realtime message fan-out ----------
CREATE OR REPLACE FUNCTION notify_new_message() RETURNS TRIGGER AS $$
BEGIN
  PERFORM pg_notify(
    'messages_channel',
    json_build_object(
      'id', NEW.id,
      'conversation_id', NEW.conversation_id,
      'organization_id', NEW.organization_id
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS messages_notify_trigger ON messages;
CREATE TRIGGER messages_notify_trigger
  AFTER INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION notify_new_message();

-- ---------- Email (Gmail) ----------
CREATE TABLE IF NOT EXISTS email_accounts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  provider          TEXT NOT NULL DEFAULT 'gmail',
  email             TEXT NOT NULL,
  access_token      TEXT,
  refresh_token     TEXT,
  token_expires_at  TIMESTAMPTZ,
  scope             TEXT,
  connected         BOOLEAN NOT NULL DEFAULT true,
  connected_by      UUID REFERENCES users(id),
  history_id        TEXT,
  watch_expires_at  TIMESTAMPTZ,
  last_synced_at    TIMESTAMPTZ,
  last_sync_error   TEXT,
  signature_html    TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, email)
);

CREATE TABLE IF NOT EXISTS email_threads (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  email_account_id  UUID REFERENCES email_accounts(id) ON DELETE CASCADE,
  thread_id         TEXT NOT NULL,
  conversation_id   UUID REFERENCES conversations(id) ON DELETE SET NULL,
  subject           TEXT,
  participants      TEXT[] DEFAULT '{}',
  last_message_time TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (email_account_id, thread_id)
);

CREATE TABLE IF NOT EXISTS email_messages (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  email_account_id  UUID REFERENCES email_accounts(id) ON DELETE CASCADE,
  thread_id         UUID REFERENCES email_threads(id) ON DELETE CASCADE,
  message_id        TEXT NOT NULL,
  rfc822_message_id TEXT,
  in_reply_to       TEXT,
  from_email        TEXT,
  to_email          TEXT[] DEFAULT '{}',
  cc_email          TEXT[] DEFAULT '{}',
  subject           TEXT,
  body              TEXT,
  html_body         TEXT,
  snippet           TEXT,
  direction         TEXT NOT NULL,
  status            TEXT NOT NULL DEFAULT 'received',
  label_ids         TEXT[] DEFAULT '{}',
  has_attachments   BOOLEAN NOT NULL DEFAULT false,
  received_at       TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (email_account_id, message_id)
);

CREATE INDEX IF NOT EXISTS ix_email_messages_thread ON email_messages (thread_id, received_at);

CREATE TABLE IF NOT EXISTS email_attachments (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id          UUID REFERENCES email_messages(id) ON DELETE CASCADE,
  filename            TEXT,
  mime_type           TEXT,
  size                INT,
  gmail_attachment_id TEXT,
  url                 TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_email_attachments_message ON email_attachments (message_id);

-- ---------- Campaigns ----------
CREATE TABLE IF NOT EXISTS campaigns (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  type            TEXT DEFAULT 'broadcast',
  channel_type    TEXT,
  message_body    TEXT,
  cta             JSONB,
  scheduled_at    TIMESTAMPTZ,
  status          TEXT DEFAULT 'draft',    -- draft | scheduled | sent | needs_approval | rejected | queued | processing | completed | failed
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- Bulk/broadcast SMS & RCS support (020_bulk_campaigns.sql) — additive,
  -- NULL/defaulted for the original one-shot campaigns.send flow.
  -- flow_playbook_id is added further down via ALTER TABLE, once
  -- `playbooks` itself exists (playbooks is created later in this file;
  -- 020_bulk_campaigns.sql could add it as a plain REFERENCES column
  -- because it ran as a later ALTER against an already-live database
  -- where playbooks already existed — a fresh single-pass schema.sql
  -- load doesn't have that luxury).
  recipient_source     TEXT,                 -- 'csv' | 'manual' | 'segment'
  send_mode            TEXT DEFAULT 'immediate', -- 'immediate' | 'scheduled'
  throttle_per_minute  INT DEFAULT 60,       -- SMS/min rate cap for this broadcast
  total_recipients     INT DEFAULT 0,
  sent_count           INT DEFAULT 0,
  failed_count         INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS campaign_audiences (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id     UUID REFERENCES campaigns(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS campaign_logs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id     UUID REFERENCES campaigns(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id),
  event           TEXT,                    -- delivered | opened | clicked | replied | converted
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Per-recipient bulk-broadcast tracking (020_bulk_campaigns.sql) — a
-- broadcast of thousands needs per-row retry/error visibility that the
-- aggregate campaign_logs event stream doesn't give.
CREATE TABLE IF NOT EXISTS campaign_recipients (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id     UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id) ON DELETE SET NULL, -- null when the row came from a raw CSV/manual entry with no matching contact
  phone           TEXT NOT NULL,
  name            TEXT,
  variables       JSONB NOT NULL DEFAULT '{}',  -- mapped CSV-column -> flow-parameter values for this recipient
  status          TEXT NOT NULL DEFAULT 'pending', -- pending | queued | sent | failed
  error           TEXT,
  attempts        INT NOT NULL DEFAULT 0,
  job_id          TEXT,                          -- BullMQ job id, for cross-referencing worker logs
  -- FIX: bulkCampaignWorker.js writes this on every send attempt (success or
  -- failure) and campaign-service's GET /campaigns/:id/recipients selects it,
  -- but it was missing here entirely — every job failed with
  -- 'column "rendered_message" does not exist' and crashed the worker/process.
  rendered_message TEXT,
  sent_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_campaign_recipients_campaign_status
  ON campaign_recipients (campaign_id, status);

-- Fast dedupe / lookup by phone within a single campaign (e.g. a CSV with a
-- repeated number, or checking "did this number already get queued").
CREATE INDEX IF NOT EXISTS ix_campaign_recipients_campaign_phone
  ON campaign_recipients (campaign_id, phone);

-- ---------- Reviews & Social ----------
CREATE TABLE IF NOT EXISTS reviews (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  source          TEXT,                    -- google
  author          TEXT,
  rating          INT,
  body            TEXT,
  reply           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS social_comments (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  source          TEXT,                    -- facebook | linkedin
  author          TEXT,
  body            TEXT,
  reply           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Google Business Profile Reviews ----------
CREATE TABLE IF NOT EXISTS google_tokens (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  access_token      TEXT,
  access_expires_at TIMESTAMPTZ,
  refresh_token     TEXT NOT NULL,
  scope             TEXT,
  connected_by      UUID REFERENCES users(id),
  last_sync_at      TIMESTAMPTZ,
  last_sync_status  TEXT,                 -- ok | error
  last_sync_error   TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id)
);

CREATE TABLE IF NOT EXISTS google_accounts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  account_id        TEXT NOT NULL,
  account_name      TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, account_id)
);

CREATE TABLE IF NOT EXISTS google_locations (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  account_id        TEXT NOT NULL,
  location_id       TEXT NOT NULL,
  location_name     TEXT,
  address           TEXT,
  phone             TEXT,
  is_selected       BOOLEAN NOT NULL DEFAULT false,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, location_id)
);

CREATE TABLE IF NOT EXISTS google_reviews (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id     UUID REFERENCES organizations(id) ON DELETE CASCADE,
  location_id         TEXT NOT NULL,
  review_id           TEXT NOT NULL,
  reviewer_name       TEXT,
  reviewer_photo_url  TEXT,
  star_rating         INT,
  comment             TEXT,
  create_time         TIMESTAMPTZ,
  update_time         TIMESTAMPTZ,
  reply_comment       TEXT,
  reply_update_time   TIMESTAMPTZ,
  synced_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, review_id)
);

CREATE INDEX IF NOT EXISTS idx_google_reviews_org_location
  ON google_reviews (organization_id, location_id);

CREATE INDEX IF NOT EXISTS idx_google_reviews_org_created
  ON google_reviews (organization_id, create_time DESC);

CREATE TABLE IF NOT EXISTS google_oauth_configs (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id         UUID REFERENCES organizations(id) ON DELETE CASCADE,
  client_id               TEXT NOT NULL,
  encrypted_client_secret TEXT NOT NULL,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id)
);

-- ---------- Email (Gmail) — see migrations/013_email_integration.sql and
-- services/email-service. Full-fidelity mailbox data lives in these
-- dedicated tables; a summarized copy is also written into the shared
-- conversations/messages tables above (channel_type='email') so a
-- connected mailbox shows up in the Unified Inbox like every other
-- channel. ----------
CREATE TABLE IF NOT EXISTS email_accounts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  provider          TEXT NOT NULL DEFAULT 'gmail',
  email             TEXT NOT NULL,
  access_token      TEXT,
  refresh_token     TEXT,
  token_expires_at  TIMESTAMPTZ,
  scope             TEXT,
  connected         BOOLEAN NOT NULL DEFAULT true,
  connected_by      UUID REFERENCES users(id),
  history_id        TEXT,
  watch_expires_at  TIMESTAMPTZ,
  last_synced_at    TIMESTAMPTZ,
  last_sync_error   TEXT,
  signature_html    TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, email)
);

CREATE TABLE IF NOT EXISTS email_threads (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id    UUID REFERENCES organizations(id) ON DELETE CASCADE,
  email_account_id   UUID REFERENCES email_accounts(id) ON DELETE CASCADE,
  thread_id          TEXT NOT NULL,
  conversation_id    UUID REFERENCES conversations(id) ON DELETE SET NULL,
  subject            TEXT,
  participants       TEXT[] DEFAULT '{}',
  last_message_time  TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (email_account_id, thread_id)
);

CREATE TABLE IF NOT EXISTS email_messages (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  email_account_id  UUID REFERENCES email_accounts(id) ON DELETE CASCADE,
  thread_id         UUID REFERENCES email_threads(id) ON DELETE CASCADE,
  message_id        TEXT NOT NULL,
  rfc822_message_id TEXT,
  in_reply_to       TEXT,
  from_email        TEXT,
  to_email          TEXT[] DEFAULT '{}',
  cc_email          TEXT[] DEFAULT '{}',
  subject           TEXT,
  body              TEXT,
  html_body         TEXT,
  snippet           TEXT,
  direction         TEXT NOT NULL,
  status            TEXT NOT NULL DEFAULT 'received',
  label_ids         TEXT[] DEFAULT '{}',
  has_attachments   BOOLEAN NOT NULL DEFAULT false,
  received_at       TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (email_account_id, message_id)
);

CREATE INDEX IF NOT EXISTS ix_email_messages_thread ON email_messages (thread_id, received_at);

CREATE TABLE IF NOT EXISTS email_attachments (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id          UUID REFERENCES email_messages(id) ON DELETE CASCADE,
  filename            TEXT,
  mime_type           TEXT,
  size                INT,
  gmail_attachment_id TEXT,
  url                 TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_email_attachments_message ON email_attachments (message_id);

-- ---------------------------------------------------------------------
-- Google Calendar integration (services/calendar-service) — see
-- infra/db/migrations/016_calendar_integration.sql for the full
-- rationale/comments; kept in sync here for fresh installs.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS calendar_accounts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  google_email      TEXT,
  access_token      TEXT,
  refresh_token     TEXT,
  token_expires_at  TIMESTAMPTZ,
  scope             TEXT,
  connected         BOOLEAN NOT NULL DEFAULT true,
  connected_by      UUID REFERENCES users(id),
  last_error        TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id)
);

CREATE TABLE IF NOT EXISTS calendar_events (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id     UUID REFERENCES organizations(id) ON DELETE CASCADE,
  -- NULL for events created while Google Calendar is not connected. Google is
  -- an optional enhancement (real invites/reminders); the internal calendar
  -- works without it, so this cannot be NOT NULL.
  google_event_id     TEXT,
  title               TEXT NOT NULL,
  description         TEXT,
  starts_at           TIMESTAMPTZ NOT NULL,
  ends_at             TIMESTAMPTZ NOT NULL,
  location            TEXT,
  attendee_emails     TEXT[],
  contact_id          UUID REFERENCES contacts(id) ON DELETE SET NULL,
  campaign_id         UUID REFERENCES campaigns(id) ON DELETE SET NULL,
  automation_node_id  TEXT,
  status              TEXT NOT NULL DEFAULT 'confirmed',
  html_link           TEXT,
  created_by          UUID REFERENCES users(id),
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_calendar_events_org_time ON calendar_events (organization_id, starts_at);
CREATE INDEX IF NOT EXISTS ix_calendar_events_contact ON calendar_events (contact_id);
CREATE INDEX IF NOT EXISTS ix_calendar_events_campaign ON calendar_events (campaign_id);

-- ---------- SMS (receive-only, via forwarder app) — see
-- migrations/015_sms_forwarder_devices.sql and services/integration-service
-- routes/smsWebhook.js + smsDevices.js. Each row is one Android phone
-- running a third-party forwarding app (e.g. SMS Forwarder) that POSTs
-- inbound texts to a per-device webhook URL; the token in that URL is the
-- only credential. Inbound texts land in the shared contacts/conversations/
-- messages tables above (channel_type='sms') like every other channel. ----------
CREATE TABLE IF NOT EXISTS sms_devices (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  label             TEXT NOT NULL,             -- e.g. "Front desk phone", "Rep #2 SIM"
  phone_number      TEXT,                       -- optional, cosmetic — not used for delivery
  webhook_token     TEXT NOT NULL UNIQUE,        -- 64-char random hex; the URL IS the credential
  connected         BOOLEAN NOT NULL DEFAULT true,
  last_message_at   TIMESTAMPTZ,
  message_count     INTEGER NOT NULL DEFAULT 0,
  last_raw_payload  JSONB,                       -- most recent payload received — critical for
                                                   -- debugging field-name mismatches
  locked_at         TIMESTAMPTZ,
  locked_by         UUID REFERENCES users(id) ON DELETE SET NULL,
  created_by        UUID REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_sms_devices_org ON sms_devices (organization_id);
CREATE UNIQUE INDEX IF NOT EXISTS ix_sms_devices_token ON sms_devices (webhook_token);

-- ---------- Ecommerce & Revenue ----------
CREATE TABLE IF NOT EXISTS ecommerce_orders (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id),
  amount          NUMERIC,
  payment_type    TEXT,                    -- cod | prepaid
  status          TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS carts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id),
  value           NUMERIC,
  recovered       BOOLEAN DEFAULT false,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS recovery_flows (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  name            TEXT,
  steps           JSONB DEFAULT '[]'::jsonb,
  active          BOOLEAN DEFAULT true
);

-- ---------- Analytics ----------
CREATE TABLE IF NOT EXISTS analytics_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  event_type      TEXT,
  payload         JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Notifications ----------
CREATE TABLE IF NOT EXISTS notifications (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  user_id         UUID REFERENCES users(id),
  title           TEXT,
  body            TEXT,
  read            BOOLEAN DEFAULT false,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Billing ----------
CREATE TABLE IF NOT EXISTS subscriptions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  plan            TEXT,
  status          TEXT DEFAULT 'active',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invoices (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id       UUID REFERENCES organizations(id) ON DELETE CASCADE,
  amount                NUMERIC(14,2),
  currency              TEXT NOT NULL DEFAULT 'INR',
  status                TEXT DEFAULT 'draft',
  billing_period_start  DATE,
  billing_period_end    DATE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- API / Webhooks / Audit ----------
CREATE TABLE IF NOT EXISTS api_keys (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  key_hash        TEXT NOT NULL,
  label           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS webhooks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  url             TEXT NOT NULL,
  event           TEXT,
  active          BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  user_id         UUID REFERENCES users(id),
  action          TEXT,
  meta            JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_conv_org ON conversations(organization_id, status);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_type ON messages(conversation_id, message_type);
CREATE INDEX IF NOT EXISTS idx_contacts_org ON contacts(organization_id);

-- ---------- Lead Automation Module (Playbook Engine) ----------
CREATE TABLE IF NOT EXISTS playbooks (
  id                TEXT PRIMARY KEY,
  organization_id   UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name              TEXT NOT NULL,
  channels          TEXT[] NOT NULL DEFAULT '{}',
  playbook_type     TEXT NOT NULL DEFAULT 'standard'
                      CHECK (playbook_type IN ('standard','default','fallback','gen_ai_default','transfer','unsubscribe')),
  trigger_keywords  TEXT[] NOT NULL DEFAULT '{}',
  status            TEXT NOT NULL DEFAULT 'draft'
                      CHECK (status IN ('draft','active','paused','archived')),
  version           INT NOT NULL DEFAULT 1,
  entry_node_id     TEXT NOT NULL,
  global_limits     JSONB NOT NULL DEFAULT '{}'::jsonb,
  nodes             JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_playbooks_org_status ON playbooks(organization_id, status);
CREATE INDEX IF NOT EXISTS idx_playbooks_org_type_status ON playbooks(organization_id, playbook_type, status);
CREATE INDEX IF NOT EXISTS idx_playbooks_channels_gin ON playbooks USING GIN (channels);

-- campaigns.flow_playbook_id (020_bulk_campaigns.sql), added here rather
-- than inline on campaigns' own CREATE TABLE further up because playbooks
-- didn't exist yet at that point in a single-pass load. Type is TEXT, not
-- UUID, to match playbooks.id above (playbook ids are human-authored
-- slugs/flow-builder ids, not generated UUIDs).
ALTER TABLE campaigns ADD COLUMN IF NOT EXISTS flow_playbook_id TEXT REFERENCES playbooks(id);

CREATE TABLE IF NOT EXISTS conversation_sessions (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playbook_id           TEXT NOT NULL REFERENCES playbooks(id) ON DELETE CASCADE,
  organization_id       UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  channel               TEXT NOT NULL
                          CHECK (channel IN ('whatsapp','instagram','messenger','google_reviews','linkedin_comments')),
  contact_external_id   TEXT NOT NULL,
  current_node_id       TEXT NOT NULL,
  status                TEXT NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','completed','handed_off','expired')),
  variables             JSONB NOT NULL DEFAULT '{}'::jsonb,
  path_history          JSONB NOT NULL DEFAULT '[]'::jsonb,
  message_count         INT NOT NULL DEFAULT 0,
  started_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_interaction_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_conversation_sessions_active
  ON conversation_sessions (playbook_id, contact_external_id)
  WHERE status = 'active';

CREATE INDEX IF NOT EXISTS idx_conversation_sessions_lookup
  ON conversation_sessions (organization_id, channel, contact_external_id, status);
CREATE INDEX IF NOT EXISTS idx_conversation_sessions_last_interaction
  ON conversation_sessions (last_interaction_at);

CREATE TABLE IF NOT EXISTS throttle_counters (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scope_key         TEXT NOT NULL,
  bucket            TEXT NOT NULL,
  limit_type        TEXT NOT NULL
                      CHECK (limit_type IN ('conversation_count','message_count','unique_contact_count')),
  count             INT NOT NULL DEFAULT 0,
  seen_contact_ids  TEXT[] NOT NULL DEFAULT '{}',
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (scope_key, bucket, limit_type)
);

-- ---------- LinkedIn Integration ----------
CREATE TABLE IF NOT EXISTS oauth_states (
  state       TEXT PRIMARY KEY,
  used        BOOLEAN NOT NULL DEFAULT false,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS linkedin_connections (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           TEXT NOT NULL UNIQUE,
  access_token      TEXT NOT NULL,
  refresh_token     TEXT,
  expires_at        TIMESTAMPTZ NOT NULL,
  linkedin_user_id  TEXT,
  linkedin_org_urn  TEXT,
  display_name      TEXT,
  granted_scopes    TEXT[] NOT NULL DEFAULT '{}',
  status            TEXT NOT NULL DEFAULT 'healthy',
  last_error        TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS linkedin_lead_forms (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         TEXT NOT NULL,
  form_urn        TEXT NOT NULL,
  name            TEXT,
  new_lead_count  INT NOT NULL DEFAULT 0,
  last_synced_at  TIMESTAMPTZ,
  sync_status     TEXT NOT NULL DEFAULT 'synced',
  auto_approve    BOOLEAN NOT NULL DEFAULT false,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, form_urn)
);

CREATE TABLE IF NOT EXISTS linkedin_leads (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  linkedin_lead_id  TEXT NOT NULL UNIQUE,
  form_urn          TEXT NOT NULL,
  submitted_at      TIMESTAMPTZ,
  form_response     JSONB NOT NULL DEFAULT '{}',
  status            TEXT NOT NULL DEFAULT 'received',
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS linkedin_campaigns (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               TEXT NOT NULL,
  campaign_urn          TEXT NOT NULL,
  name                  TEXT,
  sync_status           TEXT NOT NULL DEFAULT 'synced',
  last_synced_at        TIMESTAMPTZ,
  spend_to_date_cents   BIGINT NOT NULL DEFAULT 0,
  error_code            TEXT,
  error_detail          TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, campaign_urn)
);

CREATE TABLE IF NOT EXISTS linkedin_campaign_metrics (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         TEXT NOT NULL,
  campaign_urn    TEXT NOT NULL,
  date            DATE NOT NULL,
  impressions     INT NOT NULL DEFAULT 0,
  clicks          INT NOT NULL DEFAULT 0,
  ctr             NUMERIC NOT NULL DEFAULT 0,
  spend_cents     BIGINT NOT NULL DEFAULT 0,
  leads           INT NOT NULL DEFAULT 0,
  UNIQUE (user_id, campaign_urn, date)
);

CREATE TABLE IF NOT EXISTS linkedin_conversion_config (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               TEXT NOT NULL UNIQUE,
  conversion_rule_urn   TEXT NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS linkedin_conversion_events (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               TEXT NOT NULL,
  event_id              TEXT NOT NULL,
  conversion_rule_urn   TEXT NOT NULL,
  email_hash            TEXT NOT NULL,
  value_cents           BIGINT,
  currency_code         TEXT,
  lead_id               UUID,
  status                TEXT NOT NULL DEFAULT 'sent',
  error_detail          TEXT,
  sent_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, event_id)
);

CREATE INDEX IF NOT EXISTS idx_linkedin_conversion_events_user_sent ON linkedin_conversion_events (user_id, sent_at DESC);

CREATE TABLE IF NOT EXISTS linkedin_posts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           TEXT NOT NULL,
  post_urn          TEXT NOT NULL,
  author_urn        TEXT NOT NULL,
  as_organization   BOOLEAN NOT NULL DEFAULT false,
  text              TEXT NOT NULL,
  status            TEXT NOT NULL DEFAULT 'published',
  media_urn         TEXT,
  media_type        TEXT,
  metrics           JSONB NOT NULL DEFAULT '{}',
  comments_cache    JSONB NOT NULL DEFAULT '[]',
  comments_synced_at TIMESTAMPTZ,
  last_synced_at    TIMESTAMPTZ,
  published_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, post_urn)
);

CREATE INDEX IF NOT EXISTS idx_linkedin_posts_user_created ON linkedin_posts (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS linkedin_organizations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         TEXT NOT NULL,
  org_urn         TEXT,
  description     TEXT,
  logo_url        TEXT,
  follower_count  INT,
  last_synced_at  TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS linkedin_approvals (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           TEXT NOT NULL,
  type              TEXT NOT NULL,
  title             TEXT NOT NULL,
  detail            TEXT,
  status            TEXT NOT NULL DEFAULT 'pending',
  payload_preview   JSONB NOT NULL DEFAULT '{}',
  decision_note     TEXT,
  decided_by        TEXT,
  decided_at        TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS linkedin_sync_logs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     TEXT NOT NULL,
  module      TEXT NOT NULL,
  event       TEXT NOT NULL,
  status      TEXT NOT NULL,
  actor_type  TEXT NOT NULL DEFAULT 'system',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_linkedin_approvals_user_status ON linkedin_approvals (user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_linkedin_sync_logs_user_created ON linkedin_sync_logs (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_linkedin_campaign_metrics_lookup ON linkedin_campaign_metrics (user_id, campaign_urn, date);
-- =====================================================================
-- Platform Super Admin: multi-tenant governance + wallet billing
-- (folded in from 022_super_admin_billing.sql so a fresh non-Docker
-- setup via scripts/setup-db.sh — which only loads schema.sql, not the
-- migrations/ folder — gets these tables too. See that migration file
-- for the full design rationale.)
-- =====================================================================

CREATE TABLE IF NOT EXISTS platform_admins (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  email         TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'active', -- active | disabled
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Channel subscription billing (see infra/db/migrations/025_channel_subscription_billing.sql for full rationale) ----------

-- Our own price catalogue per channel — platform-admin managed, not per-org.
CREATE TABLE IF NOT EXISTS channel_plans (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_type    TEXT NOT NULL CHECK (channel_type IN
                    ('whatsapp','messenger','instagram','linkedin','email','sms')),
  our_fee_amount  NUMERIC(14,2) NOT NULL CHECK (our_fee_amount >= 0),
  currency        TEXT NOT NULL DEFAULT 'INR',
  billing_period  TEXT NOT NULL DEFAULT 'monthly' CHECK (billing_period IN ('monthly','annual')),
  active          BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_channel_plans_active_channel_period
  ON channel_plans (channel_type, billing_period) WHERE active;

-- Which channels an org is subscribed to, at what (snapshotted) price.
CREATE TABLE IF NOT EXISTS organization_channel_subscriptions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  channel_type    TEXT NOT NULL CHECK (channel_type IN
                    ('whatsapp','messenger','instagram','linkedin','email','sms')),
  channel_plan_id UUID REFERENCES channel_plans(id),
  price_amount    NUMERIC(14,2) NOT NULL CHECK (price_amount >= 0),
  currency        TEXT NOT NULL DEFAULT 'INR',
  billing_period  TEXT NOT NULL DEFAULT 'monthly' CHECK (billing_period IN ('monthly','annual')),
  status          TEXT NOT NULL DEFAULT 'pending_payment' CHECK (status IN ('pending_payment','active','paused','cancelled')),
  trial_ends_at   TIMESTAMPTZ,
  started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  cancelled_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_org_channel_sub_live
  ON organization_channel_subscriptions (organization_id, channel_type)
  WHERE status IN ('pending_payment','active','paused');
CREATE INDEX IF NOT EXISTS idx_org_channel_sub_org
  ON organization_channel_subscriptions (organization_id);

-- Meta's rate card (per channel_type/category/recipient country) — the
-- source of truth for WhatsApp usage pass-through. Never hardcode these
-- rates in application code; Meta revises them roughly every 6 months.
CREATE TABLE IF NOT EXISTS meta_rate_cards (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_type    TEXT NOT NULL CHECK (channel_type IN ('whatsapp','messenger','instagram')),
  category        TEXT NOT NULL CHECK (category IN ('marketing','utility','authentication','service')),
  country_code    TEXT NOT NULL DEFAULT '*',
  meta_rate       NUMERIC(14,4) NOT NULL CHECK (meta_rate >= 0),
  currency        TEXT NOT NULL DEFAULT 'INR',
  gst_percent     NUMERIC(5,2) NOT NULL DEFAULT 18.00,
  bsp_markup      NUMERIC(14,4) NOT NULL DEFAULT 0,
  effective_from  DATE NOT NULL DEFAULT CURRENT_DATE,
  active          BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_meta_rate_cards_lookup
  ON meta_rate_cards (channel_type, category, country_code, effective_from DESC) WHERE active;

-- SMS rate card — kept separate from meta_rate_cards (not a Meta product,
-- has its own compliance fields tracked alongside cost in sms_usage_charges).
CREATE TABLE IF NOT EXISTS sms_rate_cards (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_type      TEXT NOT NULL CHECK (route_type IN ('promotional','transactional','otp')),
  per_sms_rate    NUMERIC(14,4) NOT NULL CHECK (per_sms_rate >= 0),
  currency        TEXT NOT NULL DEFAULT 'INR',
  gst_percent     NUMERIC(5,2) NOT NULL DEFAULT 18.00,
  effective_from  DATE NOT NULL DEFAULT CURRENT_DATE,
  active          BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sms_rate_cards_lookup
  ON sms_rate_cards (route_type, effective_from DESC) WHERE active;

-- The % markup we add on top of Meta's/SMS's actual cost. organization_id
-- NULL = platform-wide default; a specific org can get its own override row.
CREATE TABLE IF NOT EXISTS billing_markup_config (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID REFERENCES organizations(id) ON DELETE CASCADE,
  markup_percent    NUMERIC(5,2) NOT NULL DEFAULT 0 CHECK (markup_percent >= 0),
  updated_by_admin  UUID REFERENCES platform_admins(id),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_billing_markup_default
  ON billing_markup_config ((organization_id IS NULL)) WHERE organization_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_billing_markup_org
  ON billing_markup_config (organization_id) WHERE organization_id IS NOT NULL;

-- WhatsApp campaign billing ledger — reserve (pre-send hold) → settle
-- (post-send reconcile to actual delivered count) → charge. See
-- campaign-service/src/whatsappBilling.js.
CREATE TABLE IF NOT EXISTS whatsapp_billing_ledger (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id       UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  entry_type            TEXT NOT NULL CHECK (entry_type IN ('reservation','charge','refund')),
  status                TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','settled','released')),
  amount                NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
  currency              TEXT NOT NULL DEFAULT 'INR',
  campaign_id           UUID REFERENCES campaigns(id) ON DELETE SET NULL,
  category              TEXT CHECK (category IN ('marketing','utility','authentication','service')),
  recipient_count       INT,
  reserved_by_entry_id  UUID REFERENCES whatsapp_billing_ledger(id),
  note                  TEXT,
  settled_at            TIMESTAMPTZ,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_ledger_org_created
  ON whatsapp_billing_ledger (organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_whatsapp_ledger_campaign
  ON whatsapp_billing_ledger (campaign_id) WHERE campaign_id IS NOT NULL;

-- Per-message Meta usage audit trail — feeds invoice_line_items.
CREATE TABLE IF NOT EXISTS meta_usage_charges (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  channel_type      TEXT NOT NULL CHECK (channel_type IN ('whatsapp','messenger','instagram')),
  category          TEXT NOT NULL CHECK (category IN ('marketing','utility','authentication','service')),
  recipient_country TEXT,
  meta_rate         NUMERIC(14,4) NOT NULL,
  markup_percent    NUMERIC(5,2) NOT NULL DEFAULT 0,
  bsp_markup        NUMERIC(14,4) NOT NULL DEFAULT 0,
  gst_amount        NUMERIC(14,2) NOT NULL DEFAULT 0,
  quantity          INT NOT NULL CHECK (quantity > 0),
  total_amount      NUMERIC(14,2) NOT NULL,
  currency          TEXT NOT NULL DEFAULT 'INR',
  period            DATE NOT NULL,
  campaign_id       UUID REFERENCES campaigns(id) ON DELETE SET NULL,
  reference_id      TEXT,
  invoiced          BOOLEAN NOT NULL DEFAULT false,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_meta_usage_org_period ON meta_usage_charges (organization_id, period);
CREATE INDEX IF NOT EXISTS idx_meta_usage_campaign ON meta_usage_charges (campaign_id) WHERE campaign_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_meta_usage_uninvoiced ON meta_usage_charges (organization_id) WHERE NOT invoiced;

-- SMS usage audit trail — kept separate from meta_usage_charges (different
-- compliance fields: DLT template id, sender id).
CREATE TABLE IF NOT EXISTS sms_usage_charges (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  route_type        TEXT NOT NULL CHECK (route_type IN ('promotional','transactional','otp')),
  per_sms_rate      NUMERIC(14,4) NOT NULL,
  markup_percent    NUMERIC(5,2) NOT NULL DEFAULT 0,
  gst_amount        NUMERIC(14,2) NOT NULL DEFAULT 0,
  quantity          INT NOT NULL CHECK (quantity > 0),
  total_amount      NUMERIC(14,2) NOT NULL,
  currency          TEXT NOT NULL DEFAULT 'INR',
  period            DATE NOT NULL,
  campaign_id       UUID REFERENCES campaigns(id) ON DELETE SET NULL,
  dlt_template_id   TEXT,
  sender_id         TEXT,
  reference_id      TEXT,
  invoiced          BOOLEAN NOT NULL DEFAULT false,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sms_usage_org_period ON sms_usage_charges (organization_id, period);
CREATE INDEX IF NOT EXISTS idx_sms_usage_campaign ON sms_usage_charges (campaign_id) WHERE campaign_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sms_usage_uninvoiced ON sms_usage_charges (organization_id) WHERE NOT invoiced;

-- Itemized invoice lines — indirectly scoped via invoice_id -> invoices.organization_id.
CREATE TABLE IF NOT EXISTS invoice_line_items (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id    UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  type          TEXT NOT NULL CHECK (type IN
                  ('saas_channel_fee','meta_passthrough','sms_passthrough','bsp_markup','other')),
  channel_type  TEXT,
  description   TEXT NOT NULL,
  quantity      INT NOT NULL DEFAULT 1,
  unit_amount   NUMERIC(14,2) NOT NULL,
  total_amount  NUMERIC(14,2) NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invoice_line_items_invoice ON invoice_line_items (invoice_id);

CREATE TABLE IF NOT EXISTS wallets (
  organization_id       UUID PRIMARY KEY REFERENCES organizations(id) ON DELETE CASCADE,
  balance               NUMERIC(14,2) NOT NULL DEFAULT 0,
  lifetime_deposited    NUMERIC(14,2) NOT NULL DEFAULT 0,
  lifetime_spent        NUMERIC(14,2) NOT NULL DEFAULT 0,
  low_balance_threshold NUMERIC(14,2) NOT NULL DEFAULT 100,
  credit_rates          JSONB NOT NULL DEFAULT '{"whatsapp_message": 1, "workflow_execution": 1}'::jsonb,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wallet_transactions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  type              TEXT NOT NULL CHECK (type IN ('RECHARGE', 'USAGE_DEDUCTION', 'ADJUSTMENT')),
  amount            NUMERIC(14,2) NOT NULL,
  balance_after     NUMERIC(14,2) NOT NULL,
  reference_id      TEXT,
  description       TEXT,
  action_key        TEXT,
  created_by_user   UUID REFERENCES users(id),
  created_by_admin  UUID REFERENCES platform_admins(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wallet_tx_org_created ON wallet_transactions (organization_id, created_at DESC);

-- Generic payment-gateway ledger (billing-service). Covers wallet top-ups
-- (funds campaigns/broadcasts via wallet_transactions), product-platform
-- checkout (ecommerce_orders), and staff-recorded walk-in sales — cash or
-- a Razorpay Payment Link/QR — all in one place so there's a single
-- reconciliation view instead of one per gateway flow.
CREATE TABLE IF NOT EXISTS payments (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id     UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  purpose             TEXT NOT NULL CHECK (purpose IN ('WALLET_RECHARGE', 'ECOMMERCE_ORDER', 'WALKIN_SALE', 'INVOICE_SETTLEMENT')),
  reference_id        UUID,                    -- ecommerce_orders.id for ECOMMERCE_ORDER / WALKIN_SALE
  contact_id          UUID REFERENCES contacts(id),
  amount              NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  currency            TEXT NOT NULL DEFAULT 'INR',
  method              TEXT,                    -- razorpay | cash | manual
  status              TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'pending', 'paid', 'failed', 'refunded')),
  gateway             TEXT DEFAULT 'razorpay',
  gateway_order_id    TEXT,                    -- Razorpay order_id or payment_link_id
  gateway_payment_id  TEXT,                    -- Razorpay payment_id, set once captured
  gateway_signature   TEXT,
  notes               JSONB,
  created_by_user     UUID REFERENCES users(id),
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_payments_org_created ON payments (organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payments_gateway_order_id ON payments (gateway_order_id);
-- Partial unique index (not a plain UNIQUE constraint) because most rows
-- have gateway_payment_id = NULL until captured, and NULLs must not
-- collide with each other under a normal UNIQUE.
CREATE UNIQUE INDEX IF NOT EXISTS uq_payments_gateway_payment_id ON payments (gateway_payment_id) WHERE gateway_payment_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS feature_flags (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  flag_key        TEXT NOT NULL,
  enabled         BOOLEAN NOT NULL DEFAULT false,
  updated_by_admin UUID REFERENCES platform_admins(id),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, flag_key)
);

CREATE TABLE IF NOT EXISTS attachments (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  owner_type      TEXT NOT NULL,
  owner_id        UUID NOT NULL,
  file_url        TEXT NOT NULL,
  mime_type       TEXT,
  size_bytes      INT,
  uploaded_by     UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_attachments_owner ON attachments (organization_id, owner_type, owner_id);

-- ---------- Products / Offers ----------
-- Backs services/campaign-service/src/products.js. This table (and its
-- migrations/023_products.sql source) was never folded into schema.sql, so
-- /products 500'd on every call against a fresh database — this block is
-- that migration, verbatim, applied here instead.
CREATE TABLE IF NOT EXISTS products (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

  name              TEXT NOT NULL,
  category          TEXT,                       -- e.g. saas, service, course, physical
  status            TEXT NOT NULL DEFAULT 'active',  -- active | draft | archived
  tagline           TEXT,                       -- one-line positioning
  description       TEXT,

  -- Pricing kept as text + optional numeric: real offers are often "from
  -- Rs. 4,999/seat/mo" or "custom", which a strict numeric column cannot hold,
  -- but a numeric is still wanted for sorting/analytics when one exists.
  price_display     TEXT,
  price_amount      NUMERIC(12,2),
  currency          TEXT DEFAULT 'INR',
  billing_period    TEXT,                       -- monthly | annual | one_time | usage

  -- The marketing substance. Arrays rather than prose so the agent can use
  -- them individually (one value prop per ad, one objection per FAQ answer).
  value_props       TEXT[] NOT NULL DEFAULT '{}',
  target_segments   TEXT[] NOT NULL DEFAULT '{}',
  objections        TEXT[] NOT NULL DEFAULT '{}',
  differentiators   TEXT[] NOT NULL DEFAULT '{}',
  keywords          TEXT[] NOT NULL DEFAULT '{}',

  -- Compliance/tone guardrails the agent must respect when writing for this
  -- offer (e.g. "never promise guaranteed placement").
  tone              TEXT,
  claims_to_avoid   TEXT[] NOT NULL DEFAULT '{}',

  landing_url       TEXT,
  is_primary        BOOLEAN NOT NULL DEFAULT false,  -- the default offer for new campaigns

  created_by        UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_products_org        ON products (organization_id);
CREATE INDEX IF NOT EXISTS ix_products_org_status ON products (organization_id, status);

-- At most one primary offer per organization. Partial unique index rather
-- than a constraint so archiving/unsetting stays a plain UPDATE.
CREATE UNIQUE INDEX IF NOT EXISTS ux_products_one_primary
  ON products (organization_id) WHERE is_primary;

-- Campaigns and calendar events can point at the offer they promote, so
-- performance is attributable per product. Nullable: plenty of sends are not
-- offer-specific.
ALTER TABLE campaigns       ADD COLUMN IF NOT EXISTS product_id UUID REFERENCES products(id) ON DELETE SET NULL;
ALTER TABLE calendar_events ADD COLUMN IF NOT EXISTS product_id UUID REFERENCES products(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS ix_campaigns_product ON campaigns (product_id) WHERE product_id IS NOT NULL;

-- ---------- Message Templates (Template Creation module) ----------
-- Backs services/campaign-service/src/templates.js and the sidebar's
-- Automation > Templates screen (frontend/src/app/app/campaigns/templates).
-- A local template library with its own review/approval workflow — distinct
-- from integration-service's POST /whatsapp/send-template, which sends a
-- message using a template name already approved on Meta's side. The two
-- meet at send time: campaign-service resolves a campaigns.template_id to
-- this table's `name` + `header`/`body`/`buttons` and hands that name to
-- integration-service's send-template call.
CREATE TABLE IF NOT EXISTS message_templates (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

  name              TEXT NOT NULL,               -- auto-slugified, e.g. college_broadcast_17_6_26
  category          TEXT NOT NULL DEFAULT 'MARKETING',   -- MARKETING | UTILITY | AUTHENTICATION
  language          TEXT NOT NULL DEFAULT 'en_US',
  channels          TEXT[] NOT NULL DEFAULT '{WHATSAPP}', -- WHATSAPP | RCS | SMS | EMAIL (multi-tag)
  status            TEXT NOT NULL DEFAULT 'PENDING',      -- PENDING | APPROVED | REJECTED

  header_type       TEXT NOT NULL DEFAULT 'NONE',   -- NONE | TEXT | IMAGE | VIDEO | DOCUMENT
  header_text       TEXT,
  header_media_url  TEXT,

  body              TEXT NOT NULL DEFAULT '',
  body_variables    JSONB NOT NULL DEFAULT '{}',    -- {"1": "example value", "2": "..."}
  footer            TEXT,                            -- max 60 chars, enforced app-side

  -- Array of { type: 'QUICK_REPLY'|'PHONE_NUMBER'|'URL', text, value? }
  buttons           JSONB NOT NULL DEFAULT '[]',

  created_by        UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_message_templates_org         ON message_templates (organization_id);
CREATE INDEX IF NOT EXISTS ix_message_templates_org_status  ON message_templates (organization_id, status);
CREATE INDEX IF NOT EXISTS ix_message_templates_channels    ON message_templates USING GIN (channels);

-- campaigns.template_id, added here rather than inline on campaigns' own
-- CREATE TABLE further up because message_templates didn't exist yet at
-- that point in a single-pass load (same reasoning as flow_playbook_id
-- above). Nullable — every non-WhatsApp broadcast, and any WhatsApp one
-- written as free text, still just uses campaigns.message_body directly.
ALTER TABLE campaigns ADD COLUMN IF NOT EXISTS template_id UUID REFERENCES message_templates(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS ix_campaigns_template ON campaigns (template_id) WHERE template_id IS NOT NULL;

CREATE OR REPLACE FUNCTION create_wallet_for_new_org() RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO wallets (organization_id) VALUES (NEW.id)
  ON CONFLICT (organization_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_create_wallet_for_new_org ON organizations;
CREATE TRIGGER trg_create_wallet_for_new_org
  AFTER INSERT ON organizations
  FOR EACH ROW EXECUTE FUNCTION create_wallet_for_new_org();