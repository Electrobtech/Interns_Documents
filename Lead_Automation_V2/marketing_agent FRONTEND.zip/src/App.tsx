import { useState, useEffect, useRef } from 'react'
import { ToastProvider, useToast } from './components/ui/Toast'
import Dashboard from './components/marketing/Dashboard'
import Campaigns from './components/marketing/Campaigns'
import Broadcasts from './components/marketing/Broadcasts'
import Audience from './components/marketing/Audience'
import ContentStudio from './components/marketing/ContentStudio'
import SEO from './components/marketing/SEO'
import AEO from './components/marketing/AEO'
import CompetitorAnalysis from './components/marketing/CompetitorAnalysis'
import MarketingCalendar from './components/marketing/MarketingCalendar'
import Analytics from './components/marketing/Analytics'
import Reports from './components/marketing/Reports'
import AssetsLibrary from './components/marketing/AssetsLibrary'
import KnowledgeBase from './components/marketing/KnowledgeBase'
import Settings from './components/marketing/Settings'
import {
  LayoutDashboard, Megaphone, Radio, Users, Pen, SearchIcon, Zap,
  BarChart2, Calendar, PieChart, FileBarChart, Layers, FolderOpen, BookOpen,
  Settings as SettingsIcon, ChevronRight, Bell, HelpCircle,
  Moon, Sun, Command, Bot, TrendingUp, Mail, Globe, X, AlignLeft,
  Sparkles, ChevronDown, RefreshCw, Send, ArrowRight, Cpu,
  Target, DollarSign, MessageSquare, BarChart3, Wand2, ArrowUpRight,
} from 'lucide-react'

type Page = 'dashboard' | 'campaigns' | 'broadcasts' | 'audience' | 'content' | 'seo' | 'aeo' | 'competitor' | 'calendar' | 'analytics' | 'reports' | 'templates' | 'assets' | 'knowledge' | 'settings'

const NAV_GROUPS = [
  {
    label: 'Core',
    items: [
      { id: 'dashboard' as Page, label: 'Dashboard', icon: LayoutDashboard },
      { id: 'campaigns' as Page, label: 'Campaigns', icon: Megaphone },
      { id: 'broadcasts' as Page, label: 'Broadcasts', icon: Radio },
      { id: 'audience' as Page, label: 'Audience', icon: Users },
    ],
  },
  {
    label: 'Create',
    items: [
      { id: 'content' as Page, label: 'Content Studio', icon: Pen },
      { id: 'templates' as Page, label: 'Templates', icon: Layers },
      { id: 'assets' as Page, label: 'Assets Library', icon: FolderOpen },
    ],
  },
  {
    label: 'Optimize',
    items: [
      { id: 'seo' as Page, label: 'SEO', icon: SearchIcon },
      { id: 'aeo' as Page, label: 'AEO', icon: Zap },
      { id: 'competitor' as Page, label: 'Competitor Analysis', icon: BarChart2 },
    ],
  },
  {
    label: 'Measure',
    items: [
      { id: 'calendar' as Page, label: 'Marketing Calendar', icon: Calendar },
      { id: 'analytics' as Page, label: 'Analytics', icon: PieChart },
      { id: 'reports' as Page, label: 'Reports', icon: FileBarChart },
    ],
  },
  {
    label: 'Manage',
    items: [
      { id: 'knowledge' as Page, label: 'Knowledge Base', icon: BookOpen },
      { id: 'settings' as Page, label: 'Settings', icon: SettingsIcon },
    ],
  },
]

const PAGE_LABELS: Record<Page, string> = {
  dashboard: 'Dashboard', campaigns: 'Campaigns', broadcasts: 'Broadcasts',
  audience: 'Audience', content: 'Content Studio', seo: 'SEO', aeo: 'AEO',
  competitor: 'Competitor Analysis', calendar: 'Marketing Calendar',
  analytics: 'Analytics', reports: 'Reports', templates: 'Templates',
  assets: 'Assets Library', knowledge: 'Knowledge Base', settings: 'Settings',
}

const AI_PROMPTS = [
  'Improve CTR on Facebook campaigns',
  'Build a lookalike audience from converters',
  'Generate webinar campaign copy',
  'Analyze competitor SEO gap',
  'Optimize WhatsApp broadcast timing',
  'Predict Q3 revenue from current trend',
  'Suggest budget reallocation for ROAS',
  'Write 3 ad headline variants',
]

export default function App() {
  return (
    <ToastProvider>
      <Shell />
    </ToastProvider>
  )
}

function Shell() {
  const { show } = useToast()
  const [page, setPage] = useState<Page>('dashboard')
  const [collapsed, setCollapsed] = useState(false)
  const [darkMode, setDarkMode] = useState(true)
  const [cmdOpen, setCmdOpen] = useState(false)
  const [notifsOpen, setNotifsOpen] = useState(false)
  const [copilotOpen, setCopilotOpen] = useState(true)
  const [copilotMsg, setCopilotMsg] = useState('')
  const [copilotHistory, setCopilotHistory] = useState<{ role: 'user' | 'ai'; text: string }[]>([
    { role: 'ai', text: 'Hi! I\'m your Marketing Copilot. Ask me anything — I can optimize campaigns, generate content, analyze competitors, and predict performance.' },
  ])
  const [typing, setTyping] = useState(false)
  const [pageKey, setPageKey] = useState(0)
  const msgEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setCmdOpen(true) }
      if (e.key === 'Escape') { setCmdOpen(false); setNotifsOpen(false) }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  useEffect(() => { msgEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [copilotHistory, typing])

  const navigate = (p: Page) => { setPage(p); setPageKey(k => k + 1); setCmdOpen(false) }

  const sendCopilot = () => {
    if (!copilotMsg.trim()) return
    const userMsg = copilotMsg.trim()
    setCopilotHistory(h => [...h, { role: 'user', text: userMsg }])
    setCopilotMsg('')
    setTyping(true)
    setTimeout(() => {
      setTyping(false)
      const responses = [
        `Based on your current campaigns, I recommend increasing the WhatsApp Retargeting budget by ₹800/day. This campaign has a 172x ROAS and is currently budget-limited. Projected additional revenue: **₹42,000/week**.`,
        `I analyzed your top-performing segments. Your best audience is "IT Professionals aged 28–40 in Tier 1 cities" with 94% quality score. Want me to create a lookalike based on your top 500 converters?`,
        `Your CTR dropped 8% this week. The main cause is creative fatigue — your Facebook ads have been running for 47 days. I've drafted 3 new headline variants. Shall I apply them?`,
        `Competitor alert: HubSpot just launched a WhatsApp integration. They're targeting your core segment with a ₹0 free tier. I recommend an immediate pricing page update and a comparison landing page.`,
      ]
      const reply = responses[Math.floor(Math.random() * responses.length)]
      setCopilotHistory(h => [...h, { role: 'ai', text: reply }])
    }, 1400)
  }

  const renderPage = () => {
    const pages: Record<Page, React.ReactNode> = {
      dashboard: <Dashboard onNavigate={navigate} />,
      campaigns: <Campaigns />,
      broadcasts: <Broadcasts />,
      audience: <Audience />,
      content: <ContentStudio />,
      seo: <SEO />,
      aeo: <AEO />,
      competitor: <CompetitorAnalysis />,
      calendar: <MarketingCalendar />,
      analytics: <Analytics />,
      reports: <Reports />,
      templates: <TemplatesPlaceholder />,
      assets: <AssetsLibrary />,
      knowledge: <KnowledgeBase />,
      settings: <Settings />,
    }
    return <div key={pageKey} className="page-enter" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>{pages[page]}</div>
  }

  const allItems = NAV_GROUPS.flatMap(g => g.items)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: 'var(--bg)', color: 'var(--text)', overflow: 'hidden' }}>

      {/* ─── TOP HEADER ─────────────────────────────────────────────── */}
      <header style={{ height: 52, background: 'rgba(10,10,22,0.85)', backdropFilter: 'blur(20px)', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', padding: '0 16px', gap: 8, flexShrink: 0, zIndex: 200 }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginRight: 4 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--shadow-ai)' }}>
            <Cpu size={13} color="#fff" strokeWidth={2.5} />
          </div>
          {!collapsed && <span style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, letterSpacing: '-0.02em' }} className="ai-text">LeadOS</span>}
        </div>

        {/* Breadcrumb */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, marginLeft: 4 }}>
          <span style={{ color: 'var(--text-3)', fontSize: 12 }}>AI Agents</span>
          <ChevronRight size={11} color="var(--text-4)" />
          <span style={{ color: 'var(--primary)', fontSize: 12, fontWeight: 600 }}>Marketing Agent</span>
          <ChevronRight size={11} color="var(--text-4)" />
          <span style={{ color: 'var(--text-2)', fontSize: 12 }}>{PAGE_LABELS[page]}</span>
        </div>

        <div style={{ flex: 1 }} />

        {/* Search */}
        <button onClick={() => setCmdOpen(true)} style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 10, padding: '6px 14px', fontSize: 12, color: 'var(--text-3)', cursor: 'pointer', minWidth: 220, transition: 'all 0.15s' }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-2)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-2)' }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-3)' }}>
          <SearchIcon size={12} />
          <span>Search anything…</span>
          <kbd style={{ marginLeft: 'auto', fontSize: 10, background: 'var(--surface-3)', border: '1px solid var(--border)', padding: '2px 6px', borderRadius: 4, color: 'var(--text-3)', fontFamily: 'var(--font-body)' }}>⌘K</kbd>
        </button>

        {/* Workspace */}
        <button style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '5px 10px', fontSize: 12, color: 'var(--text-2)', cursor: 'pointer' }}>
          <div style={{ width: 16, height: 16, borderRadius: 4, background: 'var(--ai-gradient)', flexShrink: 0 }} />
          Acme Inc
          <ChevronDown size={11} color="var(--text-3)" />
        </button>

        {/* Icons */}
        <div style={{ display: 'flex', gap: 2 }}>
          {[
            { icon: Bell, action: () => setNotifsOpen(o => !o), badge: true, tip: 'Notifications' },
            { icon: darkMode ? Moon : Sun, action: () => setDarkMode(d => !d), badge: false, tip: 'Theme' },
            { icon: HelpCircle, action: () => show('Help center coming soon', 'info'), badge: false, tip: 'Help' },
          ].map(({ icon: Icon, action, badge, tip }) => (
            <button key={tip} onClick={action} data-tooltip={tip} className="btn btn-icon" style={{ width: 32, height: 32, position: 'relative' }}>
              <Icon size={15} />
              {badge && <span style={{ position: 'absolute', top: 5, right: 5, width: 6, height: 6, borderRadius: '50%', background: 'var(--red)', border: '1.5px solid var(--bg)' }} />}
            </button>
          ))}
        </div>

        {/* Avatar */}
        <button onClick={() => show('Profile menu', 'info')} style={{ width: 30, height: 30, borderRadius: '50%', background: 'var(--primary-dim)', border: '1.5px solid var(--primary)', color: 'var(--primary)', fontSize: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-display)' }}>
          PS
        </button>

        {/* Copilot toggle */}
        <button onClick={() => setCopilotOpen(o => !o)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', background: copilotOpen ? 'var(--ai-gradient)' : 'var(--surface-2)', border: copilotOpen ? 'none' : '1px solid var(--border)', borderRadius: 8, fontSize: 12, fontWeight: 600, color: '#fff', cursor: 'pointer', transition: 'all 0.2s', boxShadow: copilotOpen ? 'var(--shadow-ai)' : 'none' }}>
          <Sparkles size={13} />
          {copilotOpen ? 'Copilot' : 'AI'}
        </button>
      </header>

      {/* ─── BODY ───────────────────────────────────────────────────── */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* ─── SIDEBAR ──────────────────────────────────────────────── */}
        <aside style={{ width: collapsed ? 56 : 220, background: 'var(--bg-subtle)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', flexShrink: 0, transition: 'width 0.22s var(--ease)', overflow: 'hidden', zIndex: 100 }}>
          {/* Collapse toggle */}
          <div style={{ padding: '10px 10px 8px', display: 'flex', justifyContent: collapsed ? 'center' : 'flex-end', flexShrink: 0 }}>
            <button onClick={() => setCollapsed(c => !c)} className="btn btn-icon" style={{ width: 28, height: 28 }}>
              <AlignLeft size={13} />
            </button>
          </div>

          {/* AI Agents section */}
          {!collapsed && (
            <div style={{ padding: '0 10px 6px' }}>
              <div style={{ padding: '6px 8px', marginBottom: 2 }}>
                <span className="label" style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                  <Bot size={10} /> AI AGENTS
                </span>
              </div>
              <div style={{ background: 'linear-gradient(135deg, rgba(99,102,241,0.12), rgba(168,85,247,0.08))', border: '1px solid rgba(99,102,241,0.2)', borderRadius: 10, padding: '8px 10px', marginBottom: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 24, height: 24, borderRadius: 6, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <TrendingUp size={12} color="#fff" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)' }}>Marketing Agent</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginTop: 1 }}>
                      <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--green)', flexShrink: 0 }} />
                      <span style={{ fontSize: 10, color: 'var(--text-3)' }}>Active</span>
                    </div>
                  </div>
                  <ChevronDown size={12} color="var(--text-4)" />
                </div>
              </div>
            </div>
          )}
          {collapsed && (
            <div style={{ padding: '0 10px 8px', display: 'flex', justifyContent: 'center' }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <TrendingUp size={14} color="#fff" />
              </div>
            </div>
          )}

          {/* Nav groups */}
          <div style={{ flex: 1, overflow: 'auto', padding: '0 8px 12px' }} className="scrollbar-hide">
            {NAV_GROUPS.map(group => (
              <div key={group.label} style={{ marginBottom: 4 }}>
                {!collapsed && (
                  <div style={{ padding: '8px 8px 4px' }}>
                    <span className="label" style={{ fontSize: 10 }}>{group.label}</span>
                  </div>
                )}
                {group.items.map(item => {
                  const Icon = item.icon
                  const active = page === item.id
                  return (
                    <button key={item.id} onClick={() => navigate(item.id)}
                      title={collapsed ? item.label : undefined}
                      style={{
                        display: 'flex', alignItems: 'center', gap: collapsed ? 0 : 9,
                        justifyContent: collapsed ? 'center' : 'flex-start',
                        width: '100%', padding: collapsed ? '9px' : '8px 10px',
                        background: active ? 'linear-gradient(135deg, rgba(99,102,241,0.18), rgba(168,85,247,0.10))' : 'transparent',
                        border: active ? '1px solid rgba(99,102,241,0.25)' : '1px solid transparent',
                        borderRadius: 9, fontSize: 13,
                        color: active ? 'var(--text)' : 'var(--text-3)',
                        cursor: 'pointer', textAlign: 'left', marginBottom: 2,
                        fontFamily: 'var(--font-body)', fontWeight: active ? 600 : 400,
                        transition: 'all 0.12s',
                      }}
                      onMouseEnter={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = 'var(--surface-3)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-2)' } }}
                      onMouseLeave={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = 'transparent'; (e.currentTarget as HTMLElement).style.color = 'var(--text-3)' } }}>
                      <Icon size={14} style={{ flexShrink: 0, opacity: active ? 1 : 0.7, color: active ? 'var(--primary)' : 'inherit' }} />
                      {!collapsed && <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.label}</span>}
                      {!collapsed && active && <div style={{ width: 4, height: 4, borderRadius: '50%', background: 'var(--primary)', marginLeft: 'auto', flexShrink: 0 }} />}
                    </button>
                  )
                })}
              </div>
            ))}
          </div>

          {/* Bottom user */}
          {!collapsed && (
            <div style={{ padding: '10px 12px', borderTop: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
              <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--primary-dim)', border: '1.5px solid rgba(99,102,241,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: 'var(--primary)', flexShrink: 0, fontFamily: 'var(--font-display)' }}>PS</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Priya Sharma</div>
                <div style={{ fontSize: 10, color: 'var(--text-3)' }}>Marketing Manager</div>
              </div>
              <button onClick={() => navigate('settings')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-4)', flexShrink: 0 }}>
                <SettingsIcon size={13} />
              </button>
            </div>
          )}
        </aside>

        {/* ─── MAIN ─────────────────────────────────────────────────── */}
        <main style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column', position: 'relative' }}>
          {renderPage()}
        </main>

        {/* ─── FLOATING COPILOT ─────────────────────────────────────── */}
        {copilotOpen && (
          <aside className="animate-slideRight" style={{ width: 320, background: 'var(--bg-subtle)', borderLeft: '1px solid var(--border)', display: 'flex', flexDirection: 'column', flexShrink: 0, zIndex: 100 }}>
            {/* Header */}
            <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Sparkles size={13} color="#fff" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, fontFamily: 'var(--font-display)' }} className="ai-text-shift">Marketing Copilot</div>
                <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 1 }}>Powered by Claude</div>
              </div>
              <button onClick={() => setCopilotOpen(false)} className="btn btn-icon" style={{ width: 26, height: 26 }}><X size={13} /></button>
            </div>

            {/* Quick actions */}
            <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
              <div className="label" style={{ marginBottom: 8 }}>Quick Actions</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                {[
                  { icon: Megaphone, label: 'Create Campaign' },
                  { icon: Wand2, label: 'Generate Content' },
                  { icon: Target, label: 'Improve CTR' },
                  { icon: DollarSign, label: 'Optimize Budget' },
                  { icon: SearchIcon, label: 'SEO Ideas' },
                  { icon: BarChart3, label: 'Analyze Data' },
                ].map(({ icon: Icon, label }) => (
                  <button key={label} onClick={() => { setCopilotMsg(label); }} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 9px', background: 'var(--surface-3)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 11, color: 'var(--text-2)', cursor: 'pointer', transition: 'all 0.12s' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'var(--primary-dim)'; (e.currentTarget as HTMLElement).style.borderColor = 'rgba(99,102,241,0.25)'; (e.currentTarget as HTMLElement).style.color = 'var(--primary)' }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'var(--surface-3)'; (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-2)' }}>
                    <Icon size={10} /> {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Context insight */}
            <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
              <div style={{ background: 'var(--ai-subtle)', border: '1px solid rgba(99,102,241,0.15)', borderRadius: 10, padding: '10px 12px' }}>
                <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start' }}>
                  <Sparkles size={12} style={{ color: 'var(--primary)', flexShrink: 0, marginTop: 1 }} />
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--primary)', marginBottom: 3 }}>Context: {PAGE_LABELS[page]}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.6 }}>
                      WhatsApp Retargeting is your top campaign at <strong style={{ color: 'var(--green)' }}>172x ROAS</strong>. Budget is limited — scaling it could unlock ₹42k/week more.
                    </div>
                    <button onClick={() => show('Applying AI suggestion…', 'info')} style={{ marginTop: 6, display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: 'var(--primary)', background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'var(--font-body)' }}>
                      Apply suggestion <ArrowRight size={9} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Chat history */}
            <div style={{ flex: 1, overflow: 'auto', padding: '12px' }} className="scrollbar-hide">
              {copilotHistory.map((msg, i) => (
                <div key={i} style={{ marginBottom: 12, display: 'flex', flexDirection: 'column', alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                  {msg.role === 'ai' && (
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 6, maxWidth: '90%' }}>
                      <div style={{ width: 20, height: 20, borderRadius: 6, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 2 }}>
                        <Sparkles size={10} color="#fff" />
                      </div>
                      <div style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: '0 10px 10px 10px', padding: '9px 12px', fontSize: 12, color: 'var(--text-2)', lineHeight: 1.7 }}>
                        {msg.text.split('**').map((part, j) => j % 2 === 0 ? part : <strong key={j} style={{ color: 'var(--text)' }}>{part}</strong>)}
                      </div>
                    </div>
                  )}
                  {msg.role === 'user' && (
                    <div style={{ background: 'var(--primary-dim)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: '10px 0 10px 10px', padding: '9px 12px', fontSize: 12, color: 'var(--text)', lineHeight: 1.6, maxWidth: '85%' }}>
                      {msg.text}
                    </div>
                  )}
                </div>
              ))}
              {typing && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }}>
                  <div style={{ width: 20, height: 20, borderRadius: 6, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Sparkles size={10} color="#fff" />
                  </div>
                  <div style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: '0 10px 10px 10px', padding: '9px 14px' }}>
                    <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                      {[0, 1, 2].map(i => (
                        <div key={i} style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--primary)', animation: `blink 1.2s ${i * 0.2}s ease-in-out infinite` }} />
                      ))}
                    </div>
                  </div>
                </div>
              )}
              <div ref={msgEndRef} />
            </div>

            {/* Suggested prompts */}
            <div style={{ padding: '8px 12px', flexShrink: 0 }}>
              <div className="label" style={{ marginBottom: 6 }}>Suggested</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {AI_PROMPTS.slice(0, 3).map(p => (
                  <button key={p} onClick={() => setCopilotMsg(p)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 8px', background: 'none', border: '1px solid var(--border)', borderRadius: 7, fontSize: 11, color: 'var(--text-3)', cursor: 'pointer', textAlign: 'left', transition: 'all 0.12s', fontFamily: 'var(--font-body)' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-2)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-2)' }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-3)' }}>
                    <ArrowUpRight size={10} style={{ flexShrink: 0 }} /> {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Input */}
            <div style={{ padding: '10px 12px', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
              <div style={{ display: 'flex', gap: 6 }}>
                <div style={{ flex: 1, position: 'relative' }}>
                  <textarea
                    value={copilotMsg} onChange={e => setCopilotMsg(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendCopilot() } }}
                    placeholder="Ask anything…"
                    rows={1}
                    style={{ width: '100%', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 9, padding: '9px 12px', fontSize: 12, color: 'var(--text)', outline: 'none', resize: 'none', fontFamily: 'var(--font-body)', lineHeight: 1.5 }}
                    onFocus={e => { e.currentTarget.style.borderColor = 'var(--border-focus)'; e.currentTarget.style.boxShadow = '0 0 0 3px var(--primary-dim)' }}
                    onBlur={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.boxShadow = 'none' }}
                  />
                </div>
                <button onClick={sendCopilot} disabled={!copilotMsg.trim()} style={{ width: 34, height: 34, borderRadius: 9, background: copilotMsg.trim() ? 'var(--ai-gradient)' : 'var(--surface-3)', border: 'none', cursor: copilotMsg.trim() ? 'pointer' : 'default', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s', flexShrink: 0 }}>
                  <Send size={13} color={copilotMsg.trim() ? '#fff' : 'var(--text-4)'} />
                </button>
              </div>
            </div>
          </aside>
        )}
      </div>

      {/* ─── COMMAND PALETTE ────────────────────────────────────────── */}
      {cmdOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9000, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: '13vh' }} onClick={() => setCmdOpen(false)}>
          <div className="animate-scaleIn glass-md" style={{ width: 580, maxWidth: 'calc(100vw - 32px)', borderRadius: 16, overflow: 'hidden', boxShadow: 'var(--shadow-xl)' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 18px', borderBottom: '1px solid var(--border)' }}>
              <Command size={15} color="var(--text-3)" />
              <input autoFocus placeholder="Search pages, campaigns, actions…"
                style={{ flex: 1, background: 'none', border: 'none', outline: 'none', fontSize: 15, color: 'var(--text)', fontFamily: 'var(--font-body)' }} />
              <button onClick={() => setCmdOpen(false)} style={{ background: 'var(--surface-3)', border: '1px solid var(--border)', borderRadius: 5, padding: '3px 7px', fontSize: 10, color: 'var(--text-3)', cursor: 'pointer', fontFamily: 'var(--font-body)' }}>ESC</button>
            </div>
            <div style={{ padding: '8px', maxHeight: 420, overflow: 'auto' }} className="scrollbar-hide">
              <div className="label" style={{ padding: '4px 10px 6px' }}>Navigation</div>
              {allItems.map(item => {
                const Icon = item.icon
                return (
                  <button key={item.id} onClick={() => navigate(item.id)}
                    style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'none', border: 'none', borderRadius: 9, cursor: 'pointer', fontSize: 13, color: 'var(--text-2)', textAlign: 'left', fontFamily: 'var(--font-body)', transition: 'all 0.1s' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'var(--surface-2)'; (e.currentTarget as HTMLElement).style.color = 'var(--text)' }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'none'; (e.currentTarget as HTMLElement).style.color = 'var(--text-2)' }}>
                    <div style={{ width: 28, height: 28, borderRadius: 7, background: 'var(--surface-3)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Icon size={13} color="var(--text-3)" />
                    </div>
                    {item.label}
                    <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-4)' }}>Go to page</span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* ─── NOTIFICATIONS ──────────────────────────────────────────── */}
      {notifsOpen && (
        <div className="animate-scaleIn glass-md" style={{ position: 'fixed', top: 56, right: 16, zIndex: 8000, width: 360, borderRadius: 14, boxShadow: 'var(--shadow-xl)', overflow: 'hidden' }}>
          <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>Notifications</span>
            <div style={{ display: 'flex', gap: 6 }}>
              <button onClick={() => show('All marked as read', 'success')} style={{ fontSize: 11, color: 'var(--primary)', background: 'none', border: 'none', cursor: 'pointer' }}>Mark all read</button>
              <button onClick={() => setNotifsOpen(false)} className="btn btn-icon" style={{ width: 24, height: 24 }}><X size={12} /></button>
            </div>
          </div>
          {[
            { text: 'WhatsApp Retargeting hit 172x ROAS', time: '2 min', dot: 'var(--green)' },
            { text: 'Budget alert: Google Search at 90%', time: '1 hr', dot: 'var(--amber)' },
            { text: 'New lead: Rajesh Kumar — ₹2.4L deal', time: '3 hr', dot: 'var(--primary)' },
            { text: 'AI Bootcamp CTR dropped 8% — action needed', time: '5 hr', dot: 'var(--red)' },
            { text: 'Monthly report generated and sent', time: 'Yesterday', dot: 'var(--green)' },
          ].map((n, i) => (
            <div key={i} onClick={() => setNotifsOpen(false)} style={{ display: 'flex', gap: 10, padding: '12px 16px', borderBottom: i < 4 ? '1px solid var(--border)' : 'none', cursor: 'pointer', transition: 'background 0.1s' }}
              onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = 'var(--surface-2)'}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}>
              <div style={{ width: 7, height: 7, borderRadius: '50%', background: n.dot, flexShrink: 0, marginTop: 5 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: 'var(--text)' }}>{n.text}</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{n.time} ago</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function TemplatesPlaceholder() {
  const { show } = useToast()
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, padding: 40 }}>
      <div style={{ width: 64, height: 64, borderRadius: 18, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--shadow-ai)' }} className="animate-float">
        <Layers size={28} color="#fff" />
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: 'var(--text)', marginBottom: 8 }}>Campaign Templates</div>
        <div style={{ fontSize: 14, color: 'var(--text-3)', maxWidth: 360, lineHeight: 1.7 }}>
          Browse and use pre-built campaign templates for every platform and objective. Save time, launch faster.
        </div>
      </div>
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={() => show('Browsing templates…', 'info')} className="btn btn-primary" style={{ padding: '10px 20px' }}><Sparkles size={14} /> Browse Templates</button>
        <button onClick={() => show('Creating blank template…', 'info')} className="btn btn-ghost" style={{ padding: '10px 20px' }}>Create Blank</button>
      </div>
    </div>
  )
}
