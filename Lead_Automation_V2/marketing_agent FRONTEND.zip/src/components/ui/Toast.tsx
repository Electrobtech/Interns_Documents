import { useState, useEffect, createContext, useContext, type ReactNode } from 'react'
import { CheckCircle, XCircle, Info, X } from 'lucide-react'

type ToastType = 'success' | 'error' | 'info'
interface Toast { id: number; type: ToastType; message: string }
interface ToastCtx { show: (msg: string, type?: ToastType) => void }

const ToastContext = createContext<ToastCtx>({ show: () => {} })

export function useToast() { return useContext(ToastContext) }

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const show = (message: string, type: ToastType = 'success') => {
    const id = Date.now()
    setToasts(prev => [...prev, { id, type, message }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3500)
  }

  const icons = { success: CheckCircle, error: XCircle, info: Info }
  const colors = { success: '#10b981', error: '#ef4444', info: '#6366f1' }

  return (
    <ToastContext.Provider value={{ show }}>
      {children}
      <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {toasts.map(t => {
          const Icon = icons[t.type]
          return (
            <div key={t.id} className="toast-enter" style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#1a1a2e', border: `1px solid ${colors[t.type]}40`, borderRadius: 10, padding: '12px 16px', minWidth: 280, boxShadow: '0 8px 32px rgba(0,0,0,0.4)' }}>
              <Icon size={16} style={{ color: colors[t.type], flexShrink: 0 }} />
              <span style={{ fontSize: 13, color: '#e4e4f0', flex: 1 }}>{t.message}</span>
              <button onClick={() => setToasts(prev => prev.filter(x => x.id !== t.id))} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#6b6b8c', padding: 0 }}>
                <X size={14} />
              </button>
            </div>
          )
        })}
      </div>
    </ToastContext.Provider>
  )
}
