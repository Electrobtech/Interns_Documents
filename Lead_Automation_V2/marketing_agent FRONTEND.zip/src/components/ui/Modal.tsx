import { type ReactNode } from 'react'
import { X } from 'lucide-react'

interface ModalProps { title: string; onClose: () => void; children: ReactNode; width?: number }

export default function Modal({ title, onClose, children, width = 560 }: ModalProps) {
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }} onClick={onClose}>
      <div style={{ background: '#13131e', border: '1px solid #252538', borderRadius: 14, width, maxWidth: 'calc(100vw - 32px)', maxHeight: '90vh', overflow: 'auto', boxShadow: '0 24px 80px rgba(0,0,0,0.6)' }} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: '1px solid #252538' }}>
          <span style={{ fontWeight: 600, fontSize: 15, color: '#e4e4f0' }}>{title}</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#6b6b8c', padding: 4, borderRadius: 6, display: 'flex', alignItems: 'center' }}>
            <X size={18} />
          </button>
        </div>
        <div style={{ padding: 24 }}>{children}</div>
      </div>
    </div>
  )
}
