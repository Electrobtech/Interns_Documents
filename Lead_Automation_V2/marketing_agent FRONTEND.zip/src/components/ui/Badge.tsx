interface BadgeProps { label: string; variant?: 'active' | 'paused' | 'scheduled' | 'draft' | 'sent' | 'default' | 'success' | 'warning' | 'danger' }

const variants: Record<string, { bg: string; color: string }> = {
  active: { bg: '#10b98120', color: '#10b981' },
  sent: { bg: '#10b98120', color: '#10b981' },
  success: { bg: '#10b98120', color: '#10b981' },
  paused: { bg: '#f59e0b20', color: '#f59e0b' },
  warning: { bg: '#f59e0b20', color: '#f59e0b' },
  scheduled: { bg: '#6366f120', color: '#6366f1' },
  draft: { bg: '#6b6b8c20', color: '#9b9bb8' },
  default: { bg: '#6b6b8c20', color: '#9b9bb8' },
  danger: { bg: '#ef444420', color: '#ef4444' },
}

export default function Badge({ label, variant = 'default' }: BadgeProps) {
  const s = variants[variant] || variants.default
  return (
    <span style={{ background: s.bg, color: s.color, borderRadius: 5, padding: '2px 8px', fontSize: 11, fontWeight: 600, letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>
      {label}
    </span>
  )
}
