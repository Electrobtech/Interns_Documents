import { type ReactNode } from 'react'
import { X } from 'lucide-react'

interface DrawerProps { title: string; subtitle?: string; onClose: () => void; children: ReactNode; width?: number }

export default function Drawer({ title, subtitle, onClose, children, width = 720 }: DrawerProps) {
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 900, display: 'flex', justifyContent: 'flex-end', background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(3px)' }} onClick={onClose}>
      <div style={{ width, maxWidth: '95vw', height: '100%', background: '#13131e', borderLeft: '1px solid #252538', display: 'flex', flexDirection: 'column', boxShadow: '-16px 0 64px rgba(0,0,0,0.5)' }} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', padding: '20px 24px', borderBottom: '1px solid #252538', flexShrink: 0 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, color: '#e4e4f0' }}>{title}</div>
            {subtitle && <div style={{ fontSize: 12, color: '#6b6b8c', marginTop: 2 }}>{subtitle}</div>}
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#6b6b8c', padding: 4, borderRadius: 6, marginTop: 2 }}>
            <X size={18} />
          </button>
        </div>
        <div style={{ flex: 1, overflow: 'auto' }}>{children}</div>
      </div>
    </div>
  )
}
