import { useState } from 'react'
import { Settings as SettingsIcon, Users, Shield, Zap, Bell, CreditCard, Sparkles, FileText, Globe, Palette, Check, Plus } from 'lucide-react'
import { teamMembers } from '../../data/mockData'
import { useToast } from '../ui/Toast'

const SETTINGS_TABS = [
  { id: 'general', label: 'General', icon: SettingsIcon },
  { id: 'branding', label: 'Branding', icon: Palette },
  { id: 'team', label: 'Team Members', icon: Users },
  { id: 'roles', label: 'Roles & Permissions', icon: Shield },
  { id: 'integrations', label: 'Integrations', icon: Zap },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'billing', label: 'Billing', icon: CreditCard },
  { id: 'ai', label: 'AI Preferences', icon: Sparkles },
  { id: 'audit', label: 'Audit Logs', icon: FileText },
]

const INTEGRATIONS = [
  { name: 'HubSpot', desc: 'Sync contacts and deals', connected: true, color: '#ff7a59' },
  { name: 'Salesforce', desc: 'CRM bidirectional sync', connected: false, color: '#00a1e0' },
  { name: 'Google Analytics', desc: 'Track campaign events', connected: true, color: '#e37400' },
  { name: 'WhatsApp Business API', desc: 'Send broadcasts and automations', connected: true, color: '#25d366' },
  { name: 'Slack', desc: 'Lead and campaign alerts', connected: true, color: '#4a154b' },
  { name: 'Zapier', desc: 'Connect 5,000+ apps', connected: false, color: '#ff4a00' },
  { name: 'n8n', desc: 'Advanced workflow automation', connected: false, color: '#ea4b71' },
  { name: 'Google Ads', desc: 'Sync campaigns and conversions', connected: true, color: '#4285f4' },
  { name: 'Facebook Ads', desc: 'Sync campaign data', connected: true, color: '#1877f2' },
]

export default function Settings() {
  const { show } = useToast()
  const [tab, setTab] = useState('general')

  return (
    <div style={{ display: 'flex', height: '100%' }}>
      {/* Sidebar */}
      <div style={{ width: 220, borderRight: '1px solid var(--border)', padding: '16px 12px', flexShrink: 0 }}>
        {SETTINGS_TABS.map(t => {
          const Icon = t.icon
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', width: '100%', background: tab === t.id ? '#6366f120' : 'none', border: 'none', borderRadius: 8, fontSize: 13, color: tab === t.id ? '#6366f1' : '#9b9bb8', cursor: 'pointer', textAlign: 'left', marginBottom: 2, fontFamily: 'DM Sans' }}>
              <Icon size={14} style={{ opacity: 0.8 }} /> {t.label}
            </button>
          )
        })}
      </div>

      {/* Main */}
      <div style={{ flex: 1, overflow: 'auto', padding: 28 }}>
        {tab === 'general' && (
          <div style={{ maxWidth: 520, display: 'flex', flexDirection: 'column', gap: 20 }}>
            <SectionTitle title="General Settings" />
            {[
              { label: 'Workspace Name', value: 'Acme Marketing', type: 'text' },
              { label: 'Website', value: 'https://acme.io', type: 'text' },
              { label: 'Industry', value: 'SaaS / Technology', type: 'select', options: ['SaaS / Technology', 'E-commerce', 'Education', 'Finance', 'Healthcare'] },
              { label: 'Timezone', value: 'IST (UTC+5:30)', type: 'select', options: ['IST (UTC+5:30)', 'UTC', 'EST', 'PST'] },
              { label: 'Currency', value: 'INR (₹)', type: 'select', options: ['INR (₹)', 'USD ($)', 'EUR (€)', 'GBP (£)'] },
            ].map(f => (
              <div key={f.label}>
                <label style={labelStyle}>{f.label}</label>
                {f.type === 'select' ? (
                  <select defaultValue={f.value} style={inputStyle}>{f.options!.map(o => <option key={o}>{o}</option>)}</select>
                ) : (
                  <input defaultValue={f.value} style={inputStyle} />
                )}
              </div>
            ))}
            <button onClick={() => show('Settings saved', 'success')} style={primaryBtn}>Save Changes</button>
          </div>
        )}

        {tab === 'team' && (
          <div style={{ maxWidth: 680 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
              <SectionTitle title="Team Members" />
              <button onClick={() => show('Invite sent', 'success')} style={primaryBtn}><Plus size={13} /> Invite Member</button>
            </div>
            <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden' }}>
              {teamMembers.map((m, i) => (
                <div key={m.id} style={{ display: 'flex', alignItems: 'center', padding: '14px 20px', borderBottom: i < teamMembers.length - 1 ? '1px solid #252538' : 'none', gap: 14 }}>
                  <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#6366f130', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#6366f1', flexShrink: 0 }}>{m.avatar}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>{m.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{m.email}</div>
                  </div>
                  <span style={{ fontSize: 12, color: '#9b9bb8' }}>{m.role}</span>
                  <span style={{ fontSize: 11, fontWeight: 600, color: m.status === 'Active' ? '#10b981' : '#f59e0b', background: (m.status === 'Active' ? '#10b981' : '#f59e0b') + '20', padding: '2px 8px', borderRadius: 5 }}>{m.status}</span>
                  <button onClick={() => show(`Editing ${m.name}`, 'info')} style={{ padding: '5px 10px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, fontSize: 12, color: '#9b9bb8', cursor: 'pointer' }}>Edit</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'integrations' && (
          <div style={{ maxWidth: 680 }}>
            <SectionTitle title="Integrations" />
            <p style={{ fontSize: 13, color: 'var(--text-3)', margin: '4px 0 20px' }}>Connect your favorite tools to streamline your workflow.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
              {INTEGRATIONS.map(intg => (
                <div key={intg.name} style={{ background: 'var(--card-solid)', border: `1px solid ${intg.connected ? '#252538' : '#252538'}`, borderRadius: 12, padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: intg.color + '20', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: intg.color, flexShrink: 0 }}>{intg.name[0]}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>{intg.name}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{intg.desc}</div>
                  </div>
                  <button onClick={() => show(intg.connected ? `${intg.name} disconnected` : `${intg.name} connected`, intg.connected ? 'error' : 'success')} style={{ padding: '6px 12px', background: intg.connected ? '#10b98115' : '#6366f115', border: `1px solid ${intg.connected ? '#10b98130' : '#6366f130'}`, borderRadius: 7, fontSize: 12, color: intg.connected ? '#10b981' : '#6366f1', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
                    {intg.connected && <Check size={11} />}
                    {intg.connected ? 'Connected' : 'Connect'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'ai' && (
          <div style={{ maxWidth: 520, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <SectionTitle title="AI Preferences" />
            {[
              { label: 'Default AI Model', options: ['Claude Sonnet 5', 'Claude Opus 5', 'GPT-4o', 'Gemini Pro'] },
              { label: 'Content Language', options: ['English', 'Hindi', 'Tamil', 'Mixed'] },
              { label: 'Tone Preference', options: ['Professional', 'Friendly', 'Bold', 'Conversational'] },
              { label: 'AI Insights Frequency', options: ['Real-time', 'Hourly', 'Daily', 'Weekly'] },
            ].map(f => (
              <div key={f.label}>
                <label style={labelStyle}>{f.label}</label>
                <select style={inputStyle}>{f.options.map(o => <option key={o}>{o}</option>)}</select>
              </div>
            ))}
            {['Enable AI Campaign Suggestions', 'Auto-apply AI Budget Optimization', 'AI-powered Audience Insights', 'Smart Send Time Optimization'].map(t => (
              <div key={t} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: '14px 16px' }}>
                <span style={{ fontSize: 13, color: '#9b9bb8' }}>{t}</span>
                <div onClick={() => show(`${t} toggled`, 'info')} style={{ width: 38, height: 20, background: '#6366f1', borderRadius: 99, cursor: 'pointer', position: 'relative' }}>
                  <div style={{ width: 16, height: 16, background: '#fff', borderRadius: '50%', position: 'absolute', top: 2, right: 2, transition: 'right 0.2s' }} />
                </div>
              </div>
            ))}
            <button onClick={() => show('AI preferences saved', 'success')} style={primaryBtn}>Save Preferences</button>
          </div>
        )}

        {!['general', 'team', 'integrations', 'ai'].includes(tab) && (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-3)' }}>
            <SettingsIcon size={32} style={{ opacity: 0.3, marginBottom: 12 }} />
            <div style={{ fontSize: 14 }}>{SETTINGS_TABS.find(t => t.id === tab)?.label} settings will appear here</div>
          </div>
        )}
      </div>
    </div>
  )
}

function SectionTitle({ title }: { title: string }) {
  return <h2 style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)', margin: '0 0 4px' }}>{title}</h2>
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '9px 16px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans', width: 'fit-content' }
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 600, color: '#9b9bb8', marginBottom: 6 }
const inputStyle: React.CSSProperties = { width: '100%', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', fontFamily: 'DM Sans' }
