import { useState } from 'react'
import { Upload, Search, Filter, Grid, List, Folder, Image, Video, FileText, Download, Trash2, Edit2, Move } from 'lucide-react'
import { assets } from '../../data/mockData'
import { useToast } from '../ui/Toast'

const FOLDERS = ['All Files', 'Images', 'Videos', 'PDFs', 'Logos', 'Brand Kit', 'Icons', 'AI Generated Images', 'Templates']

export default function AssetsLibrary() {
  const { show } = useToast()
  const [folder, setFolder] = useState('All Files')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [search, setSearch] = useState('')

  const filtered = assets.filter(a =>
    (folder === 'All Files' || a.type === folder) &&
    a.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={{ display: 'flex', height: '100%' }}>
      {/* Sidebar */}
      <div style={{ width: 200, borderRight: '1px solid var(--border)', padding: '16px 12px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-3)', letterSpacing: '0.08em', marginBottom: 8, padding: '0 8px' }}>FOLDERS</div>
        {FOLDERS.map(f => (
          <button key={f} onClick={() => setFolder(f)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', background: folder === f ? '#6366f120' : 'none', border: 'none', borderRadius: 7, fontSize: 13, color: folder === f ? '#6366f1' : '#9b9bb8', cursor: 'pointer', textAlign: 'left', width: '100%', fontFamily: 'DM Sans' }}>
            <Folder size={13} style={{ opacity: 0.7 }} /> {f}
          </button>
        ))}
      </div>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* Toolbar */}
        <div style={{ padding: '12px 20px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, alignItems: 'center', flexShrink: 0 }}>
          <button onClick={() => show('Upload dialog opened', 'info')} style={primaryBtn}><Upload size={14} /> Upload</button>
          <div style={{ flex: 1 }} />
          <div style={{ position: 'relative' }}>
            <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-3)' }} />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search assets…" style={{ ...inputStyle, paddingLeft: 30, width: 180 }} />
          </div>
          <button style={iconBtn}><Filter size={14} /></button>
          <button onClick={() => setViewMode('grid')} style={{ ...iconBtn, background: viewMode === 'grid' ? '#252538' : '#1a1a2e' }}><Grid size={14} /></button>
          <button onClick={() => setViewMode('list')} style={{ ...iconBtn, background: viewMode === 'list' ? '#252538' : '#1a1a2e' }}><List size={14} /></button>
        </div>

        <div style={{ flex: 1, overflow: 'auto', padding: 20 }}>
          {viewMode === 'grid' ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
              {filtered.map(a => (
                <div key={a.id} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden', cursor: 'pointer', transition: 'border-color 0.15s' }}
                  onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = '#6366f1'}
                  onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = '#252538'}>
                  {a.url ? (
                    <div style={{ height: 100, background: 'var(--surface-2)', overflow: 'hidden' }}>
                      <img src={a.url} alt={a.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </div>
                  ) : (
                    <div style={{ height: 100, background: 'var(--surface-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <FileText size={28} style={{ color: 'var(--text-3)' }} />
                    </div>
                  )}
                  <div style={{ padding: '8px 10px' }}>
                    <div style={{ fontSize: 12, color: 'var(--text)', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 2 }}>{a.size}</div>
                  </div>
                  <div style={{ display: 'flex', borderTop: '1px solid var(--border)' }}>
                    {[Download, Edit2, Trash2].map((Icon, i) => (
                      <button key={i} onClick={() => show(['Downloaded', 'Renamed', 'Deleted'][i], i === 2 ? 'error' : 'success')} style={{ flex: 1, padding: 8, background: 'none', border: 'none', cursor: 'pointer', color: i === 2 ? '#ef4444' : '#6b6b8c', display: 'flex', justifyContent: 'center' }}>
                        <Icon size={13} />
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              {/* Upload Drop Zone */}
              <div onClick={() => show('Upload dialog', 'info')} style={{ border: '2px dashed #252538', borderRadius: 10, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', minHeight: 160, gap: 6 }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = '#6366f1'}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = '#252538'}>
                <Upload size={20} style={{ color: 'var(--text-3)' }} />
                <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Drop files here</span>
              </div>
            </div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  {['Name', 'Type', 'Size', 'Modified', 'Actions'].map(h => (
                    <th key={h} style={{ padding: '8px 12px', fontSize: 11, fontWeight: 600, color: 'var(--text-3)', textAlign: 'left' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(a => (
                  <tr key={a.id} style={{ borderBottom: '1px solid #1a1a2e' }}
                    onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#1a1a2e'}
                    onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}>
                    <td style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: 8 }}>
                      {a.url ? <Image size={14} style={{ color: '#6366f1' }} /> : <FileText size={14} style={{ color: '#f59e0b' }} />}
                      <span style={{ fontSize: 13, color: 'var(--text)' }}>{a.name}</span>
                    </td>
                    <td style={{ padding: '12px', fontSize: 12, color: 'var(--text-3)' }}>{a.type}</td>
                    <td style={{ padding: '12px', fontSize: 12, fontFamily: 'JetBrains Mono', color: '#9b9bb8' }}>{a.size}</td>
                    <td style={{ padding: '12px', fontSize: 12, color: 'var(--text-3)' }}>{a.modified}</td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ display: 'flex', gap: 4 }}>
                        {[Download, Edit2, Move, Trash2].map((Icon, i) => (
                          <button key={i} onClick={() => show(['Downloaded', 'Renamed', 'Moved', 'Deleted'][i], i === 3 ? 'error' : 'success')} style={{ width: 26, height: 26, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: i === 3 ? '#ef4444' : '#9b9bb8' }}>
                            <Icon size={12} />
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const iconBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, cursor: 'pointer', color: '#9b9bb8' }
const inputStyle: React.CSSProperties = { background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '7px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', fontFamily: 'DM Sans' }
