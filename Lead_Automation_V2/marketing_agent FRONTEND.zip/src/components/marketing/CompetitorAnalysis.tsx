import { useState } from 'react'
import { Plus, RefreshCw, BarChart3, Download, Zap, TrendingUp, TrendingDown, ExternalLink } from 'lucide-react'
import { competitors } from '../../data/mockData'
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts'
import { useToast } from '../ui/Toast'

const TABS = ['Overview', 'SEO', 'Ads', 'Social', 'Content', 'Keywords', 'Landing Pages', 'Pricing']

const swotData = {
  strengths: ['WhatsApp-first approach unique in market', 'Superior ROAS (172x vs industry avg 15x)', 'India-specific audience insights', 'Fastest setup time: 10 minutes'],
  weaknesses: ['Lower domain authority vs HubSpot', 'Limited LinkedIn automation', 'Smaller template library', 'No native CRM built-in'],
  opportunities: ['42 uncovered high-volume keywords', 'HubSpot pricing gap (₹15k+ vs ₹3k)', 'WhatsApp Business API adoption growing 3x', 'AEO optimization gap vs all competitors'],
  threats: ['Salesforce entering SMB market', 'Meta restricting WhatsApp API access', 'New Indian competitors raising funding', 'Google changing SERP features'],
}

export default function CompetitorAnalysis() {
  const { show } = useToast()
  const [tab, setTab] = useState('Overview')
  const [selectedComp, setSelectedComp] = useState<string | null>(null)

  const radarComparisons = competitors.map(c => ({
    subject: c.name,
    'Our Platform': 72,
    [c.name]: c.opportunity,
  }))

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
        <button onClick={() => show('Add competitor dialog', 'info')} style={primaryBtn}><Plus size={14} /> Add Competitor</button>
        {[
          { icon: RefreshCw, label: 'Refresh' },
          { icon: BarChart3, label: 'Compare' },
          { icon: Download, label: 'Export' },
          { icon: Zap, label: 'AI Insights' },
        ].map(({ icon: Icon, label }) => (
          <button key={label} onClick={() => show(`${label} triggered`, 'info')} style={toolBtn}><Icon size={13} /> {label}</button>
        ))}
      </div>

      {/* Sub-tabs */}
      <div style={{ padding: '0 24px', borderBottom: '1px solid var(--border)', display: 'flex', overflowX: 'auto', flexShrink: 0 }} className="scrollbar-hide">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding: '12px 16px', fontSize: 13, fontWeight: tab === t ? 600 : 400, color: tab === t ? '#6366f1' : '#6b6b8c', background: 'none', border: 'none', cursor: 'pointer', borderBottom: `2px solid ${tab === t ? '#6366f1' : 'transparent'}`, whiteSpace: 'nowrap' }}>
            {t}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
        {/* Competitor Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12, marginBottom: 20 }}>
          {competitors.map(c => (
            <div key={c.id} onClick={() => setSelectedComp(selectedComp === c.id ? null : c.id)} style={{ background: 'var(--card-solid)', border: `1px solid ${selectedComp === c.id ? '#6366f1' : '#252538'}`, borderRadius: 12, padding: '16px 18px', cursor: 'pointer', transition: 'border-color 0.15s' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 9, background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: '#6366f1' }}>{c.name[0]}</div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text)' }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{c.domain}</div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                {[
                  { label: 'Traffic', value: c.traffic },
                  { label: 'DA', value: c.da },
                  { label: 'Opportunity', value: `${c.opportunity}%`, color: '#10b981' },
                  { label: 'Threat', value: `${c.threat}%`, color: c.threat > 80 ? '#ef4444' : '#f59e0b' },
                ].map(m => (
                  <div key={m.label} style={{ background: 'var(--surface-2)', borderRadius: 7, padding: '8px 10px' }}>
                    <div style={{ fontSize: 10, color: 'var(--text-3)' }}>{m.label}</div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: (m as any).color || '#e4e4f0', fontFamily: 'JetBrains Mono' }}>{m.value}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
          {/* Add New */}
          <div onClick={() => show('Add competitor', 'info')} style={{ background: 'var(--card-solid)', border: '1px dashed #252538', borderRadius: 12, padding: 16, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, minHeight: 140 }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', border: '1px dashed #252538', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-3)' }}><Plus size={14} /></div>
            <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Add Competitor</span>
          </div>
        </div>

        {tab === 'Overview' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
            {/* Competitor Bar Chart */}
            <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 12 }}>Traffic Comparison</div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={competitors}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#252538" />
                  <XAxis dataKey="name" tick={{ fill: '#6b6b8c', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#6b6b8c', fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="da" fill="#6366f1" radius={[4, 4, 0, 0]} name="Domain Authority" />
                  <Bar dataKey="engagement" fill="#10b981" radius={[4, 4, 0, 0]} name="Engagement" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* SWOT */}
            <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 12 }}>SWOT Analysis</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                {[
                  { label: 'Strengths', items: swotData.strengths, color: '#10b981' },
                  { label: 'Weaknesses', items: swotData.weaknesses, color: '#ef4444' },
                  { label: 'Opportunities', items: swotData.opportunities, color: '#6366f1' },
                  { label: 'Threats', items: swotData.threats, color: '#f59e0b' },
                ].map(q => (
                  <div key={q.label} style={{ background: q.color + '08', border: `1px solid ${q.color}25`, borderRadius: 8, padding: 10 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: q.color, marginBottom: 6, letterSpacing: '0.04em' }}>{q.label.toUpperCase()}</div>
                    {q.items.map((item, i) => (
                      <div key={i} style={{ fontSize: 11, color: '#9b9bb8', marginBottom: 4, lineHeight: 1.4 }}>· {item}</div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const toolBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 11px', fontSize: 12, color: '#9b9bb8', cursor: 'pointer', fontFamily: 'DM Sans' }
