import { useState, useEffect, useRef } from 'react'
import { TrendingUp, TrendingDown, Megaphone, Users, DollarSign, Target, Sparkles, BarChart3, RefreshCw, Download, ArrowRight, AlertTriangle, CheckCircle, Info, Zap, Plus, Radio, Search, Pen, ChevronRight, Activity, Clock, Bot, Globe, BarChart2 } from 'lucide-react'
import { AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { kpiData, performanceData, platformData, funnelData, channelPerformance, audienceGrowth, aiInsights, revenueData } from '../../data/mockData'
import { useToast } from '../ui/Toast'

type Page = 'campaigns' | 'broadcasts' | 'audience' | 'content' | 'seo' | 'analytics'
interface Props { onNavigate?: (page: any) => void }

const QUICK_ACTIONS = [
  { icon: Megaphone, label: 'Launch Campaign', sub: 'AI-powered', color: 'var(--primary)', page: 'campaigns' },
  { icon: Radio, label: 'Broadcast', sub: 'WhatsApp · Email', color: '#10b981', page: 'broadcasts' },
  { icon: Pen, label: 'Generate Content', sub: 'AI Studio', color: '#8b5cf6', page: 'content' },
  { icon: Search, label: 'SEO Audit', sub: 'Run now', color: '#f59e0b', page: 'seo' },
  { icon: Users, label: 'Build Audience', sub: 'Segmentation', color: '#3b82f6', page: 'audience' },
  { icon: BarChart2, label: 'View Analytics', sub: 'Live data', color: '#ec4899', page: 'analytics' },
]

const ACTIVITY = [
  { icon: Megaphone, text: 'Campaign "AI Bootcamp Q3" launched', sub: '2 minutes ago', color: 'var(--primary)' },
  { icon: Sparkles, text: 'AI optimized WhatsApp Retargeting budget', sub: '18 minutes ago', color: '#8b5cf6' },
  { icon: Users, text: 'Audience segment "High-Intent Leads Q3" updated', sub: '1 hour ago', color: '#10b981' },
  { icon: Radio, text: 'Flash Sale broadcast sent to 12,000 contacts', sub: '3 hours ago', color: '#f59e0b' },
  { icon: AlertTriangle, text: 'Competitor alert: HubSpot launched WhatsApp feature', sub: '5 hours ago', color: '#ef4444' },
  { icon: CheckCircle, text: 'SEO audit completed — 74/100 score', sub: '8 hours ago', color: '#10b981' },
  { icon: BarChart3, text: 'Monthly report generated and sent to leadership', sub: 'Yesterday', color: '#3b82f6' },
]

function AnimatedNumber({ value, prefix = '', suffix = '' }: { value: number | string; prefix?: string; suffix?: string }) {
  const [display, setDisplay] = useState(0)
  const numVal = typeof value === 'string' ? parseFloat(value.replace(/[^0-9.]/g, '')) : value
  const isStr = typeof value === 'string' && isNaN(numVal)

  useEffect(() => {
    if (isStr) return
    let start = 0
    const end = numVal
    const duration = 800
    const step = (end / duration) * 16
    const timer = setInterval(() => {
      start += step
      if (start >= end) { setDisplay(end); clearInterval(timer) }
      else setDisplay(Math.floor(start))
    }, 16)
    return () => clearInterval(timer)
  }, [numVal])

  if (isStr) return <>{value}</>
  return <>{prefix}{display.toLocaleString()}{suffix}</>
}

export default function Dashboard({ onNavigate }: Props) {
  const { show } = useToast()
  const [refreshing, setRefreshing] = useState(false)
  const [aiApplied, setAiApplied] = useState(false)

  const handleRefresh = () => {
    setRefreshing(true)
    setTimeout(() => { setRefreshing(false); show('Dashboard refreshed') }, 1200)
  }

  const handleApplyAI = () => {
    setAiApplied(true)
    show('AI suggestions applied to 3 campaigns', 'success')
  }

  const insightColors = { warning: 'var(--amber)', success: 'var(--green)', info: 'var(--primary)' }
  const insightIcons = { warning: AlertTriangle, success: CheckCircle, info: Info }

  return (
    <div style={{ padding: '28px 28px 40px', display: 'flex', flexDirection: 'column', gap: 24, minHeight: 0 }}>

      {/* ─── PAGE HEADER ─────────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 800, color: 'var(--text)', letterSpacing: '-0.02em', lineHeight: 1.1, margin: 0 }}>
            Good morning, Priya ✨
          </h1>
          <p style={{ fontSize: 13, color: 'var(--text-3)', marginTop: 5 }}>Aug 5, 2025 · Your marketing is performing well today</p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button onClick={() => show('Report downloading…', 'info')} className="btn btn-ghost" style={{ padding: '8px 14px' }}>
            <Download size={13} /> Export Report
          </button>
          <button onClick={handleRefresh} className="btn btn-ghost" style={{ padding: '8px 14px', opacity: refreshing ? 0.6 : 1 }}>
            <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} /> Refresh
          </button>
        </div>
      </div>

      {/* ─── HERO ROW: AI Summary + Quick Actions ────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 16 }}>

        {/* AI Summary Hero Card */}
        <div style={{ background: 'linear-gradient(135deg, rgba(99,102,241,0.15) 0%, rgba(168,85,247,0.10) 50%, rgba(59,130,246,0.08) 100%)', border: '1px solid rgba(99,102,241,0.25)', borderRadius: 20, padding: '24px 28px', position: 'relative', overflow: 'hidden' }}>
          {/* Background glow */}
          <div style={{ position: 'absolute', top: -40, right: -40, width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle, rgba(168,85,247,0.12) 0%, transparent 70%)', pointerEvents: 'none' }} />

          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--shadow-ai)' }}>
                <Sparkles size={16} color="#fff" />
              </div>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, color: 'var(--text)' }}>Today's AI Summary</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 1 }}>Updated 2 minutes ago</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 800, lineHeight: 1 }} className="ai-text">87</div>
                <div style={{ fontSize: 10, color: 'var(--text-3)' }}>Marketing Score</div>
              </div>
              <svg width="52" height="52" viewBox="0 0 52 52">
                <circle cx="26" cy="26" r="22" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="4" />
                <circle cx="26" cy="26" r="22" fill="none" stroke="url(#scoreGrad)" strokeWidth="4" strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 22 * 0.87} ${2 * Math.PI * 22}`} transform="rotate(-90 26 26)" />
                <defs><linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#a855f7" /><stop offset="100%" stopColor="#3b82f6" /></linearGradient></defs>
              </svg>
            </div>
          </div>

          {/* Metrics row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
            {[
              { label: 'Revenue MTD', value: '₹52.6L', trend: '+34%', up: true },
              { label: 'Active Campaigns', value: '14', trend: '+3', up: true },
              { label: 'Leads Today', value: '284', trend: '+18%', up: true },
              { label: 'Avg ROAS', value: '29.4x', trend: '+8%', up: true },
            ].map(m => (
              <div key={m.label} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '12px 14px' }}>
                <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 4 }}>{m.label}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: 'var(--text)', lineHeight: 1 }}>{m.value}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginTop: 4, fontSize: 11, color: m.up ? 'var(--green)' : 'var(--red)' }}>
                  {m.up ? <TrendingUp size={10} /> : <TrendingDown size={10} />} {m.trend}
                </div>
              </div>
            ))}
          </div>

          {/* AI message */}
          <div style={{ background: 'rgba(0,0,0,0.2)', borderRadius: 12, padding: '14px 16px', marginBottom: 16 }}>
            <div style={{ fontSize: 12, color: 'var(--text-2)', lineHeight: 1.8 }}>
              <span style={{ color: 'var(--amber)', fontWeight: 600 }}>3 campaigns need attention.</span> CTR on Brand Awareness dropped 8% — creative refresh recommended.{' '}
              <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Increasing LinkedIn budget by 20%</span> could generate +420 qualified leads based on current performance trends.
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8 }}>
              <div style={{ height: 3, flex: 1, background: 'rgba(255,255,255,0.08)', borderRadius: 99 }}>
                <div style={{ height: '100%', width: '92%', background: 'var(--ai-gradient)', borderRadius: 99 }} />
              </div>
              <span style={{ fontSize: 10, color: 'var(--primary)', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>92% confidence</span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={handleApplyAI} className="btn btn-ai" style={{ padding: '9px 20px', opacity: aiApplied ? 0.7 : 1 }}>
              <Sparkles size={13} /> {aiApplied ? 'Applied ✓' : 'Apply Suggestions'}
            </button>
            <button onClick={() => onNavigate?.('analytics')} className="btn btn-ghost" style={{ padding: '9px 16px' }}>
              View Details <ArrowRight size={13} />
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 20, padding: '20px' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 700, color: 'var(--text)', marginBottom: 14 }}>Quick Actions</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {QUICK_ACTIONS.map(action => {
              const Icon = action.icon
              return (
                <button key={action.label} onClick={() => onNavigate?.(action.page)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 8, padding: '12px 14px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 12, cursor: 'pointer', transition: 'all 0.15s', textAlign: 'left', fontFamily: 'var(--font-body)' }}
                  onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = action.color + '50'; el.style.background = action.color + '10'; el.style.transform = 'translateY(-1px)' }}
                  onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'var(--border)'; el.style.background = 'var(--surface-2)'; el.style.transform = 'none' }}>
                  <div style={{ width: 30, height: 30, borderRadius: 8, background: action.color + '20', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon size={14} style={{ color: action.color }} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)' }}>{action.label}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 1 }}>{action.sub}</div>
                  </div>
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* ─── KPI STRIP ───────────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 10 }}>
        {[
          { label: 'Total Campaigns', value: kpiData.totalCampaigns, suffix: '', trend: +12, color: 'var(--primary)' },
          { label: 'Leads Generated', value: kpiData.leadsGenerated, suffix: '', trend: +28, color: '#10b981' },
          { label: 'Conversion Rate', value: kpiData.conversionRate, suffix: '%', trend: +2.1, color: '#3b82f6' },
          { label: 'CTR Average', value: kpiData.ctr, suffix: '%', trend: +0.4, color: 'var(--primary)' },
          { label: 'CPC', value: kpiData.cpc, prefix: '₹', trend: -12, color: '#10b981' },
          { label: 'Cost Per Lead', value: kpiData.costPerLead, prefix: '₹', trend: -8, color: '#10b981' },
          { label: 'CPM', value: kpiData.cpm, prefix: '₹', trend: -5, color: '#8b5cf6' },
          { label: 'ROAS', value: kpiData.roas, suffix: 'x', trend: +8, color: '#f59e0b' },
          { label: 'AI Score', value: kpiData.aiMarketingScore, suffix: '/100', trend: +6, color: '#a855f7' },
        ].map(kpi => (
          <div key={kpi.label} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 14, padding: '14px 16px', transition: 'all 0.15s' }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = kpi.color + '40'; (e.currentTarget as HTMLElement).style.transform = 'translateY(-1px)' }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLElement).style.transform = 'none' }}>
            <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 8 }}>{kpi.label}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 800, color: 'var(--text)', lineHeight: 1 }}>
              {kpi.prefix}<AnimatedNumber value={kpi.value} />{kpi.suffix}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginTop: 6, fontSize: 11, color: kpi.trend > 0 ? 'var(--green)' : 'var(--red)' }}>
              {kpi.trend > 0 ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
              {kpi.trend > 0 ? '+' : ''}{kpi.trend}% vs last month
            </div>
          </div>
        ))}
      </div>

      {/* ─── CHARTS ROW 1 ───────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
        {/* Campaign Performance */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 22px' }}>
          <ChartHeader title="Campaign Performance" subtitle="Revenue vs leads · Last 7 months" />
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={performanceData}>
              <defs>
                <linearGradient id="gRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gLead" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fill: 'var(--text-3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text-3)', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: 'var(--surface-3)', border: '1px solid var(--border-2)', borderRadius: 10, fontSize: 12, color: 'var(--text)' }} />
              <Area type="monotone" dataKey="revenue" stroke="#6366f1" fill="url(#gRev)" strokeWidth={2.5} name="Revenue (₹)" />
              <Area type="monotone" dataKey="leads" stroke="#10b981" fill="url(#gLead)" strokeWidth={2} name="Leads" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Lead Funnel */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 22px' }}>
          <ChartHeader title="Lead Funnel" subtitle="This month · Top to bottom" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 12 }}>
            {funnelData.map((stage, i) => {
              const colors = ['#6366f1', '#8b5cf6', '#a855f7', '#c084fc', '#ddd6fe']
              return (
                <div key={i}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                    <span style={{ fontSize: 12, color: 'var(--text-2)', fontWeight: 500 }}>{stage.stage}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text)', fontWeight: 600 }}>{stage.value.toLocaleString()}</span>
                  </div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${stage.pct}%`, background: colors[i] }} />
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* ─── CHARTS ROW 2 ───────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
        {/* Revenue vs Target */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 22px' }}>
          <ChartHeader title="Revenue vs Target" subtitle="Monthly performance" />
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={revenueData} barSize={20} barCategoryGap="30%">
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: 'var(--text-3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text-3)', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: 'var(--surface-3)', border: '1px solid var(--border-2)', borderRadius: 10, fontSize: 12, color: 'var(--text)' }} />
              <Bar dataKey="revenue" fill="#6366f1" radius={[5, 5, 0, 0]} name="Revenue" />
              <Bar dataKey="target" fill="rgba(255,255,255,0.07)" radius={[5, 5, 0, 0]} name="Target" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Platform Distribution */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 22px' }}>
          <ChartHeader title="Platform Split" subtitle="Spend distribution" />
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <ResponsiveContainer width={140} height={140}>
              <PieChart>
                <Pie data={platformData} cx="50%" cy="50%" innerRadius={44} outerRadius={64} paddingAngle={3} dataKey="value">
                  {platformData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: 'var(--surface-3)', border: '1px solid var(--border-2)', borderRadius: 8, fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {platformData.map(p => (
                <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: p.color, flexShrink: 0 }} />
                  <span style={{ fontSize: 11, color: 'var(--text-2)' }}>{p.name}</span>
                  <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-3)' }}>{p.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Audience Growth */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 22px' }}>
          <ChartHeader title="Audience Growth" subtitle="Last 8 weeks" />
          <ResponsiveContainer width="100%" height={140}>
            <LineChart data={audienceGrowth}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="week" tick={{ fill: 'var(--text-3)', fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text-3)', fontSize: 9 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: 'var(--surface-3)', border: '1px solid var(--border-2)', borderRadius: 8, fontSize: 11 }} />
              <Line type="monotone" dataKey="total" stroke="#10b981" strokeWidth={2.5} dot={false} name="Total Audience" />
            </LineChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10 }}>
            <span style={{ fontSize: 11, color: 'var(--text-3)' }}>Total subscribers</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, color: 'var(--green)' }}>84,200</span>
          </div>
        </div>
      </div>

      {/* ─── AI INSIGHTS + CHANNEL TABLE + ACTIVITY ─────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 320px', gap: 16 }}>
        {/* AI Insights */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 22px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--ai-gradient)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Sparkles size={13} color="#fff" />
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>AI Insights</div>
              <div style={{ fontSize: 10, color: 'var(--text-3)' }}>{aiInsights.length} active recommendations</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {aiInsights.map(insight => {
              const Icon = insightIcons[insight.type as keyof typeof insightIcons]
              const color = insightColors[insight.type as keyof typeof insightColors]
              return (
                <div key={insight.id} onClick={() => show(insight.recommendation, 'info')} style={{ background: color + '08', border: `1px solid ${color}25`, borderRadius: 12, padding: '12px 14px', cursor: 'pointer', transition: 'all 0.15s' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = color + '14'; (e.currentTarget as HTMLElement).style.borderColor = color + '40' }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = color + '08'; (e.currentTarget as HTMLElement).style.borderColor = color + '25' }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                    <Icon size={13} style={{ color, flexShrink: 0, marginTop: 1 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', marginBottom: 2 }}>{insight.title}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 6 }}>{insight.campaign}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.5 }}>{insight.recommendation}</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8 }}>
                        <div className="progress-track" style={{ flex: 1 }}>
                          <div className="progress-fill" style={{ width: `${insight.confidence}%`, background: color }} />
                        </div>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color, fontWeight: 700 }}>{insight.confidence}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Channel Performance */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 22px' }}>
          <ChartHeader title="Channel Performance" subtitle="Leads, CPL & ROAS · Jul 2025" />
          <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 8 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Channel', 'Leads', 'CPL', 'ROAS'].map(h => (
                  <th key={h} style={{ padding: '6px 8px', fontSize: 10, fontWeight: 700, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: h === 'Channel' ? 'left' : 'right' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {channelPerformance.map((row, i) => (
                <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <td style={{ padding: '11px 8px', fontSize: 13, color: 'var(--text)', fontWeight: 500 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 6, height: 6, borderRadius: 2, background: ['#6366f1','#4285f4','#0077b5','#e1306c','#25d366','#8b5cf6'][i], flexShrink: 0 }} />
                      {row.channel}
                    </div>
                  </td>
                  <td style={{ padding: '11px 8px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>{row.leads.toLocaleString()}</td>
                  <td style={{ padding: '11px 8px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-3)' }}>₹{row.cpl}</td>
                  <td style={{ padding: '11px 8px', textAlign: 'right' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700, color: row.roas > 50 ? 'var(--green)' : row.roas > 20 ? 'var(--amber)' : 'var(--text-3)' }}>{row.roas}x</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Activity Feed */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 18, padding: '20px 18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <Activity size={14} style={{ color: 'var(--text-3)' }} />
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>Activity Feed</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', position: 'relative' }}>
            <div style={{ position: 'absolute', left: 9, top: 10, bottom: 10, width: 1, background: 'var(--border)' }} />
            {ACTIVITY.map((item, i) => {
              const Icon = item.icon
              return (
                <div key={i} style={{ display: 'flex', gap: 10, paddingBottom: i < ACTIVITY.length - 1 ? 14 : 0, position: 'relative' }}>
                  <div style={{ width: 20, height: 20, borderRadius: '50%', background: item.color + '18', border: `1.5px solid ${item.color}40`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, zIndex: 1 }}>
                    <Icon size={9} style={{ color: item.color }} />
                  </div>
                  <div style={{ paddingTop: 1 }}>
                    <div style={{ fontSize: 12, color: 'var(--text-2)', lineHeight: 1.4 }}>{item.text}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginTop: 2, fontSize: 10, color: 'var(--text-4)' }}>
                      <Clock size={8} /> {item.sub}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

function ChartHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{title}</div>
      {subtitle && <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{subtitle}</div>}
    </div>
  )
}
