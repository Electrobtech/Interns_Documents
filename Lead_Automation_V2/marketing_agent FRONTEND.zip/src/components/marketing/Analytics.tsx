import { Download, Share2, BarChart3, RefreshCw, Sparkles, TrendingUp } from 'lucide-react'
import { AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts'
import { performanceData, revenueData, funnelData, platformData, channelPerformance } from '../../data/mockData'
import { useToast } from '../ui/Toast'

export default function Analytics() {
  const { show } = useToast()

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, flexWrap: 'wrap', flexShrink: 0, alignItems: 'center' }}>
        <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', flex: 1 }}>Analytics</span>
        <select style={selectStyle}>
          {['Last 30 days', 'Last 7 days', 'Last 90 days', 'This year', 'Custom'].map(o => <option key={o}>{o}</option>)}
        </select>
        <select style={selectStyle}>
          {['All Campaigns', 'Active Only', 'Facebook', 'Google Ads', 'WhatsApp'].map(o => <option key={o}>{o}</option>)}
        </select>
        {[
          { icon: BarChart3, label: 'Compare' },
          { icon: Sparkles, label: 'AI Report' },
          { icon: Share2, label: 'Share' },
          { icon: Download, label: 'Export' },
          { icon: RefreshCw, label: 'Refresh' },
        ].map(({ icon: Icon, label }) => (
          <button key={label} onClick={() => show(`${label} triggered`, 'info')} style={toolBtn}><Icon size={13} /> {label}</button>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* KPI Strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {[
            { label: 'Total Revenue', value: '₹52.6L', change: '+34%', up: true },
            { label: 'Total Leads', value: '28,420', change: '+28%', up: true },
            { label: 'Avg CTR', value: '4.8%', change: '+0.4%', up: true },
            { label: 'Campaign ROI', value: '294%', change: '+42%', up: true },
          ].map(m => (
            <div key={m.label} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: '14px 16px' }}>
              <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{m.label}</div>
              <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)', marginTop: 4, fontFamily: 'JetBrains Mono' }}>{m.value}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4, fontSize: 12, color: m.up ? '#10b981' : '#ef4444' }}>
                <TrendingUp size={11} /> {m.change} vs last period
              </div>
            </div>
          ))}
        </div>

        {/* Revenue + Leads */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div style={cardStyle}>
            <SectionHdr title="Revenue Trend" subtitle="₹ Monthly revenue vs target" />
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#252538" />
                <XAxis dataKey="month" tick={{ fill: '#6b6b8c', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#6b6b8c', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
                <Area type="monotone" dataKey="revenue" stroke="#6366f1" fill="url(#revGrad)" strokeWidth={2} name="Revenue" />
                <Line type="monotone" dataKey="target" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" dot={false} name="Target" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div style={cardStyle}>
            <SectionHdr title="Campaign Performance" subtitle="Impressions, clicks & leads over time" />
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#252538" />
                <XAxis dataKey="month" tick={{ fill: '#6b6b8c', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#6b6b8c', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="leads" fill="#6366f1" radius={[4, 4, 0, 0]} name="Leads" />
                <Bar dataKey="conversions" fill="#10b981" radius={[4, 4, 0, 0]} name="Conversions" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Channel + Platform */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
          {/* Funnel */}
          <div style={cardStyle}>
            <SectionHdr title="Conversion Funnel" subtitle="Top to bottom of funnel" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8 }}>
              {funnelData.map((stage, i) => (
                <div key={i}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                    <span style={{ fontSize: 12, color: '#9b9bb8' }}>{stage.stage}</span>
                    <span style={{ fontSize: 12, fontFamily: 'JetBrains Mono', color: 'var(--text)' }}>{stage.value.toLocaleString()}</span>
                  </div>
                  <div style={{ height: 6, background: '#252538', borderRadius: 3 }}>
                    <div style={{ height: '100%', width: `${stage.pct}%`, background: `hsl(${234 + i * 15}, 70%, ${55 + i * 5}%)`, borderRadius: 3 }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Platform Distribution */}
          <div style={cardStyle}>
            <SectionHdr title="Platform Distribution" subtitle="Spend by platform" />
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={platformData} cx="50%" cy="50%" innerRadius={44} outerRadius={68} paddingAngle={3} dataKey="value">
                  {platformData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px 10px' }}>
              {platformData.map(p => (
                <span key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: '#9b9bb8' }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: p.color }} />{p.name}
                </span>
              ))}
            </div>
          </div>

          {/* Channel ROAS */}
          <div style={cardStyle}>
            <SectionHdr title="Channel ROAS" subtitle="Return on ad spend by channel" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8 }}>
              {channelPerformance.sort((a, b) => b.roas - a.roas).map((ch, i) => (
                <div key={i}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                    <span style={{ fontSize: 12, color: '#9b9bb8' }}>{ch.channel}</span>
                    <span style={{ fontSize: 12, fontFamily: 'JetBrains Mono', fontWeight: 600, color: ch.roas > 50 ? '#10b981' : '#f59e0b' }}>{ch.roas}x</span>
                  </div>
                  <div style={{ height: 4, background: '#252538', borderRadius: 2 }}>
                    <div style={{ height: '100%', width: `${Math.min(ch.roas / 2, 100)}%`, background: ch.roas > 50 ? '#10b981' : '#f59e0b', borderRadius: 2 }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function SectionHdr({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>{title}</div>
      {subtitle && <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{subtitle}</div>}
    </div>
  )
}

const cardStyle: React.CSSProperties = { background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }
const toolBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 11px', fontSize: 12, color: '#9b9bb8', cursor: 'pointer', fontFamily: 'DM Sans' }
const selectStyle: React.CSSProperties = { background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 10px', fontSize: 12, color: '#9b9bb8', outline: 'none', cursor: 'pointer', fontFamily: 'DM Sans' }
