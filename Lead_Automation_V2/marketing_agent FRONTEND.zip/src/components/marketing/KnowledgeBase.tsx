import { useState } from 'react'
import { Search, Upload, FolderPlus, Filter, SortAsc, Sparkles, FileText, Tag, Clock } from 'lucide-react'
import { knowledgeDocs } from '../../data/mockData'
import { useToast } from '../ui/Toast'

const CATEGORIES = ['All', 'Marketing Docs', 'Brand Guidelines', 'Reports', 'Case Studies', 'Templates', 'FAQs']

export default function KnowledgeBase() {
  const { show } = useToast()
  const [cat, setCat] = useState('All')
  const [search, setSearch] = useState('')
  const [aiQuery, setAiQuery] = useState('')

  const filtered = knowledgeDocs.filter(d =>
    (cat === 'All' || d.category === cat) &&
    d.title.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, flexShrink: 0, flexWrap: 'wrap', alignItems: 'center' }}>
        <button onClick={() => show('Upload document', 'info')} style={primaryBtn}><Upload size={14} /> Upload</button>
        <button onClick={() => show('New folder created', 'success')} style={toolBtn}><FolderPlus size={13} /> New Folder</button>
        <button onClick={() => show('Filters opened', 'info')} style={toolBtn}><Filter size={13} /> Filters</button>
        <button style={toolBtn}><SortAsc size={13} /> Sort</button>
        <div style={{ flex: 1 }} />
        <div style={{ position: 'relative' }}>
          <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-3)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search documents…" style={{ ...inputStyle, paddingLeft: 30, width: 220 }} />
        </div>
      </div>

      {/* AI Search */}
      <div style={{ padding: '12px 24px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
        <div style={{ position: 'relative', maxWidth: 560 }}>
          <Sparkles size={13} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#6366f1' }} />
          <input
            value={aiQuery} onChange={e => setAiQuery(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && aiQuery) show(`AI Search: "${aiQuery}" — Found 3 relevant documents`, 'info') }}
            placeholder="Ask AI: 'What was our ROAS in Q2?' or 'Show brand voice guidelines…'"
            style={{ ...inputStyle, paddingLeft: 34, background: '#6366f110', border: '1px solid #6366f130', width: '100%' }}
          />
          <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', fontSize: 10, color: '#6366f1', background: '#6366f120', padding: '2px 7px', borderRadius: 5, pointerEvents: 'none' }}>Enter</span>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
        {/* Category chips */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 }}>
          {CATEGORIES.map(c => (
            <button key={c} onClick={() => setCat(c)} style={{ padding: '6px 14px', background: cat === c ? '#6366f120' : '#13131e', border: `1px solid ${cat === c ? '#6366f1' : '#252538'}`, borderRadius: 99, fontSize: 12, color: cat === c ? '#6366f1' : '#9b9bb8', cursor: 'pointer' }}>
              {c}
            </button>
          ))}
        </div>

        {/* Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
          {filtered.map(doc => (
            <div key={doc.id} onClick={() => show(`Opening: ${doc.title}`, 'info')} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px', cursor: 'pointer', transition: 'border-color 0.15s' }}
              onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = '#6366f1'}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = '#252538'}>
              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 10 }}>
                <div style={{ width: 36, height: 36, borderRadius: 8, background: '#6366f120', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <FileText size={16} style={{ color: '#6366f1' }} />
                </div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text)' }}>{doc.title}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{doc.category}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
                {doc.tags.map(tag => (
                  <span key={tag} style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 10, background: 'var(--surface-2)', border: '1px solid var(--border)', padding: '2px 7px', borderRadius: 5, color: '#9b9bb8' }}>
                    <Tag size={8} /> {tag}
                  </span>
                ))}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--text-3)' }}>
                  <Clock size={10} /> {doc.updatedAt}
                </span>
                <span style={{ fontSize: 11, color: 'var(--text-3)' }}>{doc.size}</span>
              </div>
            </div>
          ))}

          {filtered.length === 0 && (
            <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '60px 0', color: 'var(--text-3)' }}>
              <FileText size={32} style={{ opacity: 0.3, marginBottom: 12 }} />
              <div>No documents found</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const toolBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 11px', fontSize: 12, color: '#9b9bb8', cursor: 'pointer', fontFamily: 'DM Sans' }
const inputStyle: React.CSSProperties = { background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', fontFamily: 'DM Sans' }
