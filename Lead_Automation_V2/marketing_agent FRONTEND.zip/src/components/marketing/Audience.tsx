import { useState } from 'react'
import { Plus, Upload, Download, Search, Filter, Users, Target, TrendingUp, Star } from 'lucide-react'
import { audiences } from '../../data/mockData'
import { useToast } from '../ui/Toast'

const TABS = ['All Audiences', 'Segments', 'Custom Audiences', 'Lookalikes', 'Lead Scoring', 'Saved Filters']

export default function Audience() {
  const { show } = useToast()
  const [tab, setTab] = useState('All Audiences')
  const [search, setSearch] = useState('')

  const filtered = audiences.filter(a => a.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
        <button onClick={() => show('Create audience', 'info')} style={primaryBtn}><Plus size={14} /> Create Audience</button>
        <button onClick={() => show('Import started', 'info')} style={toolBtn}><Upload size={13} /> Import</button>
        <button onClick={() => show('Exported', 'success')} style={toolBtn}><Download size={13} /> Export</button>
        <div style={{ flex: 1 }} />
        <div style={{ position: 'relative' }}>
          <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-3)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search audiences…" style={{ ...inputStyle, paddingLeft: 30, width: 200 }} />
        </div>
        <button style={iconBtn}><Filter size={14} /></button>
      </div>

      {/* Sub-tabs */}
      <div style={{ padding: '0 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 0, overflowX: 'auto', flexShrink: 0 }} className="scrollbar-hide">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding: '12px 16px', fontSize: 13, fontWeight: tab === t ? 600 : 400, color: tab === t ? '#6366f1' : '#6b6b8c', background: 'none', border: 'none', cursor: 'pointer', borderBottom: `2px solid ${tab === t ? '#6366f1' : 'transparent'}`, whiteSpace: 'nowrap' }}>
            {t}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
        {/* Stats Row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Total Audiences', value: '24', icon: Users, color: '#6366f1' },
            { label: 'Total Reach', value: '2.1M', icon: Target, color: '#10b981' },
            { label: 'Avg Quality Score', value: '86/100', icon: Star, color: '#f59e0b' },
            { label: 'High-Intent Segments', value: '8', icon: TrendingUp, color: '#3b82f6' },
          ].map(s => {
            const Icon = s.icon
            return (
              <div key={s.label} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: '14px 16px', display: 'flex', gap: 12, alignItems: 'center' }}>
                <div style={{ width: 36, height: 36, borderRadius: 9, background: s.color + '20', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon size={16} style={{ color: s.color }} />
                </div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--text)', fontFamily: 'JetBrains Mono' }}>{s.value}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{s.label}</div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Audience Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
          {filtered.map(a => (
            <div key={a.id} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px', cursor: 'pointer', transition: 'border-color 0.15s' }}
              onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = '#6366f1'}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = '#252538'}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text)' }}>{a.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>Source: {a.source} · Updated {a.lastUpdated}</div>
                </div>
                <span style={{ fontSize: 11, fontWeight: 600, color: '#10b981', background: '#10b98120', padding: '2px 8px', borderRadius: 5 }}>{a.status}</span>
              </div>
              <div style={{ display: 'flex', gap: 20, marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>Size</div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)', fontFamily: 'JetBrains Mono' }}>{a.size.toLocaleString()}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>Quality Score</div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: a.score >= 90 ? '#10b981' : a.score >= 70 ? '#f59e0b' : '#ef4444', fontFamily: 'JetBrains Mono' }}>{a.score}/100</div>
                </div>
              </div>
              <div style={{ height: 4, background: '#252538', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${a.score}%`, background: a.score >= 90 ? '#10b981' : a.score >= 70 ? '#f59e0b' : '#ef4444', borderRadius: 2 }} />
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <button onClick={() => show(`Using ${a.name} in campaign`, 'info')} style={{ flex: 1, padding: '7px', background: '#6366f115', border: '1px solid #6366f130', borderRadius: 7, fontSize: 12, color: '#6366f1', cursor: 'pointer' }}>Use in Campaign</button>
                <button onClick={() => show(`Editing ${a.name}`, 'info')} style={{ flex: 1, padding: '7px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer' }}>Edit</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const toolBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 11px', fontSize: 12, color: '#9b9bb8', cursor: 'pointer', fontFamily: 'DM Sans' }
const iconBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, cursor: 'pointer', color: '#9b9bb8' }
const inputStyle: React.CSSProperties = { background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '7px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', fontFamily: 'DM Sans' }
