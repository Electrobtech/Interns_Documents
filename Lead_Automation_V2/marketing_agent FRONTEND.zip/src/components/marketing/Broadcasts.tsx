import { useState } from 'react'
import { Plus, Copy, Trash2, Download, FileText, Calendar, Zap, MoreHorizontal, Bold, Italic, Smile, Variable, Image, Video, FileIcon, X, Check, ChevronRight, ChevronLeft, Sparkles } from 'lucide-react'
import { broadcasts } from '../../data/mockData'
import Badge from '../ui/Badge'
import { useToast } from '../ui/Toast'

export default function Broadcasts() {
  const { show } = useToast()
  const [showCreate, setShowCreate] = useState(false)
  const [wizardStep, setWizardStep] = useState(0)
  const [msgContent, setMsgContent] = useState('')

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
        <button onClick={() => { setShowCreate(true); setWizardStep(0) }} style={primaryBtn}>
          <Plus size={14} /> Create Broadcast
        </button>
        {[Copy, Trash2, Download, FileText, Calendar, Zap].map((Icon, i) => (
          <button key={i} onClick={() => show(['Duplicate', 'Delete', 'Export', 'Templates', 'Schedule', 'AI Generate'][i] + ' triggered', 'info')} style={toolBtn}>
            <Icon size={13} /> {['Duplicate', 'Delete', 'Export', 'Templates', 'Schedule', 'AI Generate'][i]}
          </button>
        ))}
      </div>

      {/* Table */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
          <thead>
            <tr style={{ position: 'sticky', top: 0, background: '#0d0d14', borderBottom: '1px solid var(--border)' }}>
              <th style={th}><input type="checkbox" style={{ accentColor: '#6366f1' }} /></th>
              {['Name', 'Channel', 'Audience', 'Status', 'Sent', 'Delivered', 'Opened', 'Clicked', 'Responses', 'Conv.%', 'AI Score', ''].map(h => (
                <th key={h} style={{ ...th, textAlign: ['Sent', 'Delivered', 'Opened', 'Clicked', 'Responses', 'Conv.%', 'AI Score'].includes(h) ? 'right' : 'left' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {broadcasts.map(b => (
              <tr key={b.id} style={{ borderBottom: '1px solid #1a1a2e' }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#1a1a2e'}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}>
                <td style={td}><input type="checkbox" style={{ accentColor: '#6366f1' }} /></td>
                <td style={td}><div style={{ fontWeight: 600, fontSize: 13, color: 'var(--text)' }}>{b.name}</div></td>
                <td style={td}><ChannelBadge channel={b.channel} /></td>
                <td style={{ ...td, fontSize: 12, color: '#9b9bb8' }}>{b.audience}</td>
                <td style={td}><Badge label={b.status} variant={b.status.toLowerCase() as any} /></td>
                {[b.sent, b.delivered, b.opened, b.clicked, b.responses].map((v, i) => (
                  <td key={i} style={{ ...td, textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 12, color: '#9b9bb8' }}>{v.toLocaleString()}</td>
                ))}
                <td style={{ ...td, textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 12, color: b.conversion > 15 ? '#10b981' : b.conversion > 5 ? '#f59e0b' : '#9b9bb8' }}>{b.conversion}%</td>
                <td style={{ ...td, textAlign: 'right' }}>
                  <span style={{ fontSize: 11, fontFamily: 'JetBrains Mono', fontWeight: 700, color: b.aiScore >= 85 ? '#10b981' : '#f59e0b', background: (b.aiScore >= 85 ? '#10b981' : '#f59e0b') + '18', padding: '2px 8px', borderRadius: 99 }}>{b.aiScore}</span>
                </td>
                <td style={td}>
                  <button onClick={() => show(`Actions for ${b.name}`, 'info')} style={iconBtn}><MoreHorizontal size={14} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Create Broadcast Wizard */}
      {showCreate && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 680, maxWidth: 'calc(100vw - 32px)', maxHeight: '90vh', background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 16, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text)' }}>Create Broadcast</div>
                <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Step {wizardStep + 1} of 3: {['Setup', 'Message Builder', 'Schedule'][wizardStep]}</div>
              </div>
              <button onClick={() => setShowCreate(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)' }}><X size={18} /></button>
            </div>

            {/* Steps indicator */}
            <div style={{ padding: '12px 24px', display: 'flex', gap: 8, borderBottom: '1px solid #1a1a2e' }}>
              {['Setup', 'Message Builder', 'Schedule'].map((s, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 20, height: 20, borderRadius: '50%', background: i < wizardStep ? '#6366f1' : i === wizardStep ? '#6366f1' : '#252538', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: i <= wizardStep ? '#fff' : '#6b6b8c' }}>
                    {i < wizardStep ? <Check size={10} /> : i + 1}
                  </div>
                  <span style={{ fontSize: 12, color: i === wizardStep ? '#e4e4f0' : '#6b6b8c' }}>{s}</span>
                  {i < 2 && <ChevronRight size={12} style={{ color: '#252538' }} />}
                </div>
              ))}
            </div>

            <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
              {wizardStep === 0 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {[
                    { label: 'Broadcast Name', placeholder: 'e.g. Flash Sale - August' },
                    { label: 'Channel', isSelect: true, options: ['WhatsApp', 'Email', 'SMS', 'Telegram'] },
                    { label: 'Template', isSelect: true, options: ['None', 'Welcome Template', 'Promo Template', 'Reminder Template'] },
                    { label: 'Audience', isSelect: true, options: ['All Subscribers', 'New Leads', 'Active Users', 'Cold Leads', 'Custom Segment'] },
                  ].map(f => (
                    <div key={f.label}>
                      <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: '#9b9bb8', marginBottom: 6 }}>{f.label}</label>
                      {f.isSelect ? (
                        <select style={inputStyle}>{f.options!.map(o => <option key={o}>{o}</option>)}</select>
                      ) : (
                        <input placeholder={f.placeholder} style={inputStyle} />
                      )}
                    </div>
                  ))}
                </div>
              )}
              {wizardStep === 1 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {/* Formatting Toolbar */}
                  <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', padding: '8px 10px', background: 'var(--surface-2)', borderRadius: 8, border: '1px solid var(--border)' }}>
                    {[Bold, Italic, Smile, Variable, Image, Video, FileIcon].map((Icon, i) => (
                      <button key={i} onClick={() => show('Formatting applied', 'info')} style={{ width: 30, height: 30, background: 'none', border: 'none', cursor: 'pointer', color: '#9b9bb8', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Icon size={14} />
                      </button>
                    ))}
                    <div style={{ width: 1, background: '#252538', margin: '4px 6px' }} />
                    {['Poll', 'Location', 'Buttons'].map(t => (
                      <button key={t} style={{ padding: '4px 10px', background: 'none', border: '1px solid var(--border)', borderRadius: 6, fontSize: 11, color: '#9b9bb8', cursor: 'pointer' }}>{t}</button>
                    ))}
                  </div>
                  <textarea
                    value={msgContent} onChange={e => setMsgContent(e.target.value)}
                    placeholder="Type your message here…&#10;&#10;Use {{name}}, {{company}} for personalization."
                    style={{ ...inputStyle, height: 160, resize: 'none', lineHeight: 1.7 }}
                  />
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    {['Generate AI Message', 'Grammar Check', 'Translate', 'Shorten', 'Expand'].map(a => (
                      <button key={a} onClick={() => show(`${a} applied`, 'success')} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', background: '#6366f115', border: '1px solid #6366f130', borderRadius: 7, fontSize: 12, color: '#6366f1', cursor: 'pointer' }}>
                        <Sparkles size={11} /> {a}
                      </button>
                    ))}
                  </div>
                  {/* Preview */}
                  <div style={{ background: 'var(--surface-2)', borderRadius: 10, padding: 16 }}>
                    <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 8 }}>WhatsApp Preview</div>
                    <div style={{ background: '#25d36615', border: '1px solid #25d36630', borderRadius: 8, padding: '10px 14px', maxWidth: 280 }}>
                      <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.6 }}>{msgContent || 'Your message preview will appear here…'}</div>
                    </div>
                  </div>
                </div>
              )}
              {wizardStep === 2 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {['Send Now', 'Schedule Later', 'Recurring', 'Smart Time'].map((opt, i) => (
                    <div key={opt} style={{ display: 'flex', alignItems: 'center', gap: 12, background: i === 0 ? '#6366f110' : '#1a1a2e', border: `1px solid ${i === 0 ? '#6366f1' : '#252538'}`, borderRadius: 10, padding: '14px 16px', cursor: 'pointer' }}>
                      <div style={{ width: 16, height: 16, borderRadius: '50%', border: `2px solid ${i === 0 ? '#6366f1' : '#252538'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {i === 0 && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#6366f1' }} />}
                      </div>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{opt}</div>
                        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{['Send immediately to all selected contacts', 'Pick a specific date and time', 'Set up recurring broadcasts', 'AI-suggested optimal send time'][i]}</div>
                      </div>
                    </div>
                  ))}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <div>
                      <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: '#9b9bb8', marginBottom: 6 }}>Date</label>
                      <input type="date" style={inputStyle} />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: '#9b9bb8', marginBottom: 6 }}>Timezone</label>
                      <select style={inputStyle}>
                        {['IST', 'UTC', 'EST', 'PST'].map(t => <option key={t}>{t}</option>)}
                      </select>
                    </div>
                  </div>
                  <div style={{ background: '#6366f110', border: '1px solid #6366f130', borderRadius: 10, padding: 12 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#6366f1', marginBottom: 4 }}>A/B Test</div>
                    <div style={{ fontSize: 12, color: '#9b9bb8' }}>Split audience 50/50 to test message variants. Results tracked in Analytics.</div>
                  </div>
                </div>
              )}
            </div>

            <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border)', display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button onClick={() => setShowCreate(false)} style={{ padding: '8px 16px', background: 'none', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: 'var(--text-3)', cursor: 'pointer' }}>Cancel</button>
              {wizardStep > 0 && <button onClick={() => setWizardStep(s => s - 1)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: '#9b9bb8', cursor: 'pointer' }}><ChevronLeft size={14} /> Back</button>}
              <button onClick={() => show('Draft saved', 'info')} style={{ padding: '8px 16px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: '#9b9bb8', cursor: 'pointer' }}>Save Draft</button>
              {wizardStep < 2
                ? <button onClick={() => setWizardStep(s => s + 1)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 20px', background: '#6366f1', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer' }}>Next <ChevronRight size={14} /></button>
                : <button onClick={() => { setShowCreate(false); show('Broadcast published!') }} style={{ padding: '8px 20px', background: '#6366f1', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer' }}>Publish</button>
              }
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function ChannelBadge({ channel }: { channel: string }) {
  const colors: Record<string, string> = { WhatsApp: '#25d366', Email: '#8b5cf6', SMS: '#f59e0b', Telegram: '#0088cc' }
  const c = colors[channel] || '#9b9bb8'
  return <span style={{ fontSize: 11, fontWeight: 600, color: c, background: c + '18', padding: '2px 8px', borderRadius: 5 }}>{channel}</span>
}

const th: React.CSSProperties = { padding: '10px 12px', fontSize: 11, fontWeight: 600, color: 'var(--text-3)', letterSpacing: '0.05em', whiteSpace: 'nowrap', background: '#0d0d14', textAlign: 'left' }
const td: React.CSSProperties = { padding: '12px 12px', fontSize: 13, color: 'var(--text)', whiteSpace: 'nowrap', verticalAlign: 'middle' }
const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const toolBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 11px', fontSize: 12, color: '#9b9bb8', cursor: 'pointer', fontFamily: 'DM Sans' }
const iconBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 30, height: 30, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, cursor: 'pointer', color: '#9b9bb8' }
const inputStyle: React.CSSProperties = { width: '100%', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', fontFamily: 'DM Sans' }
