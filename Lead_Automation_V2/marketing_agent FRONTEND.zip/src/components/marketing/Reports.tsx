import { FileText, Download, BarChart3, Calendar, Plus, Sparkles } from 'lucide-react'
import { useToast } from '../ui/Toast'

const TEMPLATES = [
  { id: '1', name: 'Campaign Performance Report', desc: 'Full breakdown of all campaigns: spend, ROAS, leads, conversions', icon: BarChart3, color: '#6366f1', last: '2025-07-31' },
  { id: '2', name: 'Monthly Marketing Report', desc: 'Executive summary of monthly marketing activities and results', icon: Calendar, color: '#10b981', last: '2025-07-01' },
  { id: '3', name: 'ROI & Revenue Report', desc: 'Revenue attribution, cost analysis, and return on investment', icon: BarChart3, color: '#f59e0b', last: '2025-07-15' },
  { id: '4', name: 'Lead Generation Report', desc: 'Lead sources, quality scores, and conversion funnel analysis', icon: FileText, color: '#3b82f6', last: '2025-07-28' },
  { id: '5', name: 'Executive Summary', desc: 'High-level KPIs and strategic insights for leadership review', icon: FileText, color: '#8b5cf6', last: '2025-07-31' },
  { id: '6', name: 'Competitor Benchmarking', desc: 'Side-by-side comparison against key competitors', icon: BarChart3, color: '#ef4444', last: '2025-07-20' },
]

export default function Reports() {
  const { show } = useToast()

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, flexShrink: 0, alignItems: 'center' }}>
        <button onClick={() => show('Custom report builder opened', 'info')} style={primaryBtn}><Plus size={14} /> New Report</button>
        <button onClick={() => show('Generating AI report…', 'info')} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', background: '#6366f115', border: '1px solid #6366f130', borderRadius: 8, fontSize: 13, color: '#6366f1', cursor: 'pointer' }}>
          <Sparkles size={14} /> AI Report
        </button>
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 6 }}>
          {['Export All as PDF', 'Export All as Excel', 'Export All as CSV'].map(a => (
            <button key={a} onClick={() => show(a, 'success')} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer' }}>
              <Download size={12} /> {a.split(' ').slice(-1)[0]}
            </button>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
        {/* Recent Reports */}
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 14 }}>Report Templates</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 12 }}>
            {TEMPLATES.map(t => {
              const Icon = t.icon
              return (
                <div key={t.id} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '18px 20px', cursor: 'pointer', transition: 'border-color 0.15s' }}
                  onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = t.color}
                  onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = '#252538'}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 12 }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: t.color + '20', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Icon size={18} style={{ color: t.color }} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text)' }}>{t.name}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2, lineHeight: 1.4 }}>{t.desc}</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 12 }}>Last generated: {t.last}</div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => show(`Generating ${t.name}…`, 'info')} style={{ flex: 1, padding: '7px', background: t.color + '15', border: `1px solid ${t.color}30`, borderRadius: 7, fontSize: 12, color: t.color, cursor: 'pointer' }}>Generate</button>
                    <button onClick={() => show(`Downloading ${t.name}`, 'success')} style={{ padding: '7px 12px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
                      <Download size={12} /> PDF
                    </button>
                    <button onClick={() => show(`Downloading ${t.name}`, 'success')} style={{ padding: '7px 12px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
                      <Download size={12} /> CSV
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Scheduled Reports */}
        <div>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 14 }}>Scheduled Reports</div>
          <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden' }}>
            {[
              { name: 'Weekly Campaign Digest', frequency: 'Every Monday 9 AM', recipients: 'Team (4)', status: 'Active', next: '2025-08-04' },
              { name: 'Monthly Executive Summary', frequency: '1st of each month', recipients: 'Leadership (2)', status: 'Active', next: '2025-09-01' },
              { name: 'Daily Spend Alert', frequency: 'Daily 8 PM', recipients: 'Priya Sharma', status: 'Paused', next: '—' },
            ].map((r, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', padding: '14px 20px', borderBottom: i < 2 ? '1px solid #252538' : 'none', gap: 16 }}>
                <FileText size={16} style={{ color: 'var(--text-3)', flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{r.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{r.frequency} · To: {r.recipients}</div>
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-3)' }}>Next: {r.next}</div>
                <span style={{ fontSize: 11, fontWeight: 600, color: r.status === 'Active' ? '#10b981' : '#f59e0b', background: (r.status === 'Active' ? '#10b981' : '#f59e0b') + '20', padding: '2px 8px', borderRadius: 5 }}>{r.status}</span>
                <button onClick={() => show(`Editing ${r.name}`, 'info')} style={{ padding: '5px 10px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, fontSize: 12, color: '#9b9bb8', cursor: 'pointer' }}>Edit</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
