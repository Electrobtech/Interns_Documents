import { useState } from 'react'
import { Check, ChevronRight, ChevronLeft, X, Sparkles, AlertCircle } from 'lucide-react'
import { useToast } from '../ui/Toast'

interface Props { onClose: () => void; onCreated?: (c: any) => void }

const STEPS = [
  'Campaign Info', 'Objective', 'Platforms', 'Budget', 'Audience',
  'Placements', 'Creatives', 'Tracking', 'Review', 'Publish'
]

const OBJECTIVES = ['Lead Generation', 'Website Traffic', 'Sales', 'Engagement', 'Brand Awareness', 'Event Registration', 'Webinar', 'Course Registration', 'Remarketing', 'Conversion']
const PLATFORMS = ['Facebook', 'Instagram', 'LinkedIn', 'Google Ads', 'WhatsApp', 'Messenger', 'Telegram', 'Email', 'SMS', 'Web Push']
const PLACEMENTS = ['Facebook Feed', 'Instagram Feed', 'Stories', 'Reels', 'Messenger', 'Audience Network']

export default function CreateCampaignWizard({ onClose }: Props) {
  const { show } = useToast()
  const [step, setStep] = useState(0)
  const [form, setForm] = useState({
    name: '', description: '', tags: '', owner: 'Priya Sharma', priority: 'Medium',
    objective: '', platforms: [] as string[], placements: [] as string[],
    dailyBudget: '', lifetimeBudget: '', currency: 'INR', bidStrategy: 'Lowest Cost',
    startDate: '', endDate: '', timezone: 'IST',
    locations: '', ageMin: '18', ageMax: '45', gender: 'All',
    headline: '', description2: '', cta: 'Learn More', landingPage: '',
    utm: '', pixel: '', conversionEvent: '',
  })

  const update = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))
  const togglePlatform = (p: string) => setForm(f => ({ ...f, platforms: f.platforms.includes(p) ? f.platforms.filter(x => x !== p) : [...f.platforms, p] }))
  const togglePlacement = (p: string) => setForm(f => ({ ...f, placements: f.placements.includes(p) ? f.placements.filter(x => x !== p) : [...f.placements, p] }))

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ width: 760, maxWidth: 'calc(100vw - 32px)', maxHeight: '92vh', background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 16, display: 'flex', flexDirection: 'column', overflow: 'hidden', boxShadow: '0 24px 80px rgba(0,0,0,0.7)' }}>
        {/* Header */}
        <div style={{ padding: '20px 28px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, color: 'var(--text)' }}>Create Campaign</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Step {step + 1} of {STEPS.length}: {STEPS[step]}</div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)', padding: 4 }}><X size={18} /></button>
        </div>

        {/* Step Progress */}
        <div style={{ padding: '16px 28px', borderBottom: '1px solid #1a1a2e', display: 'flex', gap: 4, overflowX: 'auto', flexShrink: 0 }} className="scrollbar-hide">
          {STEPS.map((s, i) => (
            <button key={i} onClick={() => i < step && setStep(i)} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: i <= step ? 'pointer' : 'default', padding: '4px 0', flexShrink: 0 }}>
              <div style={{ width: 22, height: 22, borderRadius: '50%', background: i < step ? '#6366f1' : i === step ? '#6366f1' : '#252538', border: i === step ? '2px solid #6366f150' : 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: i <= step ? '#fff' : '#6b6b8c', flexShrink: 0 }}>
                {i < step ? <Check size={10} /> : i + 1}
              </div>
              <span style={{ fontSize: 11, color: i === step ? '#e4e4f0' : i < step ? '#6366f1' : '#6b6b8c', whiteSpace: 'nowrap' }}>{s}</span>
              {i < STEPS.length - 1 && <ChevronRight size={12} style={{ color: '#252538', marginLeft: 2 }} />}
            </button>
          ))}
        </div>

        {/* Step Content */}
        <div style={{ flex: 1, overflow: 'auto', padding: 28 }}>
          {step === 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <FieldGroup label="Campaign Name" required>
                <Input value={form.name} onChange={v => update('name', v)} placeholder="e.g. AI Bootcamp Lead Gen Q3" />
              </FieldGroup>
              <FieldGroup label="Description">
                <textarea value={form.description} onChange={e => update('description', e.target.value)} placeholder="Describe your campaign goal…" style={{ ...inputStyle, height: 80, resize: 'none' }} />
              </FieldGroup>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                <FieldGroup label="Tags"><Input value={form.tags} onChange={v => update('tags', v)} placeholder="lead-gen, q3, india" /></FieldGroup>
                <FieldGroup label="Owner">
                  <select value={form.owner} onChange={e => update('owner', e.target.value)} style={inputStyle}>
                    {['Priya Sharma', 'Rahul Verma', 'Ananya Iyer', 'Vikram Singh'].map(o => <option key={o}>{o}</option>)}
                  </select>
                </FieldGroup>
                <FieldGroup label="Priority">
                  <select value={form.priority} onChange={e => update('priority', e.target.value)} style={inputStyle}>
                    {['Low', 'Medium', 'High', 'Critical'].map(p => <option key={p}>{p}</option>)}
                  </select>
                </FieldGroup>
              </div>
            </div>
          )}
          {step === 1 && (
            <div>
              <p style={{ fontSize: 13, color: '#9b9bb8', marginBottom: 16 }}>Select the primary goal for this campaign.</p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 10 }}>
                {OBJECTIVES.map(obj => (
                  <button key={obj} onClick={() => update('objective', obj)} style={{ padding: '16px 12px', background: form.objective === obj ? '#6366f120' : '#1a1a2e', border: `1px solid ${form.objective === obj ? '#6366f1' : '#252538'}`, borderRadius: 10, fontSize: 13, fontWeight: form.objective === obj ? 600 : 400, color: form.objective === obj ? '#6366f1' : '#9b9bb8', cursor: 'pointer', textAlign: 'center', transition: 'all 0.15s' }}>
                    {obj}
                  </button>
                ))}
              </div>
            </div>
          )}
          {step === 2 && (
            <div>
              <p style={{ fontSize: 13, color: '#9b9bb8', marginBottom: 16 }}>Select one or more platforms. You can run multi-channel campaigns.</p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10 }}>
                {PLATFORMS.map(p => (
                  <button key={p} onClick={() => togglePlatform(p)} style={{ padding: '14px 12px', background: form.platforms.includes(p) ? '#6366f120' : '#1a1a2e', border: `1px solid ${form.platforms.includes(p) ? '#6366f1' : '#252538'}`, borderRadius: 10, fontSize: 13, fontWeight: form.platforms.includes(p) ? 600 : 400, color: form.platforms.includes(p) ? '#6366f1' : '#9b9bb8', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center' }}>
                    {form.platforms.includes(p) && <Check size={12} />}
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}
          {step === 3 && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <FieldGroup label="Daily Budget (₹)"><Input value={form.dailyBudget} onChange={v => update('dailyBudget', v)} placeholder="e.g. 2000" /></FieldGroup>
              <FieldGroup label="Lifetime Budget (₹)"><Input value={form.lifetimeBudget} onChange={v => update('lifetimeBudget', v)} placeholder="e.g. 60000" /></FieldGroup>
              <FieldGroup label="Currency">
                <select value={form.currency} onChange={e => update('currency', e.target.value)} style={inputStyle}>
                  {['INR', 'USD', 'EUR', 'GBP', 'AED'].map(c => <option key={c}>{c}</option>)}
                </select>
              </FieldGroup>
              <FieldGroup label="Bid Strategy">
                <select value={form.bidStrategy} onChange={e => update('bidStrategy', e.target.value)} style={inputStyle}>
                  {['Lowest Cost', 'Target CPA', 'Target ROAS', 'Manual CPC', 'Maximize Conversions'].map(b => <option key={b}>{b}</option>)}
                </select>
              </FieldGroup>
              <FieldGroup label="Start Date"><Input type="date" value={form.startDate} onChange={v => update('startDate', v)} /></FieldGroup>
              <FieldGroup label="End Date"><Input type="date" value={form.endDate} onChange={v => update('endDate', v)} /></FieldGroup>
              <FieldGroup label="Timezone">
                <select value={form.timezone} onChange={e => update('timezone', e.target.value)} style={inputStyle}>
                  {['IST', 'UTC', 'EST', 'PST', 'GST'].map(t => <option key={t}>{t}</option>)}
                </select>
              </FieldGroup>
            </div>
          )}
          {step === 4 && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {[
                  { label: 'Location', key: 'locations', placeholder: 'e.g. India, Mumbai, Delhi' },
                  { label: 'Age Range', key: 'ageMin', placeholder: '18' },
                  { label: 'Gender', key: 'gender', isSelect: true, options: ['All', 'Male', 'Female', 'Non-binary'] },
                ].map(f => (
                  <FieldGroup key={f.label} label={f.label}>
                    {f.isSelect ? (
                      <select value={(form as any)[f.key]} onChange={e => update(f.key, e.target.value)} style={inputStyle}>
                        {f.options!.map(o => <option key={o}>{o}</option>)}
                      </select>
                    ) : <Input value={(form as any)[f.key]} onChange={v => update(f.key, v)} placeholder={f.placeholder} />}
                  </FieldGroup>
                ))}
                {['Interests', 'Education', 'Custom Audience', 'Lookalike Audience'].map(field => (
                  <FieldGroup key={field} label={field}>
                    <Input value="" onChange={() => {}} placeholder={`Select ${field.toLowerCase()}…`} />
                  </FieldGroup>
                ))}
              </div>
              <div style={{ background: '#6366f110', border: '1px solid #6366f130', borderRadius: 12, padding: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 14 }}>
                  <Sparkles size={14} style={{ color: '#6366f1' }} />
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#6366f1' }}>AI Audience Insights</span>
                </div>
                {[
                  { label: 'Estimated Reach', value: '2.4M – 4.1M' },
                  { label: 'Expected Conversion', value: '12.4%' },
                  { label: 'Audience Quality', value: '87/100' },
                  { label: 'High Intent Score', value: '91%' },
                ].map(m => (
                  <div key={m.label} style={{ marginBottom: 12 }}>
                    <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 2 }}>{m.label}</div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', fontFamily: 'JetBrains Mono' }}>{m.value}</div>
                  </div>
                ))}
                <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 14 }}>AI Suggestion</div>
                <div style={{ fontSize: 12, color: '#9b9bb8', marginTop: 4, lineHeight: 1.6 }}>Add "Online Courses" and "Career Development" interests to increase qualified reach by ~18%.</div>
              </div>
            </div>
          )}
          {step === 5 && (
            <div>
              <p style={{ fontSize: 13, color: '#9b9bb8', marginBottom: 16 }}>Select where your ads will appear.</p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                {PLACEMENTS.map(p => (
                  <button key={p} onClick={() => togglePlacement(p)} style={{ padding: '16px', background: form.placements.includes(p) ? '#6366f120' : '#1a1a2e', border: `1px solid ${form.placements.includes(p) ? '#6366f1' : '#252538'}`, borderRadius: 10, fontSize: 13, color: form.placements.includes(p) ? '#6366f1' : '#9b9bb8', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
                    {form.placements.includes(p) && <Check size={12} />}{p}
                  </button>
                ))}
              </div>
            </div>
          )}
          {step === 6 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {['Images', 'Videos', 'Carousel', 'Stories', 'Reels'].map(t => (
                  <button key={t} style={{ padding: '6px 14px', background: t === 'Images' ? '#6366f1' : '#1a1a2e', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: t === 'Images' ? '#fff' : '#9b9bb8', cursor: 'pointer' }}>{t}</button>
                ))}
              </div>
              <div style={{ border: '2px dashed #252538', borderRadius: 12, padding: '32px', textAlign: 'center', cursor: 'pointer', background: 'var(--surface-2)' }}>
                <div style={{ fontSize: 13, color: 'var(--text-3)' }}>Drag & drop media files here</div>
                <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 4 }}>or</div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 12 }}>
                  {['Upload Image', 'Upload Video', 'From Library'].map(a => (
                    <button key={a} style={{ padding: '7px 14px', background: '#252538', border: 'none', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer' }}>{a}</button>
                  ))}
                </div>
              </div>
              <FieldGroup label="Headline"><Input value={form.headline} onChange={v => update('headline', v)} placeholder="Compelling headline…" /></FieldGroup>
              <FieldGroup label="Description"><Input value={form.description2} onChange={v => update('description2', v)} placeholder="Ad description…" /></FieldGroup>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <FieldGroup label="CTA">
                  <select value={form.cta} onChange={e => update('cta', e.target.value)} style={inputStyle}>
                    {['Learn More', 'Sign Up', 'Get Started', 'Book Now', 'Download', 'Contact Us', 'Shop Now'].map(c => <option key={c}>{c}</option>)}
                  </select>
                </FieldGroup>
                <FieldGroup label="Landing Page"><Input value={form.landingPage} onChange={v => update('landingPage', v)} placeholder="https://…" /></FieldGroup>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {['AI Generate Copy', 'AI Generate Headlines', 'AI Generate CTA', 'Preview'].map(a => (
                  <button key={a} style={{ padding: '7px 14px', background: '#6366f115', border: '1px solid #6366f130', borderRadius: 7, fontSize: 12, color: '#6366f1', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Sparkles size={12} /> {a}
                  </button>
                ))}
              </div>
            </div>
          )}
          {step === 7 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <FieldGroup label="UTM Parameters"><Input value={form.utm} onChange={v => update('utm', v)} placeholder="utm_source=facebook&utm_medium=cpc&utm_campaign=…" /></FieldGroup>
              <FieldGroup label="Pixel / Tag ID"><Input value={form.pixel} onChange={v => update('pixel', v)} placeholder="e.g. 1234567890" /></FieldGroup>
              <FieldGroup label="Conversion Event">
                <select value={form.conversionEvent} onChange={e => update('conversionEvent', e.target.value)} style={inputStyle}>
                  {['', 'Lead', 'Purchase', 'Registration', 'View Content', 'Add to Cart'].map(e => <option key={e}>{e}</option>)}
                </select>
              </FieldGroup>
              {['CRM Tracking', 'Google Analytics'].map(t => (
                <div key={t} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--surface-2)', borderRadius: 10, padding: '14px 16px' }}>
                  <span style={{ fontSize: 13, color: '#9b9bb8' }}>{t}</span>
                  <div style={{ width: 36, height: 20, background: '#252538', borderRadius: 99, cursor: 'pointer', position: 'relative' }}>
                    <div style={{ width: 16, height: 16, background: '#6b6b8c', borderRadius: '50%', position: 'absolute', top: 2, left: 2, transition: 'left 0.2s' }} />
                  </div>
                </div>
              ))}
            </div>
          )}
          {step === 8 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ background: '#f59e0b10', border: '1px solid #f59e0b30', borderRadius: 10, padding: 14, display: 'flex', gap: 10 }}>
                <AlertCircle size={16} style={{ color: '#f59e0b', flexShrink: 0, marginTop: 1 }} />
                <div style={{ fontSize: 12, color: '#f59e0b' }}>No pixel configured for Facebook platform. Add a pixel ID to track conversions.</div>
              </div>
              <div style={{ background: 'var(--surface-2)', borderRadius: 10, padding: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', marginBottom: 12 }}>Campaign Summary</div>
                {[
                  { label: 'Name', value: form.name || 'Not set' },
                  { label: 'Objective', value: form.objective || 'Not set' },
                  { label: 'Platforms', value: form.platforms.join(', ') || 'Not set' },
                  { label: 'Daily Budget', value: form.dailyBudget ? `₹${form.dailyBudget}` : 'Not set' },
                  { label: 'Audience', value: 'India · 18–45 · All Genders' },
                ].map(({ label, value }) => (
                  <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                    <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{label}</span>
                    <span style={{ fontSize: 12, color: 'var(--text)', fontWeight: 500 }}>{value}</span>
                  </div>
                ))}
              </div>
              <div style={{ background: '#6366f110', border: '1px solid #6366f130', borderRadius: 10, padding: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#6366f1', marginBottom: 6 }}>AI Suggestions</div>
                <div style={{ fontSize: 12, color: '#9b9bb8', lineHeight: 1.7 }}>• Launch on Tuesday 9 AM for best engagement<br />• Add 2 creative variants for A/B testing<br />• Enable CRM sync to auto-assign leads</div>
              </div>
            </div>
          )}
          {step === 9 && (
            <div style={{ textAlign: 'center', padding: '20px 0' }}>
              <div style={{ width: 64, height: 64, borderRadius: '50%', background: '#10b98120', border: '2px solid #10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                <Check size={28} style={{ color: '#10b981' }} />
              </div>
              <h3 style={{ fontSize: 18, fontWeight: 700, color: 'var(--text)', margin: '0 0 8px' }}>Ready to Launch</h3>
              <p style={{ fontSize: 13, color: 'var(--text-3)', margin: '0 0 28px' }}>Your campaign is configured and ready. Choose how you want to proceed.</p>
              <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
                {['Publish Now', 'Schedule', 'Save as Draft'].map((a, i) => (
                  <button key={a} onClick={onClose} style={{ padding: '12px 24px', background: i === 0 ? '#6366f1' : '#1a1a2e', border: `1px solid ${i === 0 ? '#6366f1' : '#252538'}`, borderRadius: 10, fontSize: 14, fontWeight: i === 0 ? 600 : 400, color: i === 0 ? '#fff' : '#9b9bb8', cursor: 'pointer' }}>
                    {a}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: '16px 28px', borderTop: '1px solid #252538', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
          <button onClick={onClose} style={{ padding: '8px 16px', background: 'none', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: 'var(--text-3)', cursor: 'pointer' }}>Cancel</button>
          <div style={{ display: 'flex', gap: 8 }}>
            {step > 0 && (
              <button onClick={() => setStep(s => s - 1)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: '#9b9bb8', cursor: 'pointer' }}>
                <ChevronLeft size={14} /> Back
              </button>
            )}
            <button onClick={() => show('Draft saved')} style={{ padding: '8px 16px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: '#9b9bb8', cursor: 'pointer' }}>Save Draft</button>
            {step < STEPS.length - 1 && (
              <button onClick={() => setStep(s => s + 1)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 20px', background: '#6366f1', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer' }}>
                Next <ChevronRight size={14} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function FieldGroup({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: '#9b9bb8', marginBottom: 6, letterSpacing: '0.03em' }}>
        {label}{required && <span style={{ color: '#ef4444', marginLeft: 3 }}>*</span>}
      </label>
      {children}
    </div>
  )
}

function Input({ value, onChange, placeholder, type = 'text' }: { value: string; onChange: (v: string) => void; placeholder?: string; type?: string }) {
  return <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={inputStyle} />
}

const inputStyle: React.CSSProperties = {
  width: '100%', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8,
  padding: '9px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', fontFamily: 'DM Sans',
}


