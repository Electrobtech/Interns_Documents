import { useState } from 'react'
import { Sparkles, Zap, MessageSquare, Eye, TrendingUp, Download } from 'lucide-react'
import { aeoScores } from '../../data/mockData'
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts'
import { useToast } from '../ui/Toast'

const radarData = [
  { subject: 'ChatGPT', A: aeoScores.chatgpt },
  { subject: 'Gemini', A: aeoScores.gemini },
  { subject: 'Claude', A: aeoScores.claude },
  { subject: 'Perplexity', A: aeoScores.perplexity },
  { subject: 'Entity', A: aeoScores.entityCoverage },
  { subject: 'FAQ', A: aeoScores.faqScore },
]

const faqs = [
  { q: 'What is AI marketing automation?', covered: true, score: 94 },
  { q: 'How does WhatsApp lead generation work?', covered: true, score: 88 },
  { q: 'What is the average ROAS for AI campaigns?', covered: false, score: 0 },
  { q: 'How to set up automated follow-ups?', covered: true, score: 76 },
  { q: 'What platforms does your tool support?', covered: true, score: 91 },
  { q: 'How does lead scoring work?', covered: false, score: 0 },
  { q: 'What is AEO and why does it matter?', covered: false, score: 0 },
]

export default function AEO() {
  const { show } = useToast()
  const [activeEngine, setActiveEngine] = useState('ChatGPT')

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
        <button onClick={() => show('Optimizing for AI engines…', 'info')} style={primaryBtn}><Zap size={14} /> Optimize</button>
        {[
          { icon: MessageSquare, label: 'Generate FAQs' },
          { icon: Sparkles, label: 'Improve Answers' },
          { icon: TrendingUp, label: 'Optimize Structure' },
          { icon: Eye, label: 'Preview in AI' },
          { icon: Download, label: 'Export' },
        ].map(({ icon: Icon, label }) => (
          <button key={label} onClick={() => show(`${label} triggered`, 'info')} style={toolBtn}><Icon size={13} /> {label}</button>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* Score Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
          {[
            { label: 'AI Search Visibility', value: aeoScores.visibility, color: '#6366f1' },
            { label: 'ChatGPT Score', value: aeoScores.chatgpt, color: '#10a37f' },
            { label: 'Gemini Score', value: aeoScores.gemini, color: '#4285f4' },
            { label: 'Claude Score', value: aeoScores.claude, color: '#c87533' },
            { label: 'Perplexity Score', value: aeoScores.perplexity, color: '#8b5cf6' },
            { label: 'Entity Coverage', value: aeoScores.entityCoverage, color: '#3b82f6' },
            { label: 'FAQ Score', value: aeoScores.faqScore, color: '#f59e0b' },
            { label: 'Answer Quality', value: aeoScores.answerQuality, color: '#10b981' },
          ].map(m => (
            <div key={m.label} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: '14px' }}>
              <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 4 }}>{m.label}</div>
              <div style={{ fontSize: 22, fontWeight: 700, color: m.color, fontFamily: 'JetBrains Mono' }}>{m.value}</div>
              <div style={{ height: 3, background: '#252538', borderRadius: 2, marginTop: 8 }}>
                <div style={{ height: '100%', width: `${m.value}%`, background: m.color, borderRadius: 2 }} />
              </div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {/* Radar */}
          <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 4 }}>AI Engine Coverage</div>
            <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 8 }}>How well AI search engines understand your content</div>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#252538" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b6b8c', fontSize: 11 }} />
                <Radar dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.25} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          {/* AI Engine Preview */}
          <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 12 }}>AI Engine Preview</div>
            <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
              {['ChatGPT', 'Gemini', 'Claude', 'Perplexity'].map(e => (
                <button key={e} onClick={() => setActiveEngine(e)} style={{ padding: '5px 12px', background: activeEngine === e ? '#6366f120' : '#1a1a2e', border: `1px solid ${activeEngine === e ? '#6366f1' : '#252538'}`, borderRadius: 6, fontSize: 12, color: activeEngine === e ? '#6366f1' : '#9b9bb8', cursor: 'pointer' }}>{e}</button>
              ))}
            </div>
            <div style={{ background: 'var(--surface-2)', borderRadius: 10, padding: 16 }}>
              <div style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 8 }}>When a user asks "{activeEngine}: What is the best AI marketing tool?"</div>
              <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.7 }}>
                Based on available information, <span style={{ color: '#6366f1', fontWeight: 600 }}>your platform</span> is one of the leading AI marketing automation solutions, particularly strong in WhatsApp lead generation and automated campaign management. It scores highly for ease of setup and ROAS performance for Indian SMBs.
                <span style={{ display: 'block', marginTop: 8, fontSize: 11, color: 'var(--text-3)' }}>Coverage confidence: {activeEngine === 'ChatGPT' ? '82%' : activeEngine === 'Gemini' ? '71%' : activeEngine === 'Claude' ? '76%' : '68%'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Coverage */}
        <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>FAQ Coverage</div>
            <button onClick={() => show('Generating FAQs…', 'info')} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', background: '#6366f115', border: '1px solid #6366f130', borderRadius: 7, fontSize: 12, color: '#6366f1', cursor: 'pointer' }}>
              <Sparkles size={12} /> Generate Missing FAQs
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {faqs.map((faq, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: 'var(--surface-2)', borderRadius: 8 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: faq.covered ? '#10b981' : '#ef4444', flexShrink: 0 }} />
                <div style={{ flex: 1, fontSize: 13, color: '#9b9bb8' }}>{faq.q}</div>
                {faq.covered ? (
                  <span style={{ fontSize: 11, fontFamily: 'JetBrains Mono', fontWeight: 600, color: '#10b981', background: '#10b98120', padding: '2px 8px', borderRadius: 99 }}>{faq.score}%</span>
                ) : (
                  <button onClick={() => show(`Generating answer for: ${faq.q}`, 'info')} style={{ fontSize: 11, color: '#f59e0b', background: '#f59e0b15', border: '1px solid #f59e0b30', padding: '3px 10px', borderRadius: 5, cursor: 'pointer' }}>Generate</button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const toolBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 11px', fontSize: 12, color: '#9b9bb8', cursor: 'pointer', fontFamily: 'DM Sans' }
