import { useState } from 'react'
import { Plus, ChevronLeft, ChevronRight, Calendar, List } from 'lucide-react'
import { calendarEvents } from '../../data/mockData'
import { useToast } from '../ui/Toast'

const VIEWS = ['Month', 'Week', 'Day', 'Timeline', 'Agenda']
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

function getDaysInMonth(year: number, month: number) {
  const firstDay = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  return { firstDay, daysInMonth }
}

export default function MarketingCalendar() {
  const { show } = useToast()
  const [view, setView] = useState('Month')
  const [currentDate, setCurrentDate] = useState(new Date(2025, 7, 1)) // Aug 2025
  const [showCreate, setShowCreate] = useState(false)

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()
  const { firstDay, daysInMonth } = getDaysInMonth(year, month)

  const getEventsForDay = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    return calendarEvents.filter(e => e.date === dateStr)
  }

  const eventTypeColors: Record<string, string> = {
    campaign: '#6366f1', broadcast: '#10b981', meeting: '#3b82f6',
    webinar: '#f59e0b', reminder: '#8b5cf6', holiday: '#ef4444',
  }

  const cells = []
  for (let i = 0; i < firstDay; i++) cells.push(null)
  for (let d = 1; d <= daysInMonth; d++) cells.push(d)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '12px 24px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0, flexWrap: 'wrap' }}>
        <button onClick={() => setShowCreate(true)} style={primaryBtn}><Plus size={14} /> Create Event</button>
        <div style={{ display: 'flex', gap: 4, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: 3 }}>
          {VIEWS.map(v => (
            <button key={v} onClick={() => setView(v)} style={{ padding: '5px 12px', background: view === v ? '#252538' : 'none', border: 'none', borderRadius: 6, fontSize: 12, color: view === v ? '#e4e4f0' : '#6b6b8c', cursor: 'pointer' }}>{v}</button>
          ))}
        </div>
        <div style={{ flex: 1 }} />
        {/* Month Nav */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button onClick={() => setCurrentDate(new Date(year, month - 1, 1))} style={navBtn}><ChevronLeft size={14} /></button>
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', minWidth: 140, textAlign: 'center' }}>{MONTHS[month]} {year}</span>
          <button onClick={() => setCurrentDate(new Date(year, month + 1, 1))} style={navBtn}><ChevronRight size={14} /></button>
        </div>
        <button onClick={() => setCurrentDate(new Date(2025, 7, 1))} style={{ padding: '6px 12px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer' }}>Today</button>
      </div>

      {/* Legend */}
      <div style={{ padding: '8px 24px', borderBottom: '1px solid #1a1a2e', display: 'flex', gap: 16, flexShrink: 0 }}>
        {Object.entries(eventTypeColors).map(([type, color]) => (
          <span key={type} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#9b9bb8' }}>
            <span style={{ width: 8, height: 8, borderRadius: 2, background: color }} />
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </span>
        ))}
      </div>

      {/* Calendar Grid */}
      {view === 'Month' && (
        <div style={{ flex: 1, overflow: 'auto', padding: 16 }}>
          {/* Day headers */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2, marginBottom: 4 }}>
            {DAYS.map(d => (
              <div key={d} style={{ padding: '6px 8px', fontSize: 11, fontWeight: 600, color: 'var(--text-3)', letterSpacing: '0.04em', textAlign: 'center' }}>{d}</div>
            ))}
          </div>
          {/* Day cells */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}>
            {cells.map((day, i) => {
              const events = day ? getEventsForDay(day) : []
              const isToday = day === 4 && month === 7 && year === 2025
              return (
                <div key={i} style={{ minHeight: 90, background: day ? '#13131e' : 'transparent', border: day ? `1px solid ${isToday ? '#6366f1' : '#252538'}` : 'none', borderRadius: 8, padding: '6px 8px', cursor: day ? 'pointer' : 'default', transition: 'border-color 0.15s' }}
                  onMouseEnter={e => day && ((e.currentTarget as HTMLElement).style.borderColor = '#6366f150')}
                  onMouseLeave={e => day && ((e.currentTarget as HTMLElement).style.borderColor = isToday ? '#6366f1' : '#252538')}>
                  {day && (
                    <>
                      <div style={{ fontSize: 12, fontWeight: isToday ? 700 : 400, color: isToday ? '#6366f1' : '#9b9bb8', marginBottom: 4, width: 22, height: 22, borderRadius: '50%', background: isToday ? '#6366f120' : 'none', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{day}</div>
                      {events.slice(0, 3).map(e => (
                        <div key={e.id} onClick={() => show(`Event: ${e.title}`, 'info')} style={{ fontSize: 10, background: e.color + '25', color: e.color, borderRadius: 3, padding: '2px 5px', marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', cursor: 'pointer' }}>
                          {e.title}
                        </div>
                      ))}
                      {events.length > 3 && <div style={{ fontSize: 10, color: 'var(--text-3)' }}>+{events.length - 3} more</div>}
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {view === 'Agenda' && (
        <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {calendarEvents.sort((a, b) => a.date.localeCompare(b.date)).map(e => (
              <div key={e.id} onClick={() => show(`Event: ${e.title}`, 'info')} style={{ display: 'flex', gap: 16, padding: '12px 16px', background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, cursor: 'pointer', alignItems: 'center' }}
                onMouseEnter={ev => (ev.currentTarget as HTMLElement).style.borderColor = e.color}
                onMouseLeave={ev => (ev.currentTarget as HTMLElement).style.borderColor = '#252538'}>
                <div style={{ width: 3, height: 36, borderRadius: 2, background: e.color, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 2 }}>{e.date}</div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{e.title}</div>
                </div>
                <span style={{ marginLeft: 'auto', fontSize: 11, background: e.color + '20', color: e.color, padding: '2px 8px', borderRadius: 5, fontWeight: 600 }}>{e.type}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {!['Month', 'Agenda'].includes(view) && (
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-3)', fontSize: 14 }}>
          <div style={{ textAlign: 'center' }}>
            <Calendar size={32} style={{ opacity: 0.3, marginBottom: 12 }} />
            <div>{view} view coming soon</div>
          </div>
        </div>
      )}

      {/* Create Event Modal */}
      {showCreate && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }} onClick={() => setShowCreate(false)}>
          <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 14, padding: 24, width: 440, boxShadow: '0 24px 80px rgba(0,0,0,0.5)' }} onClick={e => e.stopPropagation()}>
            <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text)', marginBottom: 16 }}>Create Event</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label style={labelStyle}>Event Title</label>
                <input placeholder="e.g. Campaign Launch" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Event Type</label>
                <select style={inputStyle}>
                  {['Campaign', 'Broadcast', 'Meeting', 'Webinar', 'Reminder', 'Holiday'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div>
                  <label style={labelStyle}>Date</label>
                  <input type="date" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Time</label>
                  <input type="time" style={inputStyle} />
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 20 }}>
              <button onClick={() => setShowCreate(false)} style={{ padding: '8px 16px', background: 'none', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: 'var(--text-3)', cursor: 'pointer' }}>Cancel</button>
              <button onClick={() => { setShowCreate(false); show('Event created!') }} style={{ padding: '8px 16px', background: '#6366f1', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer' }}>Create</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const navBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 30, height: 30, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, cursor: 'pointer', color: '#9b9bb8' }
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 600, color: '#9b9bb8', marginBottom: 6 }
const inputStyle: React.CSSProperties = { width: '100%', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '9px 12px', fontSize: 13, color: 'var(--text)', outline: 'none', fontFamily: 'DM Sans' }
