import { useState } from 'react'
import { Sparkles, RefreshCw, Globe, Minimize2, Maximize2, Save, Download, Copy } from 'lucide-react'
import { useToast } from '../ui/Toast'

const CONTENT_TABS = ['Ad Copy', 'Blogs', 'Emails', 'WhatsApp', 'SMS', 'Instagram', 'Facebook', 'LinkedIn', 'SEO', 'Landing Pages']

const prompts: Record<string, string> = {
  'Ad Copy': 'Write a compelling Facebook ad copy for an AI marketing automation platform targeting SMB owners in India. Highlight lead generation, WhatsApp automation, and ROAS improvement.',
  'Blogs': 'Write an SEO-optimized blog post about "How AI is Transforming Lead Generation in 2025" for B2B SaaS companies.',
  'Emails': 'Write a 3-email drip sequence for webinar registrants. Focus on value, anticipation, and final reminder.',
  'WhatsApp': 'Write a WhatsApp broadcast message for a flash sale. Keep it under 160 characters, add emoji.',
  'SMS': 'Write a short SMS campaign message for course enrollment. Include urgency and a clear CTA.',
  'Instagram': 'Write 3 Instagram caption variants for a product launch. Mix value, storytelling, and CTA.',
  'Facebook': 'Write a Facebook post for announcing a new AI feature. Include benefit, social proof, and CTA.',
  'LinkedIn': 'Write a LinkedIn thought leadership post about marketing automation ROI with a data-backed hook.',
  'SEO': 'Write meta title, meta description, and an H1 tag for a page targeting "AI marketing automation for SMBs".',
  'Landing Pages': 'Write a full landing page copy for a free lead automation demo. Include headline, sub-headline, 3 benefit bullets, and CTA.',
}

const sampleOutputs: Record<string, string> = {
  'Ad Copy': `🚀 Stop chasing leads. Let AI do it for you.

Our AI Marketing Platform helps SMB owners in India generate 3x more leads on WhatsApp, Email & Facebook — automatically.

✅ Set up in 10 minutes
✅ 40% lower cost per lead
✅ ROAS up to 172x verified by customers

📲 Start your free trial → [Link]

#LeadGeneration #AIMarketing #SmallBusiness`,
  'Blogs': `# How AI is Transforming Lead Generation in 2025

The way businesses capture and nurture leads has changed dramatically. In 2025, AI-powered marketing platforms are no longer a luxury — they are a competitive necessity for B2B SaaS companies looking to scale.

## The Old Way vs The AI Way

Traditional lead generation relied on manual follow-ups, broad ad targeting, and generic email sequences. Conversion rates hovered around 2–4%, and sales teams spent 60% of their time on unqualified prospects.

AI changes everything. Modern platforms can now:
- Identify high-intent signals in real time
- Auto-segment audiences based on behavior
- Personalize outreach at scale
- Predict the optimal time to reach each lead

## Key Statistics for 2025

According to recent industry data, companies using AI in their marketing workflows see:
- **28% reduction** in cost per lead
- **3.4x increase** in qualified pipeline
- **47% faster** lead response time

## What This Means for Your Strategy

If you're still running manual campaigns, you're leaving revenue on the table. Start with these three AI use cases: audience segmentation, predictive lead scoring, and automated follow-up sequences.`,
}

export default function ContentStudio() {
  const { show } = useToast()
  const [activeTab, setActiveTab] = useState('Ad Copy')
  const [prompt, setPrompt] = useState(prompts['Ad Copy'])
  const [output, setOutput] = useState(sampleOutputs['Ad Copy'] || '')
  const [generating, setGenerating] = useState(false)
  const [tone, setTone] = useState('Professional')
  const [lang, setLang] = useState('English')

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    setPrompt(prompts[tab] || '')
    setOutput(sampleOutputs[tab] || '')
  }

  const generate = () => {
    setGenerating(true)
    setOutput('')
    const finalOutput = sampleOutputs[activeTab] || `Here is your AI-generated ${activeTab} content based on your prompt:\n\nThis is a professional, engaging piece of content tailored to your brand voice and target audience. It includes a compelling hook, clear value proposition, and strong call-to-action optimized for ${activeTab}.`
    let i = 0
    const interval = setInterval(() => {
      setOutput(finalOutput.slice(0, i))
      i += 8
      if (i >= finalOutput.length) { setOutput(finalOutput); setGenerating(false); clearInterval(interval) }
    }, 20)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Content Type Tabs */}
      <div style={{ padding: '0 24px', borderBottom: '1px solid var(--border)', display: 'flex', overflowX: 'auto', flexShrink: 0 }} className="scrollbar-hide">
        {CONTENT_TABS.map(t => (
          <button key={t} onClick={() => handleTabChange(t)} style={{ padding: '14px 16px', fontSize: 13, fontWeight: activeTab === t ? 600 : 400, color: activeTab === t ? '#6366f1' : '#6b6b8c', background: 'none', border: 'none', cursor: 'pointer', borderBottom: `2px solid ${activeTab === t ? '#6366f1' : 'transparent'}`, whiteSpace: 'nowrap' }}>
            {t}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 24, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Input Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', margin: 0, flex: 1 }}>Content Brief</h3>
            <select value={tone} onChange={e => setTone(e.target.value)} style={selectStyle}>
              {['Professional', 'Friendly', 'Bold', 'Conversational', 'Formal'].map(t => <option key={t}>{t}</option>)}
            </select>
            <select value={lang} onChange={e => setLang(e.target.value)} style={selectStyle}>
              {['English', 'Hindi', 'Tamil', 'Telugu', 'Marathi'].map(l => <option key={l}>{l}</option>)}
            </select>
          </div>

          <textarea
            value={prompt} onChange={e => setPrompt(e.target.value)}
            style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: '14px', fontSize: 13, color: 'var(--text)', outline: 'none', resize: 'none', height: 160, lineHeight: 1.7, fontFamily: 'DM Sans' }}
          />

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button onClick={generate} disabled={generating} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '9px 18px', background: '#6366f1', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', opacity: generating ? 0.7 : 1 }}>
              <Sparkles size={14} style={{ animation: generating ? 'spin 1s linear infinite' : 'none' }} /> {generating ? 'Generating…' : 'Generate'}
            </button>
            {['Improve', 'Rewrite', 'Translate', 'Summarize', 'Expand', 'Shorten'].map(a => (
              <button key={a} onClick={() => show(`${a} applied`, 'success')} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer' }}>
                <RefreshCw size={11} /> {a}
              </button>
            ))}
          </div>

          {/* Templates */}
          <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#9b9bb8', marginBottom: 10 }}>Quick Templates</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {['AIDA Formula', 'PAS Framework', 'BAB Formula', 'FOMO Copy', '4Ps Template'].map(t => (
                <button key={t} onClick={() => show(`${t} loaded`, 'info')} style={{ padding: '8px 12px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, fontSize: 12, color: '#9b9bb8', cursor: 'pointer', textAlign: 'left' }}>
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Output Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', margin: 0, flex: 1 }}>Generated Output</h3>
            <button onClick={() => { navigator.clipboard.writeText(output); show('Copied!') }} style={iconBtn}><Copy size={14} /></button>
            <button onClick={() => show('Saved as template', 'success')} style={iconBtn}><Save size={14} /></button>
            <button onClick={() => show('Exported', 'success')} style={iconBtn}><Download size={14} /></button>
          </div>

          <div style={{ flex: 1, background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: 16, overflow: 'auto', minHeight: 400 }}>
            {output ? (
              <pre style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'var(--text)', whiteSpace: 'pre-wrap', margin: 0, lineHeight: 1.8 }}>{output}{generating && <span style={{ animation: 'pulse 1s infinite', color: '#6366f1' }}>▊</span>}</pre>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 300, color: 'var(--text-3)' }}>
                <Sparkles size={32} style={{ marginBottom: 12, opacity: 0.5 }} />
                <div style={{ fontSize: 13 }}>Generated content will appear here</div>
                <div style={{ fontSize: 12, marginTop: 4 }}>Adjust your brief and click Generate</div>
              </div>
            )}
          </div>

          {output && (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button onClick={() => show('Published!', 'success')} style={{ padding: '8px 16px', background: '#6366f1', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer' }}>Publish</button>
              <button onClick={() => show('Saved as template', 'success')} style={{ padding: '8px 16px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: '#9b9bb8', cursor: 'pointer' }}>Save Template</button>
              <button onClick={() => generate()} style={{ padding: '8px 16px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13, color: '#9b9bb8', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
                <RefreshCw size={12} /> Regenerate
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

const selectStyle: React.CSSProperties = { background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 10px', fontSize: 12, color: '#9b9bb8', outline: 'none', cursor: 'pointer', fontFamily: 'DM Sans' }
const iconBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, cursor: 'pointer', color: '#9b9bb8' }
