import { useState } from 'react'
import { Search, TrendingUp, TrendingDown, ExternalLink, RefreshCw, Download, Plus, Zap, BarChart3, AlertCircle, CheckCircle } from 'lucide-react'
import { seoKeywords } from '../../data/mockData'
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts'
import { useToast } from '../ui/Toast'

const SEO_TABS = ['Overview', 'Keywords', 'Backlinks', 'Core Web Vitals', 'Audit', 'Competitors']

const radarData = [
  { subject: 'On-Page', A: 78 }, { subject: 'Technical', A: 65 }, { subject: 'Content', A: 82 },
  { subject: 'Backlinks', A: 71 }, { subject: 'Performance', A: 58 }, { subject: 'Mobile', A: 88 },
]

export default function SEO() {
  const { show } = useToast()
  const [tab, setTab] = useState('Overview')

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
        <button onClick={() => show('SEO audit started…', 'info')} style={primaryBtn}><Search size={14} /> Run Audit</button>
        {[
          { icon: Plus, label: 'Generate Keywords' },
          { icon: Zap, label: 'Optimize Content' },
          { icon: BarChart3, label: 'Compare' },
          { icon: Download, label: 'Export Report' },
          { icon: RefreshCw, label: 'Refresh' },
        ].map(({ icon: Icon, label }) => (
          <button key={label} onClick={() => show(`${label} triggered`, 'info')} style={toolBtn}><Icon size={13} /> {label}</button>
        ))}
      </div>

      {/* Sub-tabs */}
      <div style={{ padding: '0 24px', borderBottom: '1px solid var(--border)', display: 'flex', overflowX: 'auto', flexShrink: 0 }} className="scrollbar-hide">
        {SEO_TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding: '12px 16px', fontSize: 13, fontWeight: tab === t ? 600 : 400, color: tab === t ? '#6366f1' : '#6b6b8c', background: 'none', border: 'none', cursor: 'pointer', borderBottom: `2px solid ${tab === t ? '#6366f1' : 'transparent'}`, whiteSpace: 'nowrap' }}>
            {t}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
        {tab === 'Overview' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {/* KPI Cards */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
              {[
                { label: 'SEO Score', value: '74', suffix: '/100', color: '#f59e0b' },
                { label: 'Keywords Ranking', value: '218', suffix: '', color: '#6366f1' },
                { label: 'Avg Position', value: '8.4', suffix: '', color: '#10b981' },
                { label: 'Backlinks', value: '4.2K', suffix: '', color: '#3b82f6' },
                { label: 'Domain Authority', value: '52', suffix: '', color: '#8b5cf6' },
                { label: 'Broken Links', value: '7', suffix: '', color: '#ef4444' },
                { label: 'Core Web Vitals', value: 'Good', suffix: '', color: '#10b981' },
                { label: 'Page Speed', value: '84', suffix: '/100', color: '#f59e0b' },
              ].map(m => (
                <div key={m.label} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 10, padding: '14px' }}>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 4 }}>{m.label}</div>
                  <div style={{ fontSize: 20, fontWeight: 700, color: m.color, fontFamily: 'JetBrains Mono' }}>
                    {m.value}<span style={{ fontSize: 12, color: 'var(--text-3)' }}>{m.suffix}</span>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
              {/* Radar Chart */}
              <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 4 }}>SEO Health Radar</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 8 }}>Performance across all dimensions</div>
                <ResponsiveContainer width="100%" height={220}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="#252538" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b6b8c', fontSize: 11 }} />
                    <Radar dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.25} strokeWidth={2} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              {/* Keyword Position Bar */}
              <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 4 }}>Top Keywords by Volume</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 8 }}>Monthly search volume</div>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={seoKeywords} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#252538" />
                    <XAxis type="number" tick={{ fill: '#6b6b8c', fontSize: 10 }} axisLine={false} tickLine={false} />
                    <YAxis type="category" dataKey="keyword" width={160} tick={{ fill: '#9b9bb8', fontSize: 10 }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
                    <Bar dataKey="volume" fill="#6366f1" radius={[0, 4, 4, 0]} name="Search Volume" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Issues */}
            <div style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 12 }}>SEO Issues</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  { type: 'error', label: '7 Broken Links Found', desc: '/blog/old-post-1, /careers/dev, +5 more' },
                  { type: 'warning', label: 'Page Speed Below Threshold', desc: 'LCP: 3.8s (target < 2.5s) on 12 pages' },
                  { type: 'warning', label: 'Missing Meta Descriptions', desc: '18 pages have no meta description' },
                  { type: 'success', label: 'Schema Markup Detected', desc: 'FAQ, Article, BreadcrumbList schemas found' },
                  { type: 'success', label: 'Mobile-Friendly', desc: 'All 84 indexed pages pass mobile test' },
                ].map((issue, i) => {
                  const Icon = issue.type === 'error' ? AlertCircle : issue.type === 'warning' ? AlertCircle : CheckCircle
                  const color = issue.type === 'error' ? '#ef4444' : issue.type === 'warning' ? '#f59e0b' : '#10b981'
                  return (
                    <div key={i} style={{ display: 'flex', gap: 10, padding: '10px 12px', background: 'var(--surface-2)', borderRadius: 8 }}>
                      <Icon size={14} style={{ color, flexShrink: 0, marginTop: 1 }} />
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{issue.label}</div>
                        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{issue.desc}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        )}

        {tab === 'Keywords' && (
          <div>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  {['Keyword', 'Volume', 'Difficulty', 'Position', 'Change', 'Actions'].map(h => (
                    <th key={h} style={{ ...thStyle, textAlign: h === 'Keyword' ? 'left' : 'right' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {seoKeywords.map((kw, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #1a1a2e' }}
                    onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#1a1a2e'}
                    onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}>
                    <td style={tdStyle}><span style={{ fontWeight: 500, color: 'var(--text)' }}>{kw.keyword}</span></td>
                    <td style={{ ...tdStyle, textAlign: 'right', fontFamily: 'JetBrains Mono', color: '#9b9bb8' }}>{kw.volume.toLocaleString()}</td>
                    <td style={{ ...tdStyle, textAlign: 'right' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 6 }}>
                        <div style={{ width: 40, height: 4, background: '#252538', borderRadius: 2 }}>
                          <div style={{ height: '100%', width: `${kw.difficulty}%`, background: kw.difficulty > 65 ? '#ef4444' : kw.difficulty > 45 ? '#f59e0b' : '#10b981', borderRadius: 2 }} />
                        </div>
                        <span style={{ fontFamily: 'JetBrains Mono', fontSize: 12, color: '#9b9bb8' }}>{kw.difficulty}</span>
                      </div>
                    </td>
                    <td style={{ ...tdStyle, textAlign: 'right', fontFamily: 'JetBrains Mono', fontWeight: 600, color: kw.position <= 5 ? '#10b981' : kw.position <= 10 ? '#f59e0b' : '#9b9bb8' }}>#{kw.position}</td>
                    <td style={{ ...tdStyle, textAlign: 'right' }}>
                      <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 3, fontSize: 12, color: kw.change > 0 ? '#10b981' : kw.change < 0 ? '#ef4444' : '#6b6b8c' }}>
                        {kw.change > 0 ? <TrendingUp size={12} /> : kw.change < 0 ? <TrendingDown size={12} /> : null}
                        {kw.change > 0 ? '+' : ''}{kw.change}
                      </span>
                    </td>
                    <td style={tdStyle}>
                      <button onClick={() => show(`Optimizing for "${kw.keyword}"`, 'info')} style={{ padding: '4px 10px', background: '#6366f115', border: '1px solid #6366f130', borderRadius: 5, fontSize: 11, color: '#6366f1', cursor: 'pointer' }}>Optimize</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {!['Overview', 'Keywords'].includes(tab) && (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-3)' }}>
            <Search size={32} style={{ opacity: 0.3, marginBottom: 12 }} />
            <div style={{ fontSize: 14 }}>{tab} data will appear here</div>
          </div>
        )}
      </div>
    </div>
  )
}

const primaryBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, background: '#6366f1', border: 'none', borderRadius: 8, padding: '8px 14px', fontSize: 13, fontWeight: 600, color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans' }
const toolBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 7, padding: '6px 11px', fontSize: 12, color: '#9b9bb8', cursor: 'pointer', fontFamily: 'DM Sans' }
const thStyle: React.CSSProperties = { padding: '10px 12px', fontSize: 11, fontWeight: 600, color: 'var(--text-3)', letterSpacing: '0.05em', whiteSpace: 'nowrap' }
const tdStyle: React.CSSProperties = { padding: '12px 12px', fontSize: 13, color: 'var(--text)', whiteSpace: 'nowrap', verticalAlign: 'middle' }
