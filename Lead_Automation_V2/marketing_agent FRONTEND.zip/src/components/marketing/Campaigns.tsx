import { useState } from 'react'
import { Plus, Copy, Archive, Pause, Play, Trash2, Download, Upload, BarChart3, Zap, Search, LayoutGrid, List, Columns, MoreHorizontal, ExternalLink, Edit2, Eye, TrendingUp, TrendingDown, Sparkles, Filter, ChevronDown, Target, DollarSign, Users } from 'lucide-react'
import { LineChart, Line, ResponsiveContainer, Tooltip } from 'recharts'
import { campaigns as initialCampaigns } from '../../data/mockData'
import Badge from '../ui/Badge'
import Drawer from '../ui/Drawer'
import Modal from '../ui/Modal'
import CreateCampaignWizard from './CreateCampaignWizard'
import { useToast } from '../ui/Toast'

const statusVariant: Record<string, 'active' | 'paused' | 'scheduled' | 'draft'> = {
  Active: 'active', Paused: 'paused', Scheduled: 'scheduled', Draft: 'draft',
}

const KANBAN_COLS = ['Draft', 'Scheduled', 'Active', 'Paused']
const KANBAN_COLORS: Record<string, string> = {
  Draft: '#7070a0', Scheduled: '#3b82f6', Active: '#10b981', Paused: '#f59e0b',
}

// Generate sparkline data per campaign
function sparkline(seed: number, n = 8) {
  let v = 30 + seed * 7
  return Array.from({ length: n }, (_, i) => {
    v = Math.max(5, Math.min(100, v + (Math.random() * 20 - 10)))
    return { v: Math.round(v) }
  })
}

export default function Campaigns() {
  const { show } = useToast()
  const [campaigns, setCampaigns] = useState(initialCampaigns)
  const [selected, setSelected] = useState<string[]>([])
  const [search, setSearch] = useState('')
  const [view, setView] = useState<'table' | 'card' | 'kanban'>('table')
  const [showCreate, setShowCreate] = useState(false)
  const [drawerCampaign, setDrawerCampaign] = useState<typeof campaigns[0] | null>(null)
  const [actionMenu, setActionMenu] = useState<string | null>(null)

  const filtered = campaigns.filter(c => c.name.toLowerCase().includes(search.toLowerCase()))
  const allSelected = filtered.length > 0 && filtered.every(c => selected.includes(c.id))
  const toggleAll = () => setSelected(allSelected ? [] : filtered.map(c => c.id))
  const toggleRow = (id: string) => setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  const bulkAction = (action: string) => { show(`${action} applied to ${selected.length} campaign(s)`); setSelected([]) }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)' }}>

      {/* Toolbar */}
      <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', flexShrink: 0, background: 'var(--surface)' }}>
        <button onClick={() => setShowCreate(true)} className="btn btn-ai" style={{ padding: '8px 16px' }}>
          <Plus size={13} /> Create Campaign
        </button>
        {[
          { icon: Copy, label: 'Duplicate' }, { icon: Archive, label: 'Archive' },
          { icon: Pause, label: 'Pause' }, { icon: Play, label: 'Resume' },
          { icon: Trash2, label: 'Delete' }, { icon: Upload, label: 'Import' },
          { icon: Download, label: 'Export' }, { icon: BarChart3, label: 'Report' },
          { icon: Zap, label: 'AI Optimize' },
        ].map(({ icon: Icon, label }) => (
          <button key={label} onClick={() => show(`${label} action triggered`, 'info')} className="btn btn-ghost" style={{ padding: '7px 12px' }}>
            <Icon size={12} /> {label}
          </button>
        ))}
        <div style={{ flex: 1 }} />
        {/* Search */}
        <div style={{ position: 'relative' }}>
          <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-3)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search campaigns…"
            style={{ paddingLeft: 32, paddingRight: 12, height: 34, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text)', fontSize: 13, outline: 'none', width: 220, fontFamily: 'var(--font-body)' }} />
        </div>
        <button className="btn btn-ghost" style={{ padding: '7px 12px' }}><Filter size={12} /> Filter</button>
        {/* View switcher */}
        <div style={{ display: 'flex', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: 2, gap: 2 }}>
          {([['table', List], ['card', LayoutGrid], ['kanban', Columns]] as const).map(([v, Icon]) => (
            <button key={v} onClick={() => setView(v)} title={v}
              style={{ width: 30, height: 28, borderRadius: 6, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s', background: view === v ? 'var(--primary)' : 'transparent', color: view === v ? '#fff' : 'var(--text-3)' }}>
              <Icon size={13} />
            </button>
          ))}
        </div>
      </div>

      {/* Bulk actions bar */}
      {selected.length > 0 && (
        <div style={{ padding: '10px 24px', background: 'rgba(99,102,241,0.08)', borderBottom: '1px solid rgba(99,102,241,0.2)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 13, color: 'var(--primary)', fontWeight: 600 }}>{selected.length} selected</span>
          {['Pause', 'Resume', 'Duplicate', 'Archive', 'Delete'].map(a => (
            <button key={a} onClick={() => bulkAction(a)} className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }}>{a}</button>
          ))}
          <button onClick={() => setSelected([])} className="btn btn-ghost" style={{ marginLeft: 'auto', padding: '5px 12px', fontSize: 12 }}>Clear</button>
        </div>
      )}

      {/* Stats strip */}
      <div style={{ padding: '12px 24px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 24, background: 'var(--surface)', flexShrink: 0 }}>
        {[
          { label: 'Total', value: filtered.length, color: 'var(--text)' },
          { label: 'Active', value: filtered.filter(c => c.status === 'Active').length, color: 'var(--green)' },
          { label: 'Paused', value: filtered.filter(c => c.status === 'Paused').length, color: 'var(--amber)' },
          { label: 'Scheduled', value: filtered.filter(c => c.status === 'Scheduled').length, color: 'var(--blue)' },
          { label: 'Draft', value: filtered.filter(c => c.status === 'Draft').length, color: 'var(--text-3)' },
        ].map(s => (
          <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 18, fontWeight: 800, fontFamily: 'var(--font-display)', color: s.color }}>{s.value}</span>
            <span style={{ fontSize: 11, color: 'var(--text-3)' }}>{s.label}</span>
          </div>
        ))}
      </div>

      {/* Content area */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        {view === 'table' && <TableView campaigns={filtered} selected={selected} toggleAll={toggleAll} toggleRow={toggleRow} allSelected={allSelected} onView={setDrawerCampaign} actionMenu={actionMenu} setActionMenu={setActionMenu} show={show} />}
        {view === 'card' && <CardView campaigns={filtered} onView={setDrawerCampaign} show={show} />}
        {view === 'kanban' && <KanbanView campaigns={filtered} onView={setDrawerCampaign} show={show} />}
      </div>

      {/* Wizard modal */}
      {showCreate && (
        <Modal title="Create Campaign" onClose={() => setShowCreate(false)}>
          <CreateCampaignWizard onClose={() => setShowCreate(false)} onCreated={c => { setCampaigns(prev => [c, ...prev]); setShowCreate(false); show('Campaign created!', 'success') }} />
        </Modal>
      )}

      {/* Detail drawer */}
      {drawerCampaign && (
        <Drawer title={drawerCampaign.name} subtitle={`${drawerCampaign.platform} · ${drawerCampaign.status}`} onClose={() => setDrawerCampaign(null)}>
          <CampaignDrawerContent campaign={drawerCampaign} />
        </Drawer>
      )}
    </div>
  )
}

/* ─── TABLE VIEW ──────────────────────────────────────────────────────── */
function TableView({ campaigns, selected, toggleAll, toggleRow, allSelected, onView, actionMenu, setActionMenu, show }: any) {
  const cols = ['', 'Campaign', 'Status', 'Platform', 'Budget', 'Spend', 'Revenue', 'Leads', 'CTR', 'ROAS', 'Start', 'End', 'Trend', '']

  return (
    <div style={{ overflow: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 1100 }}>
        <thead>
          <tr style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 10 }}>
            <th style={{ width: 44, padding: '10px 12px' }}>
              <input type="checkbox" checked={allSelected} onChange={toggleAll} style={{ accentColor: 'var(--primary)', width: 14, height: 14 }} />
            </th>
            {cols.slice(1).map(h => (
              <th key={h} style={{ padding: '10px 12px', fontSize: 11, fontWeight: 700, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: h === '' ? 'center' : 'left', whiteSpace: 'nowrap' }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {campaigns.map((c: any, i: number) => {
            const spark = sparkline(i)
            const isUp = spark[spark.length - 1].v >= spark[0].v
            return (
              <tr key={c.id} style={{ borderBottom: '1px solid var(--border)', transition: 'background 0.12s', cursor: 'pointer', background: selected.includes(c.id) ? 'rgba(99,102,241,0.06)' : 'transparent' }}
                onMouseEnter={e => { if (!selected.includes(c.id)) (e.currentTarget as HTMLElement).style.background = 'var(--surface)' }}
                onMouseLeave={e => { if (!selected.includes(c.id)) (e.currentTarget as HTMLElement).style.background = 'transparent' }}>
                <td style={{ padding: '12px' }}>
                  <input type="checkbox" checked={selected.includes(c.id)} onChange={() => toggleRow(c.id)} onClick={e => e.stopPropagation()} style={{ accentColor: 'var(--primary)', width: 14, height: 14 }} />
                </td>
                <td style={{ padding: '12px' }} onClick={() => onView(c)}>
                  <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--text)', marginBottom: 2 }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{c.objective}</div>
                </td>
                <td style={{ padding: '12px' }}><Badge variant={statusVariant[c.status] ?? 'draft'} label={c.status} /></td>
                <td style={{ padding: '12px', fontSize: 12, color: 'var(--text-2)' }}>{c.platform}</td>
                <td style={{ padding: '12px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>₹{c.budget.toLocaleString()}</td>
                <td style={{ padding: '12px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>₹{c.spend.toLocaleString()}</td>
                <td style={{ padding: '12px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--green)', fontWeight: 600 }}>₹{c.revenue.toLocaleString()}</td>
                <td style={{ padding: '12px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>{c.leads.toLocaleString()}</td>
                <td style={{ padding: '12px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>{c.ctr}%</td>
                <td style={{ padding: '12px' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700, color: c.roas >= 30 ? 'var(--green)' : c.roas >= 10 ? 'var(--amber)' : 'var(--red)' }}>{c.roas}x</span>
                </td>
                <td style={{ padding: '12px', fontSize: 11, color: 'var(--text-3)', whiteSpace: 'nowrap' }}>{c.startDate}</td>
                <td style={{ padding: '12px', fontSize: 11, color: 'var(--text-3)', whiteSpace: 'nowrap' }}>{c.endDate}</td>
                <td style={{ padding: '12px', width: 80 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                    {isUp ? <TrendingUp size={10} style={{ color: 'var(--green)', flexShrink: 0 }} /> : <TrendingDown size={10} style={{ color: 'var(--red)', flexShrink: 0 }} />}
                    <ResponsiveContainer width={60} height={28}>
                      <LineChart data={spark}>
                        <Line type="monotone" dataKey="v" stroke={isUp ? 'var(--green)' : 'var(--red)'} strokeWidth={1.5} dot={false} />
                        <Tooltip contentStyle={{ display: 'none' }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </td>
                <td style={{ padding: '12px', position: 'relative' }}>
                  <button onClick={e => { e.stopPropagation(); setActionMenu(actionMenu === c.id ? null : c.id) }}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)', padding: '3px 6px', borderRadius: 6 }}>
                    <MoreHorizontal size={15} />
                  </button>
                  {actionMenu === c.id && (
                    <div style={{ position: 'absolute', right: 8, top: '100%', width: 160, background: 'var(--surface-3)', border: '1px solid var(--border-2)', borderRadius: 10, boxShadow: 'var(--shadow-lg)', zIndex: 200, padding: '4px 0', marginTop: 2 }} onClick={e => e.stopPropagation()}>
                      {[['View Details', Eye], ['Edit', Edit2], ['Duplicate', null], ['Pause', null], ['Archive', null]].map(([label, Icon]: any) => (
                        <button key={label as string} onClick={() => { if (label === 'View Details') onView(c); show(`${label}: ${c.name}`); setActionMenu(null) }}
                          style={{ width: '100%', padding: '8px 12px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12, color: 'var(--text-2)', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-body)' }}
                          onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = 'var(--surface-2)'}
                          onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'none'}>
                          {Icon && <Icon size={12} />} {label}
                        </button>
                      ))}
                    </div>
                  )}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
      {campaigns.length === 0 && <EmptyState />}
    </div>
  )
}

/* ─── CARD VIEW ───────────────────────────────────────────────────────── */
function CardView({ campaigns, onView, show }: any) {
  return (
    <div style={{ padding: 24, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
      {campaigns.map((c: any, i: number) => {
        const spark = sparkline(i)
        const isUp = spark[spark.length - 1].v >= spark[0].v
        const spendPct = Math.round((c.spend / c.budget) * 100)
        return (
          <div key={c.id} onClick={() => onView(c)} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 16, padding: '18px 20px', cursor: 'pointer', transition: 'all 0.18s', position: 'relative', overflow: 'hidden' }}
            onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'rgba(99,102,241,0.3)'; el.style.transform = 'translateY(-2px)'; el.style.boxShadow = 'var(--shadow-md)' }}
            onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'var(--border)'; el.style.transform = 'none'; el.style.boxShadow = 'none' }}>

            {/* Status accent bar */}
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: KANBAN_COLORS[c.status] ?? 'var(--primary)', borderRadius: '16px 16px 0 0' }} />

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12, marginTop: 4 }}>
              <div style={{ flex: 1, paddingRight: 8 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text)', marginBottom: 3 }}>{c.name}</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{c.platform} · {c.objective}</div>
              </div>
              <Badge variant={statusVariant[c.status] ?? 'draft'} label={c.status} />
            </div>

            {/* KPI grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 14 }}>
              {[
                { label: 'Revenue', value: `₹${(c.revenue / 1000).toFixed(0)}K`, icon: DollarSign, color: 'var(--green)' },
                { label: 'Leads', value: c.leads.toLocaleString(), icon: Users, color: 'var(--blue)' },
                { label: 'ROAS', value: `${c.roas}x`, icon: Target, color: c.roas >= 30 ? 'var(--green)' : 'var(--amber)' },
              ].map(m => (
                <div key={m.label} style={{ background: 'var(--surface-2)', borderRadius: 8, padding: '8px 10px' }}>
                  <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 4 }}>{m.label}</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 800, color: m.color }}>{m.value}</div>
                </div>
              ))}
            </div>

            {/* Sparkline */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 10, color: isUp ? 'var(--green)' : 'var(--red)', fontWeight: 600 }}>
                {isUp ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                {isUp ? '+' : ''}{Math.round(((spark[spark.length - 1].v - spark[0].v) / spark[0].v) * 100)}%
              </div>
              <ResponsiveContainer width="100%" height={36}>
                <LineChart data={spark}>
                  <Line type="monotone" dataKey="v" stroke={isUp ? '#10b981' : '#ef4444'} strokeWidth={2} dot={false} />
                  <Tooltip contentStyle={{ display: 'none' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Budget bar */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5, fontSize: 10, color: 'var(--text-3)' }}>
                <span>Budget used</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: spendPct > 80 ? 'var(--amber)' : 'var(--text-2)' }}>{spendPct}%</span>
              </div>
              <div className="progress-track">
                <div className="progress-fill" style={{ width: `${spendPct}%`, background: spendPct > 80 ? 'var(--amber)' : 'var(--primary)' }} />
              </div>
            </div>
          </div>
        )
      })}
      {campaigns.length === 0 && <div style={{ gridColumn: '1/-1' }}><EmptyState /></div>}
    </div>
  )
}

/* ─── KANBAN VIEW ─────────────────────────────────────────────────────── */
function KanbanView({ campaigns, onView, show }: any) {
  return (
    <div style={{ padding: 24, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, minWidth: 900, height: '100%' }}>
      {KANBAN_COLS.map(col => {
        const items = campaigns.filter((c: any) => c.status === col)
        const color = KANBAN_COLORS[col]
        return (
          <div key={col} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            {/* Column header */}
            <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{col}</span>
              <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-3)', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, padding: '1px 7px' }}>{items.length}</span>
            </div>

            {/* Cards */}
            <div style={{ flex: 1, overflow: 'auto', padding: '10px 10px 14px' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {items.map((c: any, i: number) => {
                  const spark = sparkline(i + col.length)
                  const isUp = spark[spark.length - 1].v >= spark[0].v
                  return (
                    <div key={c.id} onClick={() => onView(c)} style={{ background: 'var(--card-solid)', border: '1px solid var(--border)', borderRadius: 12, padding: '12px 14px', cursor: 'pointer', transition: 'all 0.15s' }}
                      onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = color + '50'; el.style.transform = 'translateY(-1px)' }}
                      onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'var(--border)'; el.style.transform = 'none' }}>
                      <div style={{ fontWeight: 600, fontSize: 12, color: 'var(--text)', marginBottom: 4 }}>{c.name}</div>
                      <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 8 }}>{c.platform}</div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--green)', fontWeight: 700 }}>₹{(c.revenue / 1000).toFixed(0)}K</span>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: c.roas >= 30 ? 'var(--green)' : 'var(--amber)', fontWeight: 700 }}>{c.roas}x ROAS</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                        <div style={{ fontSize: 9, color: isUp ? 'var(--green)' : 'var(--red)', fontWeight: 600 }}>{isUp ? '▲' : '▼'}</div>
                        <ResponsiveContainer width="100%" height={24}>
                          <LineChart data={spark}>
                            <Line type="monotone" dataKey="v" stroke={isUp ? '#10b981' : '#ef4444'} strokeWidth={1.5} dot={false} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )
                })}
                {items.length === 0 && (
                  <div style={{ padding: '20px 12px', textAlign: 'center', fontSize: 12, color: 'var(--text-4)', border: '1px dashed var(--border)', borderRadius: 10 }}>No campaigns</div>
                )}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

/* ─── EMPTY STATE ─────────────────────────────────────────────────────── */
function EmptyState() {
  return (
    <div style={{ padding: '80px 24px', textAlign: 'center' }}>
      <div style={{ width: 64, height: 64, borderRadius: 18, background: 'var(--primary-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
        <Sparkles size={28} style={{ color: 'var(--primary)' }} />
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: 'var(--text)', marginBottom: 8 }}>No campaigns found</div>
      <div style={{ fontSize: 13, color: 'var(--text-3)', marginBottom: 20 }}>Create your first AI-powered campaign to get started</div>
    </div>
  )
}

/* ─── DRAWER CONTENT ──────────────────────────────────────────────────── */
function CampaignDrawerContent({ campaign: c }: { campaign: any }) {
  const spark = sparkline(parseInt(c.id) || 1, 14)
  const spendPct = Math.round((c.spend / c.budget) * 100)

  return (
    <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {[
          { label: 'Revenue', value: `₹${c.revenue.toLocaleString()}`, color: 'var(--green)' },
          { label: 'ROAS', value: `${c.roas}x`, color: c.roas >= 30 ? 'var(--green)' : 'var(--amber)' },
          { label: 'Leads', value: c.leads.toLocaleString(), color: 'var(--blue)' },
          { label: 'CTR', value: `${c.ctr}%`, color: 'var(--primary)' },
          { label: 'CPC', value: `₹${c.cpc}`, color: 'var(--text)' },
          { label: 'CPL', value: `₹${c.cpl}`, color: 'var(--text)' },
        ].map(m => (
          <div key={m.label} style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 14px' }}>
            <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 4 }}>{m.label}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 800, color: m.color }}>{m.value}</div>
          </div>
        ))}
      </div>

      <div style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', marginBottom: 10 }}>Performance Trend</div>
        <ResponsiveContainer width="100%" height={100}>
          <LineChart data={spark}>
            <Line type="monotone" dataKey="v" stroke="var(--primary)" strokeWidth={2} dot={false} />
            <Tooltip contentStyle={{ background: 'var(--surface-3)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 11 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 12, padding: '16px 18px' }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', marginBottom: 12 }}>Budget Utilisation</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 12, color: 'var(--text-2)' }}>
          <span>₹{c.spend.toLocaleString()} spent</span>
          <span style={{ color: 'var(--text-3)' }}>of ₹{c.budget.toLocaleString()}</span>
        </div>
        <div className="progress-track" style={{ height: 8 }}>
          <div className="progress-fill" style={{ width: `${spendPct}%`, background: spendPct > 80 ? 'var(--amber)' : 'var(--primary)', height: '100%' }} />
        </div>
        <div style={{ textAlign: 'right', marginTop: 6, fontSize: 11, color: 'var(--text-3)' }}>{spendPct}% utilised</div>
      </div>

      <div style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: 12, padding: '14px 16px' }}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
          <Sparkles size={13} style={{ color: 'var(--primary)', flexShrink: 0, marginTop: 1 }} />
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--primary)' }}>AI Recommendation</div>
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-2)', lineHeight: 1.6 }}>
          {c.roas > 30 ? `High ROAS of ${c.roas}x detected. Consider increasing budget by 20–30% to scale conversions.` : `ROAS of ${c.roas}x is below threshold. Review audience targeting and creative performance.`}
        </div>
      </div>
    </div>
  )
}
