### **Refined Master Prompt – Enterprise AI Marketing Agent (Frontend Only, Excluding Automation)**

---

## ROLE

You are a Senior Product Designer, UX Architect, and Frontend Engineer.

Design and build **ONLY the frontend** of an **Enterprise AI Marketing Agent** for a Lead Automation Platform.

This is **NOT** a chatbot.

It is a complete **Marketing Management Workspace** inspired by:

* Meta Ads Manager
* HubSpot Marketing Hub
* Google Ads
* Salesforce Marketing Cloud
* Zoho Marketing Automation
* Microsoft Clarity (Analytics UI)
* Notion (Clean UI)

Do **NOT** implement backend logic, APIs, authentication, or databases.

Use **mock JSON data** everywhere.

The UI should be production-ready and enterprise-grade.

---

# TECH STACK

* Next.js 15
* React
* TypeScript
* TailwindCSS
* shadcn/ui
* Framer Motion
* Recharts
* React Table / TanStack Table
* Lucide Icons

---

# DESIGN SYSTEM

Create a premium SaaS interface.

Requirements

* Professional
* Modern
* Enterprise
* Responsive
* Accessible
* Light/Dark Mode
* Clean spacing
* Rounded cards
* Sticky table headers
* Beautiful loading skeletons
* Empty states
* Error states
* Success states
* Toast notifications
* Tooltips
* Keyboard shortcuts
* Command Palette (Ctrl+K)

---

# SIDEBAR

Marketing Agent

```
Dashboard

Campaigns

Broadcasts

Audience

Content Studio

SEO

AEO

Competitor Analysis

Marketing Calendar

Analytics

Reports

Templates

Assets Library

Knowledge Base

Settings
```

---

# GLOBAL HEADER

Top navigation should contain

* Breadcrumb
* Global Search
* AI Search
* Notifications
* Help
* Theme Switcher
* User Profile
* Workspace Switcher

---

# DASHBOARD

Build a rich executive dashboard.

---

## KPI Cards

Display

* Total Campaigns
* Running Campaigns
* Scheduled Campaigns
* Draft Campaigns
* Leads Generated
* Conversion Rate
* CTR
* CPC
* CPM
* Cost Per Lead
* Revenue
* ROAS
* AI Marketing Score

---

## Charts

Create charts for

* Campaign Performance
* Lead Funnel
* Revenue
* Platform Distribution
* Channel Performance
* Audience Growth
* Monthly Campaigns
* Top Performing Campaigns
* Conversion Funnel

---

## AI Insights Panel

Show intelligent recommendations like

* Campaign health
* Budget recommendations
* Suggested launch time
* Trending keywords
* Competitor alerts
* SEO improvements
* AEO improvements

---

# CAMPAIGNS MODULE

Design this very similar to Meta Ads Manager.

---

## Top Toolbar

Include

```
Create Campaign

Duplicate

Archive

Pause

Resume

Delete

Import

Export

Generate Report

AI Optimize

Refresh

Columns

Saved Views

Filters

Date Picker

Search
```

---

## Campaign Table

Columns

```
Select

Campaign Name

Platform

Objective

Status

Budget

Spend

CTR

CPM

CPC

Reach

Impressions

Leads

Conversions

Revenue

ROAS

Created By

Created Date

Updated Date

AI Score

Actions
```

---

## Bulk Actions

Appears after row selection

```
Pause

Resume

Duplicate

Delete

Archive

Export

Assign Owner

Generate Report

AI Optimize
```

---

## Row Actions

```
Open

Edit

Duplicate

Preview

Analytics

AI Insights

Export

Archive

Delete
```

---

# CREATE CAMPAIGN

Create a **10-step wizard**

---

## Step 1

Campaign Information

Fields

* Campaign Name
* Description
* Tags
* Owner
* Priority

Buttons

* Cancel
* Save Draft
* Next

---

## Step 2

Campaign Objective

Options

* Lead Generation
* Website Traffic
* Sales
* Engagement
* Awareness
* Event Registration
* Webinar
* Course Registration
* Remarketing
* Conversion

---

## Step 3

Platforms

Allow multi-select

* Facebook
* Instagram
* LinkedIn
* Google Ads
* WhatsApp
* Messenger
* Telegram
* Email
* SMS
* Web Push

---

## Step 4

Budget

Fields

* Daily Budget
* Lifetime Budget
* Currency
* Bid Strategy
* Start Date
* End Date
* Time Zone

---

## Step 5

Audience

Fields

* Location
* Age
* Gender
* Interests
* Languages
* Education
* Profession
* Device
* Custom Audience
* Lookalike Audience
* Saved Audience

Right-side AI panel

Show

* Estimated Reach
* Expected Conversion
* Audience Quality
* Suggestions

---

## Step 6

Placements

Allow selection

* Facebook Feed
* Instagram Feed
* Stories
* Reels
* Messenger
* Audience Network

---

## Step 7

Creatives

Tabs

* Images
* Videos
* Carousel
* Stories
* Reels

Fields

* Headline
* Description
* CTA
* Landing Page
* Tracking URL

Buttons

* Upload Media
* AI Generate Copy
* AI Generate Headlines
* AI Generate CTA
* Preview

---

## Step 8

Tracking

Fields

* UTM Parameters
* Pixel
* Conversion Events
* CRM Tracking
* Google Analytics

---

## Step 9

Review

Display complete summary.

Show warnings.

Show AI Suggestions.

---

## Step 10

Publish

Buttons

* Publish
* Schedule
* Save Draft

---

# CAMPAIGN DETAILS

Open as a **Right Side Drawer**.

Tabs

```
Overview

Performance

Audience

Budget

Creatives

Tracking

Activity

History

AI Insights
```

---

# BROADCASTS

Design similar to WhatsApp Broadcast Manager.

Toolbar

```
Create Broadcast

Duplicate

Delete

Export

Templates

Schedule

AI Generate
```

---

## Broadcast Table

Columns

* Broadcast Name
* Channel
* Audience
* Status
* Sent
* Delivered
* Opened
* Clicked
* Responses
* Conversion
* AI Score

---

## Create Broadcast Wizard

### Step 1

* Broadcast Name
* Channel
* Audience

### Step 2

Message Builder

Toolbar

* Bold
* Italic
* Emoji
* Variables
* Images
* Video
* PDF
* Buttons

AI Buttons

* Rewrite
* Improve
* Translate
* Shorten
* Expand
* Grammar Check

### Step 3

Schedule

* Send Now
* Later
* Recurring
* Time Zone
* Smart Time

---

# AUDIENCE

Pages

* All Audiences
* Segments
* Custom Audiences
* Lookalikes
* Lead Scoring
* Saved Filters

Include

* Search
* Filters
* Import
* Export

---

# CONTENT STUDIO

Tabs

* Ad Copy
* Email
* WhatsApp
* SMS
* Facebook
* Instagram
* LinkedIn
* Blog
* Landing Pages

Buttons

* Generate
* Rewrite
* Improve
* Translate
* Expand
* Shorten
* Save Template
* Export

---

# SEO

Dashboard

Cards

* SEO Score
* Keyword Rankings
* Search Volume
* Difficulty
* Backlinks
* Internal Links
* Core Web Vitals
* Broken Links

Buttons

* Run Audit
* Generate Keywords
* Compare
* Export

---

# AEO

Cards

* AI Search Visibility
* ChatGPT Score
* Gemini Score
* Claude Score
* Perplexity Score
* Entity Coverage
* FAQ Score
* Answer Quality

Buttons

* Optimize
* Generate FAQs
* Improve Answers
* Preview

---

# COMPETITOR ANALYSIS

Allow adding competitors.

Tabs

* Overview
* SEO
* AEO
* Ads
* Social Media
* Landing Pages
* Keywords
* Pricing
* Tech Stack
* Funnels
* SWOT

Cards

* Opportunity Score
* Threat Score
* Traffic
* Domain Authority
* Backlinks
* Engagement

Buttons

* Compare
* Refresh
* Generate Report
* Export

---

# MARKETING CALENDAR

Views

* Month
* Week
* Day
* Timeline
* Agenda

Create events

* Campaign
* Broadcast
* Meeting
* Webinar
* Reminder
* Holiday

Features

* Drag & Drop
* Resize Events
* Color Labels
* Team Assignment
* Google Calendar UI (frontend only)
* Outlook Sync UI (frontend only)

---

# ANALYTICS

Executive dashboard.

Charts

* Revenue
* Leads
* CTR
* CPL
* Conversion Funnel
* Audience Growth
* Campaign ROI
* Channel Comparison
* Geographic Performance

Buttons

* Export
* Compare
* AI Report
* Refresh

---

# REPORTS

Generate report UI.

Templates

* Campaign Report
* Monthly Report
* ROI Report
* Lead Report
* Executive Summary

Export

* PDF
* Excel
* CSV

---

# ASSETS LIBRARY

Folders

* Images
* Videos
* PDFs
* Logos
* Brand Kit
* Icons
* AI Generated Images
* Templates

Include

* Upload
* Rename
* Move
* Delete
* Search
* Filters

---

# KNOWLEDGE BASE

Cards

* Marketing Docs
* Brand Guidelines
* Campaign History
* Case Studies
* Reports
* Templates
* FAQs

Include

* Search
* AI Search
* Categories
* Tags

---

# SETTINGS

Pages

* General
* Branding
* Team Members
* Roles & Permissions
* Integrations (UI only)
* Notifications
* Billing (UI only)
* AI Preferences
* Audit Logs

---

# GLOBAL COMPONENTS

Every page should include:

* Global Search
* AI Search
* Breadcrumbs
* Advanced Filters
* Saved Views
* Sort
* Pagination
* Sticky Headers
* Column Visibility
* Density Selector
* Full Screen Mode
* Keyboard Shortcuts
* Activity Timeline
* Loading Skeletons
* Empty States
* Error States
* Success Toasts
* Confirmation Dialogs
* Right-side AI Insights Panel

---

# FINAL REQUIREMENT

Build a **fully interactive frontend prototype** using mock data only. Every button should open the appropriate modal, drawer, dropdown, or multi-step wizard. Focus on polished UX, enterprise-level information architecture, and reusable components. The interface should feel like a modern combination of **Meta Ads Manager, HubSpot Marketing Hub, Google Ads, and Salesforce Marketing Cloud**, ready for backend integration later.
