# Frontend Prompt – Build Enterprise Marketing Agent (UI Only)

## Role

You are a Senior Product Designer, UX Architect, and Frontend Engineer.

Your task is to build **ONLY THE FRONTEND UI** for an **Enterprise AI Marketing Agent**. **Do not implement backend, APIs, databases, or business logic.** Use mock JSON data everywhere.

The design should be inspired by **Meta Ads Manager**, **HubSpot Marketing Hub**, **Google Ads**, **Salesforce Marketing Cloud**, and **Notion**, while maintaining a unique, premium SaaS design.

---

# Tech Stack

* Next.js 15
* React
* TypeScript
* Tailwind CSS
* shadcn/ui
* Framer Motion
* Recharts
* Lucide Icons

---

# General Requirements

* Fully responsive
* Enterprise dashboard
* Light & Dark mode
* Professional spacing
* Consistent design system
* Use reusable components
* Use dummy/mock data
* Every page should have loading skeletons
* Empty states
* Error states
* Tooltips
* Search
* Filters
* Pagination
* Bulk selection
* Right-side AI Assistant panel
* Breadcrumb navigation

---

# Sidebar Navigation

Create the following modules:

```
Marketing Agent
│
├── Dashboard
├── Campaigns
├── Broadcasts
├── Audience
├── Automation
├── Content Studio
├── SEO
├── AEO
├── Competitor Analysis
├── Marketing Calendar
├── Analytics
├── Reports
├── Templates
├── Assets
├── Knowledge Base
└── Settings
```

---

# DASHBOARD

Create a modern dashboard with:

### KPI Cards

* Total Campaigns
* Running Campaigns
* Scheduled Campaigns
* Draft Campaigns
* Leads Generated
* Cost per Lead
* Revenue
* ROAS
* CTR
* CPC
* CPM
* AI Performance Score

---

### Charts

Campaign Performance

Lead Funnel

Revenue

Traffic Sources

Platform Distribution

Audience Growth

Conversion Funnel

Marketing Score Trend

---

### AI Insights Card

Example

```
Campaign Performance

AI Recommendation

Campaign "AI Bootcamp"

CTR is 2.4%

Expected CTR

4.1%

Recommendation

Improve headline
Use shorter CTA
Schedule tomorrow at 9 AM

Confidence

94%
```

---

# CAMPAIGNS

Build exactly like Meta Ads Manager.

---

## Top Header

Buttons

```
+ Create Campaign

Duplicate

Pause

Resume

Archive

Delete

Export

Import

AI Optimize
```

Right side

```
Search

Saved Views

Date Picker

Columns

Filters

Refresh

Notifications
```

---

## Campaign Table

Columns

```
Checkbox

Campaign Name

Platform

Objective

Status

Budget

Spend

CTR

CPC

CPM

Reach

Impressions

Leads

Conversions

ROAS

Created By

Last Updated

AI Score

Actions
```

---

Actions Dropdown

```
Open

Edit

Duplicate

Preview

Pause

Resume

Archive

Delete

Export

Generate Report

AI Suggestions
```

---

Bulk Actions

When rows selected

```
Delete

Pause

Resume

Duplicate

Export

Assign

Move Folder

AI Optimize

Schedule

Archive
```

---

# CREATE CAMPAIGN FLOW

Create a **multi-step wizard**.

---

## Step 1

Campaign Details

Fields

```
Campaign Name

Description

Campaign Objective

Campaign Type

Platform

Tags

Priority

Owner
```

---

Campaign Objectives

```
Lead Generation

Website Traffic

Conversions

Brand Awareness

Engagement

Course Registration

Event Registration

Sales

Retargeting

Remarketing
```

---

Platforms

```
Facebook

Instagram

Google Ads

LinkedIn

WhatsApp

Messenger

Telegram

Email

SMS

Web Push

Multi Channel
```

---

Buttons

```
Cancel

Save Draft

Next
```

---

## Step 2

Budget

Fields

```
Daily Budget

Lifetime Budget

Currency

Bid Strategy

Schedule

Start Date

End Date

Timezone

Frequency Cap
```

---

Buttons

```
Back

Save Draft

Next
```

---

## Step 3

Audience

Sections

```
Age

Gender

Location

Language

Interests

Education

Job Role

Income

Device

Lookalike Audience

Saved Audience

Custom Audience
```

AI Suggestions Card

```
Recommended Audience

Estimated Reach

High Intent Score

Expected Conversion

Suggested Interests
```

---

Buttons

```
Back

Save Draft

Next
```

---

## Step 4

Ad Creative

Tabs

```
Images

Videos

Carousel

Reels

Stories
```

Fields

```
Headline

Primary Text

Description

CTA

Landing Page

Tracking URL
```

Buttons

```
Generate AI Copy

Generate Headlines

Generate Images

Preview
```

---

Media Upload Area

```
Drag & Drop

Upload Image

Upload Video

Choose From Library
```

---

Buttons

```
Back

Save Draft

Next
```

---

## Step 5

Automation

Enable

```
Lead Routing

Auto Assign

WhatsApp Follow-up

Email Follow-up

CRM Sync

Webhook

n8n Workflow

Slack Alert

Reminder
```

---

Buttons

```
Back

Publish Campaign

Save Draft
```

---

# CAMPAIGN DETAILS PAGE

Tabs

```
Overview

Performance

Audience

Creative

Automation

Analytics

Activity

History
```

Right Panel

```
AI Suggestions

Campaign Health

SEO Score

AEO Score

Competitor Alert
```

---

# BROADCASTS

Like WhatsApp Broadcast.

Top Buttons

```
Create Broadcast

Duplicate

Pause

Delete

Export

Templates

Schedule

AI Generate
```

---

Broadcast Table

Columns

```
Broadcast Name

Channel

Audience

Status

Sent

Delivered

Opened

Clicked

Responses

Conversion

AI Score

Actions
```

---

Create Broadcast Wizard

Step 1

```
Broadcast Name

Channel

Template

Audience
```

---

Step 2

Message Builder

Toolbar

```
Bold

Italic

Emoji

Variables

Buttons

Images

Video

PDF

Location

Poll
```

Buttons

```
Preview

Generate AI Message

Grammar Check

Translate

Shorten

Expand
```

---

Step 3

Schedule

```
Send Now

Schedule Later

Recurring

Timezone

Smart Time

A/B Test
```

Buttons

```
Publish

Save Draft

Cancel
```

---

# CONTENT STUDIO

Tabs

```
Ad Copy

Blogs

Emails

WhatsApp

SMS

Instagram

Facebook

LinkedIn

SEO

Landing Pages
```

Buttons

```
Generate

Improve

Rewrite

Translate

Summarize

Save Template

Publish
```

---

# SEO MODULE

Buttons

```
New Audit

Generate Keywords

Optimize Content

Export Report

Compare
```

Cards

```
SEO Score

Keyword Ranking

Backlinks

Page Speed

Core Web Vitals

Broken Links
```

---

# AEO MODULE

Cards

```
AI Search Visibility

ChatGPT Readiness

Gemini Score

Claude Score

Perplexity Score

Entity Coverage

FAQ Score
```

Buttons

```
Generate FAQs

Improve Answers

Optimize Structure

Preview in AI
```

---

# COMPETITOR ANALYSIS

Buttons

```
Add Competitor

Refresh

Compare

Export

Generate Report

AI Insights
```

Tabs

```
Overview

SEO

Ads

Social

Content

Keywords

Landing Pages

Pricing
```

---

# MARKETING CALENDAR

Views

```
Month

Week

Day

Timeline

Agenda
```

Buttons

```
Create Event

Campaign

Broadcast

Meeting

Reminder

Holiday

Sync Calendar
```

---

# ANALYTICS

Buttons

```
Export

Share

Compare

Date Filter

Refresh

Generate AI Report
```

Charts

```
Campaign ROI

Channel Performance

Revenue

Lead Funnel

Audience

CTR

CPL

Conversions
```

---

# KNOWLEDGE BASE

Buttons

```
Upload

New Folder

Search

AI Search

Sort

Filters
```

Cards

```
Campaign Docs

Brand Guidelines

Past Reports

Assets

Templates

Competitor Reports
```

---

# GLOBAL AI ASSISTANT PANEL

Floating panel on the right.

Buttons

```
Create Campaign

Generate Content

Improve Campaign

Optimize Budget

SEO Suggestions

AEO Suggestions

Competitor Summary

Audience Insights

Generate Report

Help
```

---

# GLOBAL COMPONENTS

Every page should include:

* Search bar
* Advanced filters
* Sort options
* Saved filters
* Refresh button
* Export menu
* Import menu
* Notifications
* User profile
* Theme switcher
* Help button
* Keyboard shortcuts modal
* Loading skeletons
* Empty state UI
* Confirmation dialogs
* Success toasts
* Error toasts
* AI recommendation cards
* Activity timeline
* Pagination
* Table density selector
* Column visibility selector
* Full-screen mode
* Breadcrumb navigation

---

## Final Deliverable

Create a **fully interactive frontend prototype** using mock data only. Every button should open the correct modal, drawer, dropdown, or multi-step wizard with realistic UI interactions. No backend integration, authentication, or API calls are required. The result should look polished enough to hand directly to a backend team for implementation.
