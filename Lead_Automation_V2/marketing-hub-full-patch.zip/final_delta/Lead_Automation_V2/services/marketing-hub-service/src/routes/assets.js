const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
const { authenticate, requirePermission } = require('@lead/shared');
const { query } = require('../database');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../../../uploads/assets');
    await fs.mkdir(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|mp4|mov|avi|pdf|doc|docx|mp3|wav/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

// Get all assets
router.get('/', authenticate, requirePermission('campaigns:read'), async (req, res) => {
  try {
    const { type, tags, search, limit = 50, offset = 0 } = req.query;
    
    let query_str = 'SELECT * FROM mh_assets WHERE organization_id = $1';
    const params = [req.user.organizationId];
    let paramCount = 1;
    
    if (type) {
      query_str += ` AND type = $${++paramCount}`;
      params.push(type);
    }
    
    if (tags) {
      query_str += ` AND tags && $${++paramCount}`;
      params.push(tags.split(','));
    }
    
    if (search) {
      query_str += ` AND name ILIKE $${++paramCount}`;
      params.push(`%${search}%`);
    }
    
    query_str += ` ORDER BY created_at DESC LIMIT $${++paramCount} OFFSET $${++paramCount}`;
    params.push(parseInt(limit), parseInt(offset));
    
    const result = await query(query_str, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching assets:', error);
    res.status(500).json({ error: 'Failed to fetch assets' });
  }
});

// Upload new asset
router.post('/', authenticate, requirePermission('campaigns:write'), upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const { name, type, tags, metadata } = req.body;
    
    const asset = await query(
      `INSERT INTO mh_assets (organization_id, name, type, file_path, file_size, mime_type, tags, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [
        req.user.organizationId,
        name || req.file.originalname,
        type || getFileType(req.file.mimetype),
        req.file.path,
        req.file.size,
        req.file.mimetype,
        tags ? tags.split(',') : [],
        metadata ? JSON.parse(metadata) : {}
      ]
    );
    
    res.status(201).json(asset.rows[0]);
  } catch (error) {
    console.error('Error uploading asset:', error);
    res.status(500).json({ error: 'Failed to upload asset' });
  }
});

// Get asset by ID
router.get('/:id', authenticate, requirePermission('campaigns:read'), async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM mh_assets WHERE id = $1 AND organization_id = $2',
      [req.params.id, req.user.organizationId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching asset:', error);
    res.status(500).json({ error: 'Failed to fetch asset' });
  }
});

// Update asset
router.put('/:id', authenticate, requirePermission('campaigns:write'), async (req, res) => {
  try {
    const { name, tags, metadata } = req.body;
    
    const result = await query(
      `UPDATE mh_assets 
       SET name = $1, tags = $2, metadata = $3, updated_at = now()
       WHERE id = $4 AND organization_id = $5
       RETURNING *`,
      [name, tags || [], metadata || {}, req.params.id, req.user.organizationId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating asset:', error);
    res.status(500).json({ error: 'Failed to update asset' });
  }
});

// Delete asset
router.delete('/:id', authenticate, requirePermission('campaigns:write'), async (req, res) => {
  try {
    const result = await query(
      'DELETE FROM mh_assets WHERE id = $1 AND organization_id = $2 RETURNING file_path',
      [req.params.id, req.user.organizationId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }
    
    // Delete file from disk
    try {
      await fs.unlink(result.rows[0].file_path);
    } catch (fileError) {
      console.warn('Failed to delete file:', fileError);
    }
    
    res.json({ message: 'Asset deleted successfully' });
  } catch (error) {
    console.error('Error deleting asset:', error);
    res.status(500).json({ error: 'Failed to delete asset' });
  }
});

// Serve asset files
router.get('/:id/file', authenticate, requirePermission('campaigns:read'), async (req, res) => {
  try {
    const result = await query(
      'SELECT file_path, mime_type, name FROM mh_assets WHERE id = $1 AND organization_id = $2',
      [req.params.id, req.user.organizationId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }
    
    const { file_path, mime_type, name } = result.rows[0];
    res.setHeader('Content-Type', mime_type);
    res.setHeader('Content-Disposition', `inline; filename="${name}"`);
    res.sendFile(path.resolve(file_path));
  } catch (error) {
    console.error('Error serving asset:', error);
    res.status(500).json({ error: 'Failed to serve asset' });
  }
});

// Get asset stats
router.get('/stats/overview', authenticate, requirePermission('campaigns:read'), async (req, res) => {
  try {
    const result = await query(
      `SELECT 
         type,
         COUNT(*) as count,
         SUM(file_size) as total_size
       FROM mh_assets 
       WHERE organization_id = $1 
       GROUP BY type`,
      [req.user.organizationId]
    );
    
    const stats = {
      total: result.rows.reduce((sum, row) => sum + parseInt(row.count), 0),
      by_type: result.rows.reduce((acc, row) => {
        acc[row.type] = { count: parseInt(row.count), size: parseInt(row.total_size) };
        return acc;
      }, {}),
      total_size: result.rows.reduce((sum, row) => sum + parseInt(row.total_size), 0)
    };
    
    res.json(stats);
  } catch (error) {
    console.error('Error fetching asset stats:', error);
    res.status(500).json({ error: 'Failed to fetch asset stats' });
  }
});

function getFileType(mimetype) {
  if (mimetype.startsWith('image/')) return 'image';
  if (mimetype.startsWith('video/')) return 'video';
  if (mimetype.startsWith('audio/')) return 'audio';
  if (mimetype.includes('pdf') || mimetype.includes('document')) return 'document';
  return 'document';
}

module.exports = router;